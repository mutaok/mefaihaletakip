"use client";

import { useMemo, useState } from "react";
import { ChevronLeft, ChevronRight, Trash2, Check, RotateCcw } from "lucide-react";

import { deleteTaskAction, toggleTaskCompletedAction } from "@/app/actions";
import { SubmitButton } from "@/components/submit-button";
import { formatDate, todayDateKey } from "@/lib/format";
import type { Task } from "@/lib/tasks";

const WEEKDAY_LABELS = ["Pt", "Sa", "Ça", "Pe", "Cu", "Ct", "Pz"];

type Urgency = "gecikti" | "bugun" | "yakinda";

const URGENCY_CHIP: Record<Urgency, { label: string; className: string }> = {
  gecikti: { label: "Gecikti", className: "bg-red-50 text-red-700 border border-red-200" },
  bugun: { label: "Bugün", className: "bg-slate-800 text-white" },
  yakinda: { label: "Yakında", className: "bg-amber-50 text-amber-700 border border-amber-200" },
};

function taskUrgency(dueDate: string, today: string): Urgency {
  if (dueDate < today) return "gecikti";
  if (dueDate === today) return "bugun";
  return "yakinda";
}

function toDateKey(date: Date): string {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function buildMonthGrid(year: number, month: number): Date[] {
  const firstOfMonth = new Date(year, month, 1);
  const leadingBlanks = (firstOfMonth.getDay() + 6) % 7;
  const gridStart = new Date(year, month, 1 - leadingBlanks);

  return Array.from({ length: 42 }, (_, i) => {
    const d = new Date(gridStart);
    d.setDate(gridStart.getDate() + i);
    return d;
  });
}

export function TaskBoard({
  activeTasks,
  completedTasks,
}: {
  activeTasks: Task[];
  completedTasks: Task[];
}) {
  const today = todayDateKey();
  const [viewDate, setViewDate] = useState(() => {
    const now = new Date();
    return new Date(now.getFullYear(), now.getMonth(), 1);
  });
  const [selectedDate, setSelectedDate] = useState<string | null>(null);
  const [showCompleted, setShowCompleted] = useState(false);

  const tasksByDate = useMemo(() => {
    const map = new Map<string, Task[]>();
    for (const task of activeTasks) {
      const list = map.get(task.dueDate) ?? [];
      list.push(task);
      map.set(task.dueDate, list);
    }
    return map;
  }, [activeTasks]);

  const grid = useMemo(
    () => buildMonthGrid(viewDate.getFullYear(), viewDate.getMonth()),
    [viewDate],
  );

  const monthLabel = new Intl.DateTimeFormat("tr-TR", {
    month: "long",
    year: "numeric",
  }).format(viewDate);

  const visibleTasks = selectedDate
    ? activeTasks.filter((task) => task.dueDate === selectedDate)
    : activeTasks;

  return (
    <div className="grid gap-6 p-6 lg:grid-cols-[minmax(0,420px)_1fr]">
      {/* ── Takvim ── */}
      <div className="h-fit rounded-3xl border border-line bg-white/80 p-5">
        <div className="mb-4 flex items-center justify-between">
          <button
            type="button"
            onClick={() =>
              setViewDate((d) => new Date(d.getFullYear(), d.getMonth() - 1, 1))
            }
            className="grid size-8 place-items-center rounded-lg border border-line text-muted transition hover:bg-line/30"
          >
            <ChevronLeft className="size-4" />
          </button>
          <p className="text-sm font-bold capitalize text-foreground">{monthLabel}</p>
          <button
            type="button"
            onClick={() =>
              setViewDate((d) => new Date(d.getFullYear(), d.getMonth() + 1, 1))
            }
            className="grid size-8 place-items-center rounded-lg border border-line text-muted transition hover:bg-line/30"
          >
            <ChevronRight className="size-4" />
          </button>
        </div>

        <div className="grid grid-cols-7 gap-1 text-center text-[11px] font-semibold uppercase tracking-wide text-muted">
          {WEEKDAY_LABELS.map((label) => (
            <div key={label} className="py-1">
              {label}
            </div>
          ))}
        </div>

        <div className="grid grid-cols-7 gap-1">
          {grid.map((date) => {
            const key = toDateKey(date);
            const inMonth = date.getMonth() === viewDate.getMonth();
            const dayTasks = tasksByDate.get(key) ?? [];
            const isToday = key === today;
            const isSelected = key === selectedDate;

            return (
              <button
                type="button"
                key={key}
                onClick={() => setSelectedDate((prev) => (prev === key ? null : key))}
                className={`flex aspect-square flex-col items-center justify-center gap-0.5 rounded-xl text-sm transition ${
                  isSelected
                    ? "bg-accent text-white"
                    : isToday
                      ? "border border-accent text-accent"
                      : inMonth
                        ? "text-foreground hover:bg-line/30"
                        : "text-muted/40 hover:bg-line/20"
                }`}
              >
                <span>{date.getDate()}</span>
                {dayTasks.length > 0 && (
                  <span
                    className={`size-1.5 rounded-full ${
                      isSelected ? "bg-white" : "bg-accent-strong"
                    }`}
                  />
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* ── Görev listesi ── */}
      <div className="space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h2 className="text-sm font-bold text-foreground">
            {selectedDate
              ? `${formatDate(selectedDate)} tarihindeki görevler`
              : "Tüm Aktif Görevler"}
            <span className="ml-2 rounded-full bg-accent/10 px-2 py-0.5 text-xs font-semibold text-accent">
              {visibleTasks.length}
            </span>
          </h2>
          {selectedDate && (
            <button
              type="button"
              onClick={() => setSelectedDate(null)}
              className="text-xs font-medium text-accent hover:underline"
            >
              Tümünü Göster
            </button>
          )}
        </div>

        {visibleTasks.length > 0 ? (
          <div className="space-y-2">
            {visibleTasks.map((task) => {
              const urgency = taskUrgency(task.dueDate, today);
              const chip = URGENCY_CHIP[urgency];
              return (
                <div
                  key={task.id}
                  className="flex flex-wrap items-start justify-between gap-3 rounded-2xl border border-line bg-white/80 px-5 py-4"
                >
                  <div className="min-w-0 flex-1 space-y-1.5">
                    <p className="text-sm font-semibold text-foreground">{task.title}</p>
                    {task.description && (
                      <p className="text-xs text-muted">{task.description}</p>
                    )}
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-xs text-muted">{formatDate(task.dueDate)}</span>
                      <span
                        className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-[11px] font-semibold ${chip.className}`}
                      >
                        {chip.label}
                      </span>
                    </div>
                  </div>
                  <div className="flex flex-shrink-0 items-center gap-2">
                    <form action={toggleTaskCompletedAction}>
                      <input name="taskId" type="hidden" value={task.id} />
                      <input name="completed" type="hidden" value="true" />
                      <SubmitButton
                        className="inline-flex items-center gap-2 rounded-xl border border-accent/30 bg-accent/10 px-3 py-2 text-xs font-semibold text-accent transition hover:bg-accent/20 disabled:opacity-70"
                        pendingLabel="..."
                      >
                        <Check className="size-3.5" /> Tamamlandı
                      </SubmitButton>
                    </form>
                    <form action={deleteTaskAction}>
                      <input name="taskId" type="hidden" value={task.id} />
                      <SubmitButton
                        className="grid size-8 place-items-center rounded-xl border border-rose-300 bg-rose-50 text-rose-700 transition hover:bg-rose-100 disabled:opacity-70"
                        pendingLabel="…"
                      >
                        <Trash2 className="size-3.5" />
                      </SubmitButton>
                    </form>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <p className="rounded-2xl border border-dashed border-line px-5 py-8 text-center text-xs text-muted">
            {selectedDate ? "Bu tarihte görev yok" : "Henüz görev eklenmedi"}
          </p>
        )}

        {completedTasks.length > 0 && (
          <div className="pt-2">
            <button
              type="button"
              onClick={() => setShowCompleted((v) => !v)}
              className="text-xs font-medium text-muted hover:text-foreground"
            >
              {showCompleted
                ? "Tamamlananları Gizle"
                : `Tamamlananları Göster (${completedTasks.length})`}
            </button>

            {showCompleted && (
              <div className="mt-3 space-y-2">
                {completedTasks.map((task) => (
                  <div
                    key={task.id}
                    className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-line bg-line/10 px-5 py-3"
                  >
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm text-foreground line-through">
                        {task.title}
                      </p>
                      <p className="text-xs text-muted">{formatDate(task.dueDate)}</p>
                    </div>
                    <div className="flex flex-shrink-0 items-center gap-2">
                      <form action={toggleTaskCompletedAction}>
                        <input name="taskId" type="hidden" value={task.id} />
                        <input name="completed" type="hidden" value="false" />
                        <SubmitButton
                          className="inline-flex items-center gap-2 rounded-xl border border-line px-3 py-2 text-xs font-semibold text-foreground transition hover:bg-line/30 disabled:opacity-70"
                          pendingLabel="..."
                        >
                          <RotateCcw className="size-3.5" /> Geri Al
                        </SubmitButton>
                      </form>
                      <form action={deleteTaskAction}>
                        <input name="taskId" type="hidden" value={task.id} />
                        <SubmitButton
                          className="grid size-8 place-items-center rounded-xl border border-rose-300 bg-rose-50 text-rose-700 transition hover:bg-rose-100 disabled:opacity-70"
                          pendingLabel="…"
                        >
                          <Trash2 className="size-3.5" />
                        </SubmitButton>
                      </form>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
