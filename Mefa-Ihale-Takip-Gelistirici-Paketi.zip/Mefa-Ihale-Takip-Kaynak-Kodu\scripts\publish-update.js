/**
 * publish-update.js
 *
 * Zips the built server folder and uploads it to Supabase Storage
 * as an auto-update package.
 *
 * Prerequisites:
 *   1. npm run build
 *   2. node scripts/build-electron.js
 *   3. node scripts/publish-update.js   ← this script
 *
 * What it does:
 *   - Reads version from package.json
 *   - Zips  dist-electron/resources/server  →  update-<version>.zip
 *   - Uploads ZIP  to  tender-files/_updates/update-<version>.zip
 *   - Uploads JSON to  tender-files/_updates/version.json
 */

"use strict";

const fs = require("fs");
const path = require("path");
const { spawnSync } = require("child_process");
const https = require("https");
const os = require("os");

// ── Paths ────────────────────────────────────────────────────────────────────

const ROOT = path.join(__dirname, "..");
const pkg = JSON.parse(fs.readFileSync(path.join(ROOT, "package.json"), "utf-8"));
const VERSION = pkg.version;
const BUCKET = "tender-files";
const UPDATE_PREFIX = "_updates";

console.log(`\n📦  MEFA Ihale Takip — Güncelleme Yayınlama  v${VERSION}\n`);

// ── Env vars ─────────────────────────────────────────────────────────────────

const envPath = path.join(ROOT, ".env.local");
if (!fs.existsSync(envPath)) {
  console.error("HATA: .env.local dosyası bulunamadı.");
  process.exit(1);
}

const envVars = {};
for (const line of fs.readFileSync(envPath, "utf-8").split("\n")) {
  const trimmed = line.trim();
  if (!trimmed || trimmed.startsWith("#")) continue;
  const eqIdx = trimmed.indexOf("=");
  if (eqIdx === -1) continue;
  const key = trimmed.slice(0, eqIdx).trim();
  let val = trimmed.slice(eqIdx + 1).trim();
  if (
    (val.startsWith('"') && val.endsWith('"')) ||
    (val.startsWith("'") && val.endsWith("'"))
  ) {
    val = val.slice(1, -1);
  }
  envVars[key] = val;
}

const SUPABASE_URL = envVars["NEXT_PUBLIC_SUPABASE_URL"];
const SERVICE_ROLE_KEY = envVars["SUPABASE_SERVICE_ROLE_KEY"];

if (!SUPABASE_URL || !SERVICE_ROLE_KEY) {
  console.error(
    "HATA: .env.local dosyasında NEXT_PUBLIC_SUPABASE_URL veya SUPABASE_SERVICE_ROLE_KEY eksik.",
  );
  process.exit(1);
}

// ── Check build output ────────────────────────────────────────────────────────

const serverSrc = path.join(ROOT, "dist-electron", "win-unpacked", "resources", "server");
const asarSrc = path.join(ROOT, "dist-electron", "win-unpacked", "resources", "app.asar");
if (!fs.existsSync(serverSrc) || !fs.existsSync(asarSrc)) {
  console.error(`HATA: Build çıktısı bulunamadı: ${serverSrc}`);
  console.error(
    "Önce şunu çalıştırın:\n  npm run build\n  node scripts/build-electron.js",
  );
  process.exit(1);
}

// ── Create ZIP ────────────────────────────────────────────────────────────────

const tmpDir = path.join(os.tmpdir(), "mefa-publish");
fs.mkdirSync(tmpDir, { recursive: true });

const zipFileName = `update-${VERSION}.zip`;
const zipPath = path.join(tmpDir, zipFileName);

// Remove old zip if exists
if (fs.existsSync(zipPath)) fs.rmSync(zipPath);

console.log("🗜   ZIP oluşturuluyor...");
console.log(`    Kaynak : ${serverSrc}`);
console.log(`    Hedef  : ${zipPath}`);

const psResult = spawnSync(
  "powershell.exe",
  [
    "-ExecutionPolicy",
    "Bypass",
    "-Command",
    `Compress-Archive -Path "${serverSrc}", "${asarSrc}" -DestinationPath "${zipPath}" -Force`,
  ],
  { stdio: "inherit" },
);

if (psResult.status !== 0) {
  console.error("HATA: ZIP oluşturulamadı.");
  process.exit(1);
}

if (!fs.existsSync(zipPath)) {
  console.error("HATA: ZIP dosyası bulunamadı.");
  process.exit(1);
}

const zipSize = fs.statSync(zipPath).size;
console.log(`    Boyut  : ${(zipSize / 1024 / 1024).toFixed(1)} MB\n`);

// ── Upload helpers ────────────────────────────────────────────────────────────

function supabaseUpload(storagePath, body, contentType) {
  return new Promise((resolve, reject) => {
    const url = new URL(
      `${SUPABASE_URL}/storage/v1/object/${BUCKET}/${storagePath}`,
    );

    const isBuffer = Buffer.isBuffer(body);
    const contentLength = isBuffer ? body.length : fs.statSync(body).size;

    const options = {
      hostname: url.hostname,
      path: url.pathname,
      method: "POST",
      headers: {
        Authorization: `Bearer ${SERVICE_ROLE_KEY}`,
        "Content-Type": contentType,
        "Content-Length": contentLength,
        "x-upsert": "true",
        // Supabase Storage nesnelere varsayilan olarak 1 saatlik CDN
        // onbellegi uyguluyor. Bu, guncelleme paketleri icin bir makinenin
        // eski/yarim kalmis bir kopyayi indirmesine yol acabiliyordu
        // (bkz. update-log.txt'teki "Merkezi Dizinin Sonu kaydi bulunamadi"
        // hatasi - indirilen zip bozuktu). Bu iki dosya icin onbellek kapatildi.
        "Cache-Control": "no-cache, max-age=0",
      },
    };

    const req = https.request(options, (res) => {
      const chunks = [];
      res.on("data", (c) => chunks.push(c));
      res.on("end", () =>
        resolve({
          status: res.statusCode,
          body: Buffer.concat(chunks).toString("utf-8"),
        }),
      );
    });

    req.on("error", reject);

    if (isBuffer) {
      req.write(body);
      req.end();
    } else {
      // body is a file path → stream
      fs.createReadStream(body).pipe(req);
    }
  });
}

// ── Main ──────────────────────────────────────────────────────────────────────

async function main() {
  // 1. Upload ZIP
  console.log(`⬆   ZIP yükleniyor → ${UPDATE_PREFIX}/${zipFileName}`);
  const zipRes = await supabaseUpload(
    `${UPDATE_PREFIX}/${zipFileName}`,
    zipPath, // file path → streamed
    "application/zip",
  );

  if (zipRes.status !== 200) {
    console.error(`HATA: ZIP yüklenemedi (HTTP ${zipRes.status})`);
    console.error(zipRes.body);
    process.exit(1);
  }
  console.log("    ✓ ZIP yüklendi.\n");

  // 2. Upload version.json
  const versionInfo = { version: VERSION, file: zipFileName };
  const versionBuf = Buffer.from(JSON.stringify(versionInfo, null, 2), "utf-8");

  console.log(`⬆   version.json güncelleniyor → ${UPDATE_PREFIX}/version.json`);
  const vRes = await supabaseUpload(
    `${UPDATE_PREFIX}/version.json`,
    versionBuf,
    "application/json",
  );

  if (vRes.status !== 200) {
    console.error(`HATA: version.json yüklenemedi (HTTP ${vRes.status})`);
    console.error(vRes.body);
    process.exit(1);
  }
  console.log(`    ✓ version.json → v${VERSION}\n`);

  // 3. Clean up temp zip
  try {
    fs.rmSync(zipPath);
  } catch {}

  console.log(`✅  Güncelleme başarıyla yayınlandı! (v${VERSION})\n`);
  console.log(
    "    Diğer bilgisayarlardaki uygulama bir sonraki açılışta otomatik güncelleme teklif edecek.\n",
  );
}

main().catch((err) => {
  console.error("Beklenmeyen hata:", err);
  process.exit(1);
});
