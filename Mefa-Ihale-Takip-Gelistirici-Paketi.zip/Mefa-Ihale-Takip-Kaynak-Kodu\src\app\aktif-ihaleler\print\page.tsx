import { PrintToolbar } from "@/components/print/print-toolbar";
import "@/app/print.css";
import { formatDate, todayDateKey } from "@/lib/format";
import { deriveTenderStatus } from "@/lib/tender-details";
import { getTenderDashboardData } from "@/lib/tenders";

export const dynamic = "force-dynamic";

const STATUS_TAG: Record<"open" | "upcoming", { label: string; className: string }> = {
  open: { label: "Değerlendirmede", className: "pd-warn" },
  upcoming: { label: "", className: "pd-info" },
};

export default async function ActiveTendersPrintPage() {
  const today = todayDateKey();
  const dashboard = await getTenderDashboardData();

  const activeTenders = dashboard.tenders
    .filter((tender) => tender.outcome === null)
    .map((tender) => ({ tender, status: deriveTenderStatus(null, tender.tenderDate, today) }))
    .sort((a, b) => {
      const aDate = a.tender.tenderDate ?? "9999-99-99";
      const bDate = b.tender.tenderDate ?? "9999-99-99";
      return aDate.localeCompare(bDate);
    });

  return (
    <div className="pd-root">
      <PrintToolbar backHref="/" />
      <div className="pd-frame">
        <article className="pd-paper" style={{ maxWidth: 760 }}>
          <div className="pd-letterhead">
            <div className="pd-wordmark">
              Mefa Group
              <small>İhale Takip Sistemi</small>
            </div>
            <div className="pd-doc-meta">
              BELGE NO: AKT-{today.replace(/-/g, "").slice(2)}
              <br />
              {formatDate(today)} itibarıyla
            </div>
          </div>
          <div className="pd-rule-1" />
          <div className="pd-rule-2" />

          <div className="pd-title-row" style={{ marginBottom: "1.4rem" }}>
            <div className="pd-title-block">
              <span className="pd-eyebrow">Aktif İhaleler Raporu</span>
              <h1>Katılacağımız / Sonuç Bekleyen İhaleler ({activeTenders.length})</h1>
            </div>
          </div>

          {activeTenders.length === 0 ? (
            <p className="pd-empty">Şu anda aktif (sonuçlanmamış) ihale bulunmuyor.</p>
          ) : (
            <div className="pd-table-scroll">
              <table className="pd-table">
                <thead>
                  <tr>
                    <th>İhale Adı</th>
                    <th>İdare</th>
                    <th>İhale Tarihi</th>
                    <th>Durum</th>
                  </tr>
                </thead>
                <tbody>
                  {activeTenders.map(({ tender, status }) => (
                    <tr key={tender.id}>
                      <td>{tender.title}</td>
                      <td className="pd-muted">{tender.authority || "—"}</td>
                      <td className="pd-num">{formatDate(tender.tenderDate)}</td>
                      <td>
                        {status.kind === "upcoming" ? (
                          <span className="pd-status-tag pd-info">{status.daysRemaining} gün kaldı</span>
                        ) : (
                          <span className={`pd-status-tag ${STATUS_TAG.open.className}`}>
                            {STATUS_TAG.open.label}
                          </span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          <div className="pd-footnote">Bu belge Mefa Group İhale Takip sisteminden otomatik oluşturulmuştur.</div>
        </article>
      </div>
    </div>
  );
}
