$WshShell = New-Object -ComObject WScript.Shell
$desktop = [Environment]::GetFolderPath('Desktop')
$lnkPath = Join-Path $desktop 'MEFA Ihale Takip.lnk'
$exePath = Join-Path $PSScriptRoot '..\dist-electron\win-unpacked\MEFA Ihale Takip.exe'
$exePath = (Resolve-Path $exePath).Path
$workDir = Split-Path $exePath

$Shortcut = $WshShell.CreateShortcut($lnkPath)
$Shortcut.TargetPath = $exePath
$Shortcut.WorkingDirectory = $workDir
$Shortcut.Description = 'Mefa Group Ihale Takip Uygulamasi'
$Shortcut.Save()

Write-Host "Kisayol olusturuldu: $lnkPath"
