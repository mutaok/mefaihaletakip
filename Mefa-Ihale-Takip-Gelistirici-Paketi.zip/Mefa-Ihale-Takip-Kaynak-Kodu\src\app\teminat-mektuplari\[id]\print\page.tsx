import { notFound } from "next/navigation";

import { PrintToolbar } from "@/components/print/print-toolbar";
import "@/app/print.css";
import { formatDate, formatDateTime, todayDateKey } from "@/lib/format";
import { getGuaranteeLetters } from "@/lib/guarantee-letters";

export const dynamic = "force-dynamic";

type PageProps = { params: Promise<{ id: string }> };

export default async function GuaranteeLetterPrintPage({ params }: PageProps) {
  const { id } = await params;
  const result = await getGuaranteeLetters();
  const letter = result.letters.find((l) => l.id === id);
  if (!result.isConfigured || result.dataError || !letter) notFound();

  const returned = Boolean(letter.returnedAt);

  return (
    <div className="pd-root">
      <PrintToolbar backHref="/teminat-mektuplari" />
      <div className="pd-frame">
        <article className="pd-paper" style={{ maxWidth: 760 }}>
          <div className="pd-letterhead">
            <div className="pd-wordmark">
              Mefa Group
              <small>İhale Takip Sistemi</small>
            </div>
            <div className="pd-doc-meta">
              BELGE NO: TM-{letter.id.slice(0, 8).toUpperCase()}
              <br />
              OLUŞTURMA: {formatDate(todayDateKey())}
            </div>
          </div>
          <div className="pd-rule-1" />
          <div className="pd-rule-2" />

          <div className="pd-title-row">
            <div className="pd-title-block">
              <span className="pd-eyebrow">Teminat Mektubu Kayıt Formu</span>
              <h1>{letter.bankName}</h1>
            </div>
            {returned ? (
              <span className="pd-stamp won">
                İade Edildi
                <small>{formatDate(letter.returnedAt)}</small>
              </span>
            ) : (
              <span className={`pd-stamp ${letter.daysOutstanding >= 90 ? "lost" : "warn"}`}>
                {letter.daysOutstanding} Gündür İade Edilmedi
              </span>
            )}
          </div>

          <div className="pd-grid">
            <div className="pd-field"><label>Tür</label><div className="pd-val">{letter.letterType === "kesin" ? "Kesin Teminat" : "Geçici Teminat"}</div></div>
            <div className="pd-field"><label>Tutar</label><div className="pd-val pd-num">{letter.amount}</div></div>
            <div className="pd-field"><label>Eklenme Tarihi</label><div className="pd-val pd-num">{formatDate(letter.createdAt.slice(0, 10))}</div></div>
            <div className="pd-field pd-field-wide"><label>İdare</label><div className="pd-val">{letter.authority}</div></div>
            <div className="pd-field pd-field-wide"><label>İlgili İş</label><div className="pd-val">{letter.jobDescription}</div></div>
          </div>

          <div className="pd-footnote">
            Orijinal teminat mektubu PDF eki sistemde kayıtlıdır · Belge No: TM-{letter.id.slice(0, 8).toUpperCase()} · {formatDateTime(new Date().toISOString())}
          </div>
        </article>
      </div>
    </div>
  );
}
