import { PrintToolbar } from "@/components/print/print-toolbar";
import "@/app/print.css";
import { formatDate, todayDateKey } from "@/lib/format";
import { getTasks, type Task } from "@/lib/tasks";

export const dynamic = "force-dynamic";

type Urgency = "gecikti" | "bugun" | "yakinda";

function taskUrgency(task: Task, today: string): Urgency {
  if (task.dueDate < today) return "gecikti";
  if (task.dueDate === today) return "bugun";
  return "yakinda";
}

const URGENCY_TAG: Record<Urgency, { label: string; className: string }> = {
  gecikti: { label: "Gecikti", className: "pd-lost" },
  bugun: { label: "Bugün", className: "pd-info" },
  yakinda: { label: "Yakında", className: "pd-warn" },
};

export default async function TasksPrintPage() {
  const today = todayDateKey();
  const result = await getTasks();
  const tasks = result.activeTasks;

  const gecikti = tasks.filter((t) => taskUrgency(t, today) === "gecikti").length;

  return (
    <div className="pd-root">
      <PrintToolbar backHref="/gorevler" />
      <div className="pd-frame">
        <article className="pd-paper" style={{ maxWidth: 760 }}>
          <div className="pd-letterhead">
            <div className="pd-wordmark">
              Mefa Group
              <small>İhale Takip Sistemi</small>
            </div>
            <div className="pd-doc-meta">
              BELGE NO: GRV-{today.replace(/-/g, "").slice(2)}
              <br />
              {formatDate(today)} itibarıyla
            </div>
          </div>
          <div className="pd-rule-1" />
          <div className="pd-rule-2" />

          <div className="pd-title-row" style={{ marginBottom: "1.4rem" }}>
            <div className="pd-title-block">
              <span className="pd-eyebrow">Operasyonel Takvim Ve Ajanda</span>
              <h1>Açık Görevler ({tasks.length})</h1>
            </div>
            {gecikti > 0 && (
              <span className="pd-stamp lost">{gecikti} Görev Gecikti</span>
            )}
          </div>

          {tasks.length === 0 ? (
            <p className="pd-empty">Şu anda açık görev bulunmuyor.</p>
          ) : (
            <div className="pd-table-scroll">
              <table className="pd-table">
                <thead>
                  <tr>
                    <th className="pd-check-cell" />
                    <th>Görev</th>
                    <th>Son Tarih</th>
                    <th>Durum</th>
                  </tr>
                </thead>
                <tbody>
                  {tasks.map((task) => {
                    const tag = URGENCY_TAG[taskUrgency(task, today)];
                    return (
                      <tr key={task.id}>
                        <td className="pd-check-cell">☐</td>
                        <td>{task.title}</td>
                        <td className="pd-num">{formatDate(task.dueDate)}</td>
                        <td>
                          <span className={`pd-status-tag ${tag.className}`}>{tag.label}</span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}

          <div className="pd-footnote">☐ kutucuğu tamamlandığında işaretlenip sisteme elle girilebilir.</div>
        </article>
      </div>
    </div>
  );
}
