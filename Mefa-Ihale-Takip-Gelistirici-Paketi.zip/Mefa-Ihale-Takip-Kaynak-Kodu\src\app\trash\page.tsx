import Link from "next/link";
import { ArrowLeft, RotateCcw, Trash2 } from "lucide-react";

import {
  permanentDeleteTenderAction,
  restoreTenderAction,
} from "@/app/actions";
import { StatusBanner } from "@/components/status-banner";
import { SubmitButton } from "@/components/submit-button";
import { resolveFlashMessage } from "@/lib/flash";
import { formatDate, formatDateTime } from "@/lib/format";
import { getDeletedTenders } from "@/lib/tenders";

export const dynamic = "force-dynamic";

type TrashPageProps = {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
};

export default async function TrashPage({ searchParams }: TrashPageProps) {
  const params = await searchParams;
  const flash = resolveFlashMessage(params);
  const result = await getDeletedTenders();

  return (
    <div className="flex flex-1 flex-col overflow-hidden">
      <header className="flex flex-shrink-0 items-center gap-4 border-b border-line bg-white/50 px-6 py-3 backdrop-blur-sm">
        <Link
          href="/"
          className="inline-flex flex-shrink-0 items-center gap-2 rounded-xl border border-line bg-white px-3.5 py-2 text-sm font-medium text-foreground transition hover:border-accent/30"
        >
          <ArrowLeft className="size-4" /> Geri
        </Link>
        <div className="flex items-center gap-3">
          <Trash2 className="size-5 text-rose-600" />
          <h1 className="text-base font-bold text-foreground">Çöp Kutusu</h1>
          <span className="rounded-full bg-rose-100 px-2.5 py-0.5 text-xs font-semibold text-rose-700">
            {result.tenders.length}
          </span>
        </div>
      </header>

      <div className="flex-1 overflow-y-auto">
        <div className="mx-auto max-w-3xl space-y-4 p-6">
          {flash ? <StatusBanner flash={flash} /> : null}

          {result.dataError && (
            <div className="rounded-2xl border border-rose-200 bg-rose-50/90 px-4 py-3 text-xs leading-6 text-rose-900">
              {result.dataError}
            </div>
          )}

          {result.tenders.length > 0 ? (
            <div className="space-y-2">
              {result.tenders.map((tender) => (
                <div
                  key={tender.id}
                  className="flex flex-wrap items-center justify-between gap-4 rounded-2xl border border-line bg-white/80 px-5 py-4"
                >
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-semibold text-foreground">
                      {tender.title}
                    </p>
                    <p className="mt-0.5 text-xs text-muted">
                      {tender.authority && `${tender.authority} · `}
                      {formatDate(tender.tenderDate)}
                    </p>
                    <p className="mt-1 text-xs text-rose-600">
                      Silinme: {formatDateTime(tender.deletedAt)}
                    </p>
                  </div>
                  <div className="flex flex-shrink-0 items-center gap-2">
                    <form action={restoreTenderAction}>
                      <input name="tenderId" type="hidden" value={tender.id} />
                      <SubmitButton
                        className="inline-flex items-center gap-2 rounded-xl border border-accent/30 bg-accent/10 px-4 py-2 text-sm font-semibold text-accent transition hover:bg-accent/20 disabled:opacity-70"
                        pendingLabel="Yükleniyor..."
                      >
                        <RotateCcw className="size-4" /> Geri Yükle
                      </SubmitButton>
                    </form>
                    <form action={permanentDeleteTenderAction}>
                      <input name="tenderId" type="hidden" value={tender.id} />
                      <SubmitButton
                        className="inline-flex items-center gap-2 rounded-xl border border-rose-300 bg-rose-50 px-4 py-2 text-sm font-semibold text-rose-700 transition hover:bg-rose-100 disabled:opacity-70"
                        pendingLabel="Siliniyor..."
                      >
                        <Trash2 className="size-4" /> Kalıcı Sil
                      </SubmitButton>
                    </form>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="flex flex-col items-center gap-3 py-16 text-center">
              <Trash2 className="size-10 text-muted/30" />
              <p className="text-sm text-muted">Çöp kutusu boş</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
