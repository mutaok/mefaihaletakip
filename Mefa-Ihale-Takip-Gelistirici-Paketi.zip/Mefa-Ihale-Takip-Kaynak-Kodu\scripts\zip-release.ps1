$src     = Join-Path $PSScriptRoot "..\dist-electron\win-unpacked"
$desktop = [Environment]::GetFolderPath('Desktop')
$dest    = Join-Path $desktop "MEFA Ihale Takip v1.1.0.zip"
if (Test-Path $dest) { Remove-Item $dest -Force }
Compress-Archive -Path "$src\*" -DestinationPath $dest -Force
$size = [math]::Round((Get-Item $dest).Length / 1MB, 1)
Write-Host "ZIP olusturuldu: $dest"
Write-Host "Boyut: $size MB"
