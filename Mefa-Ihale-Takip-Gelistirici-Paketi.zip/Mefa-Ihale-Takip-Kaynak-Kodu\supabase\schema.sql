create extension if not exists pgcrypto;

insert into storage.buckets (id, name, public)
values ('tender-files', 'tender-files', false)
on conflict (id) do nothing;

create table if not exists public.tender_folders (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  reference_code text,
  authority text,
  tender_date date,
  details jsonb not null default '{}'::jsonb,
  il text,
  ilce text,
  location_name text,
  latitude numeric(9, 6),
  longitude numeric(9, 6),
  description text,
  created_at timestamptz not null default timezone('utc', now())
);

create table if not exists public.tender_document_folders (
  id uuid primary key default gen_random_uuid(),
  tender_id uuid not null references public.tender_folders (id) on delete cascade,
  name text not null,
  created_at timestamptz not null default timezone('utc', now()),
  unique (tender_id, name)
);

alter table public.tender_folders
  add column if not exists tender_date date;

alter table public.tender_folders
  add column if not exists details jsonb not null default '{}'::jsonb;

update public.tender_folders
set details = '{}'::jsonb
where details is null;

alter table public.tender_folders
  alter column details set default '{}'::jsonb;

alter table public.tender_folders
  alter column details set not null;

alter table public.tender_folders
  alter column il drop not null;

alter table public.tender_folders
  alter column latitude drop not null;

alter table public.tender_folders
  alter column longitude drop not null;

create table if not exists public.tender_documents (
  id uuid primary key default gen_random_uuid(),
  tender_id uuid not null references public.tender_folders (id) on delete cascade,
  folder_id uuid references public.tender_document_folders (id) on delete set null,
  display_name text not null,
  original_filename text not null,
  storage_path text not null unique,
  file_size bigint,
  mime_type text not null default 'application/pdf',
  uploaded_at timestamptz not null default timezone('utc', now())
);

create index if not exists tender_folders_created_at_idx
  on public.tender_folders (created_at desc);

create index if not exists tender_document_folders_tender_id_idx
  on public.tender_document_folders (tender_id, created_at desc);

create index if not exists tender_documents_tender_id_idx
  on public.tender_documents (tender_id);

create index if not exists tender_documents_folder_id_idx
  on public.tender_documents (folder_id);

alter table public.tender_folders enable row level security;
alter table public.tender_document_folders enable row level security;
alter table public.tender_documents enable row level security;

drop policy if exists "Anyone can read tender folders" on public.tender_folders;
create policy "Anyone can read tender folders"
  on public.tender_folders for select
  using (true);

drop policy if exists "Service role manages tender folders" on public.tender_folders;
create policy "Service role manages tender folders"
  on public.tender_folders for all
  using (true)
  with check (true);

drop policy if exists "Anyone can read tender document folders" on public.tender_document_folders;
create policy "Anyone can read tender document folders"
  on public.tender_document_folders for select
  using (true);

drop policy if exists "Service role manages tender document folders" on public.tender_document_folders;
create policy "Service role manages tender document folders"
  on public.tender_document_folders for all
  using (true)
  with check (true);

drop policy if exists "Anyone can read tender documents" on public.tender_documents;
create policy "Anyone can read tender documents"
  on public.tender_documents for select
  using (true);

drop policy if exists "Service role manages tender documents" on public.tender_documents;
create policy "Service role manages tender documents"
  on public.tender_documents for all
  using (true)
  with check (true);

drop policy if exists "Authenticated users can read tender files" on storage.objects;
create policy "Authenticated users can read tender files"
  on storage.objects for select
  using (bucket_id = 'tender-files');

drop policy if exists "Service role uploads tender files" on storage.objects;
create policy "Service role uploads tender files"
  on storage.objects for insert
  with check (bucket_id = 'tender-files');

drop policy if exists "Service role deletes tender files" on storage.objects;
create policy "Service role deletes tender files"
  on storage.objects for delete
  using (bucket_id = 'tender-files');

create table if not exists public.guarantee_letters (
  id uuid primary key default gen_random_uuid(),
  bank_name text not null,
  amount text not null,
  authority text not null,
  job_description text not null,
  storage_path text not null unique,
  original_filename text not null,
  file_size bigint,
  created_at timestamptz not null default timezone('utc', now())
);

create table if not exists public.tasks (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text,
  due_date date not null,
  completed boolean not null default false,
  completed_at timestamptz,
  created_at timestamptz not null default timezone('utc', now())
);

create index if not exists guarantee_letters_created_at_idx
  on public.guarantee_letters (created_at desc);

create index if not exists tasks_due_date_idx
  on public.tasks (due_date asc);

alter table public.guarantee_letters enable row level security;
alter table public.tasks enable row level security;

drop policy if exists "Anyone can read guarantee letters" on public.guarantee_letters;
create policy "Anyone can read guarantee letters"
  on public.guarantee_letters for select
  using (true);

drop policy if exists "Service role manages guarantee letters" on public.guarantee_letters;
create policy "Service role manages guarantee letters"
  on public.guarantee_letters for all
  using (true)
  with check (true);

drop policy if exists "Anyone can read tasks" on public.tasks;
create policy "Anyone can read tasks"
  on public.tasks for select
  using (true);

drop policy if exists "Service role manages tasks" on public.tasks;
create policy "Service role manages tasks"
  on public.tasks for all
  using (true)
  with check (true);

alter table public.guarantee_letters
  add column if not exists letter_type text not null default 'gecici';

alter table public.guarantee_letters
  drop constraint if exists guarantee_letters_letter_type_check;

alter table public.guarantee_letters
  add constraint guarantee_letters_letter_type_check
  check (letter_type in ('gecici', 'kesin'));
