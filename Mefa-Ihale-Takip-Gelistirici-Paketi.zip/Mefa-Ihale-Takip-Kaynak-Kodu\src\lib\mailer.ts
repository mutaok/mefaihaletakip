import "server-only";

import nodemailer, { type Transporter } from "nodemailer";

let transporter: Transporter | null = null;
let transporterUser: string | null = null;

function getTransporter(): { transporter: Transporter; from: string } | null {
  const user = process.env.GMAIL_USER?.trim();
  const pass = process.env.GMAIL_APP_PASSWORD?.trim();
  if (!user || !pass) return null;

  if (!transporter || transporterUser !== user) {
    transporter = nodemailer.createTransport({
      service: "gmail",
      auth: { user, pass },
    });
    transporterUser = user;
  }

  return { transporter, from: user };
}

export type MailOptions = {
  subject: string;
  text: string;
  to: string[];
};

export async function sendMail(options: MailOptions): Promise<boolean> {
  const target = getTransporter();
  if (!target) {
    console.error(
      "E-posta gonderilemedi: GMAIL_USER / GMAIL_APP_PASSWORD .env.local icinde tanimli degil.",
    );
    return false;
  }

  try {
    await target.transporter.sendMail({
      from: `Mefa Group İhale Takip <${target.from}>`,
      subject: options.subject,
      text: options.text,
      to: options.to.join(", "),
    });
    return true;
  } catch (err) {
    console.error("E-posta gonderme hatasi:", err);
    return false;
  }
}
