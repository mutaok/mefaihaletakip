"use client";

import { useState } from "react";
import { createPortal } from "react-dom";
import { Plus, X } from "lucide-react";

import { createGuaranteeLetterAction } from "@/app/actions";
import { SubmitButton } from "@/components/submit-button";

const inputCls =
  "w-full rounded-xl border border-line bg-white px-3.5 py-2.5 text-sm text-foreground outline-none transition focus:border-accent focus:ring-2 focus:ring-accent/15";

const labelCls =
  "mb-1.5 block text-xs font-semibold uppercase tracking-wide text-muted";

function Field({
  label,
  name,
  placeholder,
}: {
  label: string;
  name: string;
  placeholder?: string;
}) {
  return (
    <label className="block">
      <span className={labelCls}>
        {label}
        <span className="ml-1 text-rose-500">*</span>
      </span>
      <input
        name={name}
        type="text"
        placeholder={placeholder}
        required
        className={inputCls}
      />
    </label>
  );
}

export function GuaranteeLetterCreateDialog({ disabled }: { disabled?: boolean }) {
  const [open, setOpen] = useState(false);
  const [fileName, setFileName] = useState<string | null>(null);

  return (
    <>
      <button
        type="button"
        onClick={() => setOpen(true)}
        disabled={disabled}
        className="inline-flex items-center gap-2 rounded-xl bg-accent px-5 py-2.5 text-sm font-semibold text-white transition hover:bg-accent/90 disabled:cursor-not-allowed disabled:opacity-50"
      >
        <Plus className="size-4" />
        Yeni Teminat Mektubu Ekle
      </button>

      {open &&
        createPortal(
          <div className="fixed inset-0 z-50 overflow-y-auto" role="dialog" aria-modal="true">
            <div
              className="fixed inset-0 bg-black/50 backdrop-blur-sm"
              onClick={() => setOpen(false)}
            />

            <div className="relative mx-auto my-6 w-full max-w-lg px-4">
              <div className="overflow-hidden rounded-3xl bg-white shadow-2xl">
                <div className="flex items-center justify-between border-b border-line px-8 py-5">
                  <h2 className="text-xl font-bold tracking-tight text-foreground">
                    Yeni Teminat Mektubu
                  </h2>
                  <button
                    type="button"
                    onClick={() => setOpen(false)}
                    className="grid size-9 place-items-center rounded-full border border-line text-muted transition hover:bg-line"
                  >
                    <X className="size-4" />
                  </button>
                </div>

                <form
                  action={createGuaranteeLetterAction}
                  encType="multipart/form-data"
                >
                  <div className="space-y-5 p-8">
                    <div>
                      <span className={labelCls}>
                        Teminat Mektubu Türü<span className="ml-1 text-rose-500">*</span>
                      </span>
                      <div className="flex gap-5">
                        {(
                          [
                            { value: "gecici", text: "Geçici Teminat" },
                            { value: "kesin", text: "Kesin Teminat" },
                          ] as const
                        ).map(({ value, text }, i) => (
                          <label key={value} className="flex cursor-pointer items-center gap-2">
                            <input
                              type="radio"
                              name="letterType"
                              value={value}
                              defaultChecked={i === 0}
                              className="accent-accent"
                            />
                            <span className="text-sm text-foreground">{text}</span>
                          </label>
                        ))}
                      </div>
                    </div>
                    <Field
                      label="Hangi Bankadan Alındı"
                      name="bankName"
                      placeholder="Örn: Ziraat Bankası"
                    />
                    <Field
                      label="Tutar"
                      name="amount"
                      placeholder="Örn: 500.000 TL"
                    />
                    <Field
                      label="Hangi İdareye Sunuldu"
                      name="authority"
                      placeholder="Kurum adı"
                    />
                    <Field
                      label="Hangi İş İçin Sunuldu"
                      name="jobDescription"
                      placeholder="İhale / iş konusu"
                    />

                    <label className="block">
                      <span className={labelCls}>
                        PDF Dosyası<span className="ml-1 text-rose-500">*</span>
                      </span>
                      <div className="flex items-center gap-3 rounded-xl border border-dashed border-accent/40 bg-accent/5 px-4 py-3">
                        <input
                          name="file"
                          type="file"
                          accept="application/pdf,.pdf"
                          required
                          onChange={(e) => setFileName(e.target.files?.[0]?.name ?? null)}
                          className="w-full text-sm text-foreground file:mr-3 file:rounded-lg file:border-0 file:bg-accent file:px-3 file:py-1.5 file:text-xs file:font-semibold file:text-white"
                        />
                      </div>
                      {fileName && (
                        <p className="mt-1.5 truncate text-xs text-muted">{fileName}</p>
                      )}
                    </label>
                  </div>

                  <div className="flex items-center justify-end gap-3 border-t border-line px-8 py-5">
                    <button
                      type="button"
                      onClick={() => setOpen(false)}
                      className="rounded-xl border border-line px-5 py-2.5 text-sm font-semibold text-foreground transition hover:bg-line/30"
                    >
                      İptal
                    </button>
                    <SubmitButton
                      className="rounded-xl bg-accent px-6 py-2.5 text-sm font-semibold text-white transition hover:bg-accent/90 disabled:opacity-70"
                      pendingLabel="Yükleniyor..."
                    >
                      Kaydet
                    </SubmitButton>
                  </div>
                </form>
              </div>
            </div>
          </div>,
          document.body,
        )}
    </>
  );
}
