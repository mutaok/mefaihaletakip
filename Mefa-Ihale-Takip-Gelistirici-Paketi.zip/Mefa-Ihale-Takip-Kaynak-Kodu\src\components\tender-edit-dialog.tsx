"use client";

import { useState } from "react";
import { createPortal } from "react-dom";
import { Pencil, Plus, X } from "lucide-react";

import { updateTenderAction } from "@/app/actions";
import { SubmitButton } from "@/components/submit-button";
import type { TenderDetail } from "@/lib/tenders";

type StaffRow = {
  quantity: string;
  position: string;
  requirements: string;
  other: string;
};

const emptyRow = (): StaffRow => ({
  quantity: "",
  position: "",
  requirements: "",
  other: "",
});

function boolToRadio(val: boolean | null): string {
  if (val === true) return "yes";
  if (val === false) return "no";
  return "";
}

const inputCls =
  "w-full rounded-xl border border-line bg-white px-3.5 py-2.5 text-sm text-foreground outline-none transition focus:border-accent focus:ring-2 focus:ring-accent/15";

const textareaCls =
  "w-full rounded-xl border border-line bg-white px-3.5 py-2.5 text-sm text-foreground outline-none transition focus:border-accent focus:ring-2 focus:ring-accent/15 resize-y min-h-[80px]";

const labelCls =
  "mb-1.5 block text-xs font-semibold uppercase tracking-wide text-muted";

function Field({
  label,
  name,
  type = "text",
  placeholder,
  required,
  defaultValue,
}: {
  label: string;
  name: string;
  type?: string;
  placeholder?: string;
  required?: boolean;
  defaultValue?: string;
}) {
  return (
    <label className="block">
      <span className={labelCls}>
        {label}
        {required && <span className="ml-1 text-rose-500">*</span>}
      </span>
      <input
        name={name}
        type={type}
        placeholder={placeholder}
        required={required}
        defaultValue={defaultValue ?? ""}
        className={inputCls}
      />
    </label>
  );
}

function TextareaField({
  label,
  name,
  placeholder,
  defaultValue,
}: {
  label: string;
  name: string;
  placeholder?: string;
  defaultValue?: string | null;
}) {
  return (
    <label className="block">
      <span className={labelCls}>{label}</span>
      <textarea
        name={name}
        placeholder={placeholder}
        defaultValue={defaultValue ?? ""}
        className={textareaCls}
      />
    </label>
  );
}

function YesNoField({
  label,
  name,
  defaultValue,
}: {
  label: string;
  name: string;
  defaultValue: string;
}) {
  return (
    <div>
      <span className={labelCls}>{label}</span>
      <div className="flex gap-5">
        {(
          [
            { value: "yes", text: "Evet" },
            { value: "no", text: "Hayır" },
            { value: "", text: "Belirtilmedi" },
          ] as const
        ).map(({ value, text }) => (
          <label key={value} className="flex cursor-pointer items-center gap-2">
            <input
              type="radio"
              name={name}
              value={value}
              defaultChecked={value === defaultValue}
              className="accent-accent"
            />
            <span className="text-sm text-foreground">{text}</span>
          </label>
        ))}
      </div>
    </div>
  );
}

function SectionHeading({ num, title }: { num: number; title: string }) {
  return (
    <div className="flex items-center gap-3">
      <span className="grid size-8 flex-shrink-0 place-items-center rounded-full bg-accent text-sm font-bold text-white">
        {num}
      </span>
      <h3 className="text-base font-semibold text-foreground">{title}</h3>
    </div>
  );
}

export function TenderEditDialog({ tender }: { tender: TenderDetail }) {
  const { details } = tender;

  const initialStaff: StaffRow[] =
    details.technicalStaff.length > 0
      ? details.technicalStaff.map((s) => ({
          quantity: s.quantity,
          position: s.position,
          requirements: s.requirements,
          other: s.other,
        }))
      : [emptyRow()];

  const [open, setOpen] = useState(false);
  const [staff, setStaff] = useState<StaffRow[]>(initialStaff);

  const addRow = () => setStaff((prev) => [...prev, emptyRow()]);
  const removeRow = (i: number) =>
    setStaff((prev) => prev.filter((_, idx) => idx !== i));
  const updateRow = (i: number, field: keyof StaffRow, val: string) =>
    setStaff((prev) => {
      const next = [...prev];
      next[i] = { ...next[i], [field]: val };
      return next;
    });

  return (
    <>
      <button
        onClick={() => setOpen(true)}
        className="inline-flex items-center gap-2 rounded-xl border border-accent/30 bg-accent/10 px-4 py-2 text-sm font-semibold text-accent transition hover:bg-accent/20"
      >
        <Pencil className="size-4" /> Düzenle
      </button>

      {open && createPortal(
        <div className="fixed inset-0 z-50 overflow-y-auto" role="dialog" aria-modal="true">
          <div
            className="fixed inset-0 bg-black/50 backdrop-blur-sm"
            onClick={() => setOpen(false)}
          />

          <div className="relative mx-auto my-6 w-full max-w-3xl px-4">
            <div className="overflow-hidden rounded-3xl bg-white shadow-2xl">
              {/* Header */}
              <div className="flex items-center justify-between border-b border-line px-8 py-5">
                <h2 className="text-xl font-bold tracking-tight text-foreground">
                  İhale Bilgilerini Düzenle
                </h2>
                <button
                  type="button"
                  onClick={() => setOpen(false)}
                  className="grid size-9 place-items-center rounded-full border border-line text-muted transition hover:bg-line"
                >
                  <X className="size-4" />
                </button>
              </div>

              <form action={updateTenderAction}>
                <input type="hidden" name="tenderId" value={tender.id} />
                <input
                  type="hidden"
                  name="technicalStaffJson"
                  value={JSON.stringify(staff)}
                />

                <div className="max-h-[70vh] space-y-8 overflow-y-auto p-8">
                  {/* ── Section 1 ── */}
                  <section className="space-y-4">
                    <SectionHeading num={1} title="İhale Temel Bilgileri" />
                    <div className="grid gap-4 sm:grid-cols-2">
                      <Field
                        label="İdare Adı"
                        name="authority"
                        placeholder="Kurum adı"
                        defaultValue={tender.authority ?? ""}
                      />
                      <Field
                        label="İşin Adı"
                        name="title"
                        placeholder="İhale konusu"
                        required
                        defaultValue={tender.title}
                      />
                    </div>
                    <div className="grid gap-4 sm:grid-cols-2">
                      <Field
                        label="İhale Kayıt Numarası"
                        name="referenceCode"
                        placeholder="Örn: 2024/123456"
                        defaultValue={tender.referenceCode ?? ""}
                      />
                      <Field
                        label="İhaleye Katılım Usulü"
                        name="participationMethod"
                        placeholder="Açık ihale / Belli istekliler"
                        defaultValue={details.participationMethod ?? ""}
                      />
                    </div>
                    <div className="grid gap-4 sm:grid-cols-2">
                      <Field
                        label="İhale Tarihi"
                        name="tenderDate"
                        type="date"
                        defaultValue={tender.tenderDate ?? ""}
                      />
                      <Field
                        label="İşin Süresi"
                        name="deliveryDuration"
                        placeholder="Örn: 180 takvim günü"
                        defaultValue={details.deliveryDuration ?? ""}
                      />
                    </div>
                    <Field
                      label="Hangi Şirketimiz İle Gireceğiz"
                      name="company"
                      placeholder="Örn: MEFA İnşaat A.Ş."
                      defaultValue={details.company ?? ""}
                    />
                  </section>

                  <hr className="border-line" />

                  {/* ── Section 2 ── */}
                  <section className="space-y-4">
                    <SectionHeading num={2} title="Teklif Yapısı" />
                    <div className="grid gap-4 sm:grid-cols-2">
                      <Field
                        label="Teslim Usulü"
                        name="submissionMethod"
                        placeholder="Anahtar teslim / Birim fiyat"
                        defaultValue={details.submissionMethod ?? ""}
                      />
                      <Field
                        label="Para Birimi"
                        name="currency"
                        placeholder="TL / USD / EUR"
                        defaultValue={details.currency ?? ""}
                      />
                    </div>
                  </section>

                  <hr className="border-line" />

                  {/* ── Section 3 ── */}
                  <section className="space-y-4">
                    <SectionHeading num={3} title="Teminatlar" />
                    <div className="grid gap-4 sm:grid-cols-2">
                      <Field
                        label="Geçici Teminat"
                        name="temporaryGuarantee"
                        placeholder="Örn: %3"
                        defaultValue={details.temporaryGuarantee ?? ""}
                      />
                      <Field
                        label="Kesin Teminat"
                        name="finalGuarantee"
                        placeholder="Örn: %6"
                        defaultValue={details.finalGuarantee ?? ""}
                      />
                    </div>
                    <YesNoField
                      label="Banka Referans Mektubu İstiyor mu?"
                      name="requiresBankReference"
                      defaultValue={boolToRadio(details.requiresBankReference)}
                    />
                  </section>

                  <hr className="border-line" />

                  {/* ── Section 4 ── */}
                  <section className="space-y-4">
                    <SectionHeading num={4} title="Fiyat Farkı" />
                    <TextareaField
                      label="Fiyat Farkı Koşulları"
                      name="priceDifference"
                      placeholder="Fiyat farkı uygulanacak mı? Koşullar..."
                      defaultValue={details.priceDifference}
                    />
                  </section>

                  <hr className="border-line" />

                  {/* ── Section 5 ── */}
                  <section className="space-y-4">
                    <SectionHeading num={5} title="Avans" />
                    <YesNoField
                      label="Avans Veriliyor mu?"
                      name="advancePayment"
                      defaultValue={boolToRadio(details.advancePayment)}
                    />
                    <Field
                      label="Avans Oranı veya Tutarı"
                      name="advanceAmount"
                      placeholder="Örn: %10 veya 500.000 TL"
                      defaultValue={details.advanceAmount ?? ""}
                    />
                  </section>

                  <hr className="border-line" />

                  {/* ── Section 6 ── */}
                  <section className="space-y-4">
                    <SectionHeading num={6} title="İşin Süresi" />
                    <Field
                      label="İş Süresi"
                      name="workDuration"
                      placeholder="Örn: 365 takvim günü"
                      defaultValue={details.workDuration ?? ""}
                    />
                  </section>

                  <hr className="border-line" />

                  {/* ── Section 7 ── */}
                  <section className="space-y-4">
                    <SectionHeading num={7} title="Teknik Personel Zorunluluğu" />
                    <div className="overflow-x-auto rounded-xl border border-line">
                      <table className="w-full text-sm">
                        <thead>
                          <tr className="bg-line/30">
                            <th className="w-20 px-3 py-2.5 text-left text-xs font-semibold uppercase tracking-wide text-muted">
                              Adet
                            </th>
                            <th className="px-3 py-2.5 text-left text-xs font-semibold uppercase tracking-wide text-muted">
                              Mesleki Pozisyon
                            </th>
                            <th className="px-3 py-2.5 text-left text-xs font-semibold uppercase tracking-wide text-muted">
                              Mesleki Şartlar
                            </th>
                            <th className="px-3 py-2.5 text-left text-xs font-semibold uppercase tracking-wide text-muted">
                              Diğer
                            </th>
                            <th className="w-8" />
                          </tr>
                        </thead>
                        <tbody>
                          {staff.map((row, i) => (
                            <tr key={i} className="border-t border-line">
                              <td className="p-1.5">
                                <input
                                  value={row.quantity}
                                  onChange={(e) => updateRow(i, "quantity", e.target.value)}
                                  placeholder="1"
                                  className="w-full rounded-lg border border-line px-2.5 py-1.5 text-sm outline-none focus:border-accent"
                                />
                              </td>
                              <td className="p-1.5">
                                <input
                                  value={row.position}
                                  onChange={(e) => updateRow(i, "position", e.target.value)}
                                  placeholder="İnşaat Mühendisi"
                                  className="w-full rounded-lg border border-line px-2.5 py-1.5 text-sm outline-none focus:border-accent"
                                />
                              </td>
                              <td className="p-1.5">
                                <input
                                  value={row.requirements}
                                  onChange={(e) => updateRow(i, "requirements", e.target.value)}
                                  placeholder="En az 5 yıl deneyim"
                                  className="w-full rounded-lg border border-line px-2.5 py-1.5 text-sm outline-none focus:border-accent"
                                />
                              </td>
                              <td className="p-1.5">
                                <input
                                  value={row.other}
                                  onChange={(e) => updateRow(i, "other", e.target.value)}
                                  placeholder=""
                                  className="w-full rounded-lg border border-line px-2.5 py-1.5 text-sm outline-none focus:border-accent"
                                />
                              </td>
                              <td className="p-1.5">
                                {staff.length > 1 && (
                                  <button
                                    type="button"
                                    onClick={() => removeRow(i)}
                                    className="grid size-7 place-items-center rounded-lg text-muted transition hover:bg-rose-50 hover:text-rose-600"
                                  >
                                    <X className="size-3.5" />
                                  </button>
                                )}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                    <button
                      type="button"
                      onClick={addRow}
                      className="inline-flex items-center gap-2 rounded-xl border border-dashed border-accent/40 px-4 py-2 text-sm font-medium text-accent transition hover:border-accent hover:bg-accent/5"
                    >
                      <Plus className="size-4" />
                      Satır Ekle
                    </button>
                  </section>

                  <hr className="border-line" />

                  {/* ── Section 8 ── */}
                  <section className="space-y-4">
                    <SectionHeading num={8} title="Diğer Hususlar" />
                    <TextareaField
                      label="Notlar ve Özel Koşullar"
                      name="otherNotes"
                      placeholder="Önemli notlar, şartlar, özel koşullar..."
                      defaultValue={details.otherNotes}
                    />
                  </section>
                </div>

                {/* Footer */}
                <div className="flex items-center justify-end gap-3 border-t border-line px-8 py-5">
                  <button
                    type="button"
                    onClick={() => setOpen(false)}
                    className="rounded-xl border border-line px-5 py-2.5 text-sm font-semibold text-foreground transition hover:bg-line/30"
                  >
                    İptal
                  </button>
                  <SubmitButton
                    className="rounded-xl bg-accent px-6 py-2.5 text-sm font-semibold text-white transition hover:bg-accent/90 disabled:opacity-70"
                    pendingLabel="Kaydediliyor..."
                  >
                    Kaydet
                  </SubmitButton>
                </div>
              </form>
            </div>
          </div>
        </div>
      , document.body)}
    </>
  );
}
