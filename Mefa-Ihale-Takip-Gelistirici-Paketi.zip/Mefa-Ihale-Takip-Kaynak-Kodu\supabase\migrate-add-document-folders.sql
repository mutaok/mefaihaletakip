create table if not exists public.tender_document_folders (
  id uuid primary key default gen_random_uuid(),
  tender_id uuid not null references public.tender_folders (id) on delete cascade,
  name text not null,
  created_at timestamptz not null default timezone('utc', now()),
  unique (tender_id, name)
);

alter table public.tender_documents
  add column if not exists folder_id uuid references public.tender_document_folders (id) on delete set null;

create index if not exists tender_document_folders_tender_id_idx
  on public.tender_document_folders (tender_id, created_at desc);

create index if not exists tender_documents_folder_id_idx
  on public.tender_documents (folder_id);

alter table public.tender_document_folders enable row level security;

drop policy if exists "Anyone can read tender document folders" on public.tender_document_folders;
create policy "Anyone can read tender document folders"
  on public.tender_document_folders for select
  using (true);

drop policy if exists "Service role manages tender document folders" on public.tender_document_folders;
create policy "Service role manages tender document folders"
  on public.tender_document_folders for all
  using (true)
  with check (true);
