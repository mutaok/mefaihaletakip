import Link from "next/link";

export type StatCardLegendRow = {
  dotClass: string;
  label: string;
  value: string;
};

export function DashboardStatCard({
  href,
  legend,
  subtitle,
  title,
  value,
}: {
  href: string;
  legend: StatCardLegendRow[];
  subtitle: string;
  title: string;
  value: number;
}) {
  return (
    <Link
      href={href}
      className="flex flex-col rounded-2xl bg-white p-6 shadow-[0_2px_16px_rgba(21,54,50,0.07)] transition-shadow hover:shadow-[0_4px_24px_rgba(21,54,50,0.12)]"
    >
      <div className="flex flex-1 flex-col items-center justify-center py-4 text-center">
        <div className="text-6xl font-semibold tracking-tight text-emerald-500">
          {value}
        </div>
        <div className="mt-3 text-lg font-bold text-foreground">{title}</div>
        <div className="mt-1 text-sm text-muted">{subtitle}</div>
      </div>
      <div className="mt-4 space-y-2.5 border-t border-line pt-4">
        {legend.map((row) => (
          <div
            key={row.label}
            className="flex items-center justify-between text-[13px]"
          >
            <span className="flex items-center gap-2 text-muted">
              <span className={`size-2 rounded-full ${row.dotClass}`} />
              {row.label}
            </span>
            <span className="font-medium text-foreground/80">{row.value}</span>
          </div>
        ))}
      </div>
    </Link>
  );
}
