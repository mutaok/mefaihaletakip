-- Mevcut tender_folders tablosuna il ve ilce kolonlarini ekler.
-- Eger tablo yeni olustuysa bu script'e gerek yoktur (schema.sql zaten iceriyor).

ALTER TABLE public.tender_folders ADD COLUMN IF NOT EXISTS il text;
ALTER TABLE public.tender_folders ADD COLUMN IF NOT EXISTS ilce text;

-- Mevcut satirlar varsa il'i location_name'den doldur (fallback)
UPDATE public.tender_folders SET il = COALESCE(location_name, 'Istanbul') WHERE il IS NULL;

-- Artik il zorunlu olsun
ALTER TABLE public.tender_folders ALTER COLUMN il SET NOT NULL;
