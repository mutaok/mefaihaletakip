import "server-only";

import { createSign } from "node:crypto";

function base64url(input: Buffer | string): string {
  const buf = typeof input === "string" ? Buffer.from(input) : input;
  return buf.toString("base64").replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

function getServiceAccountConfig() {
  const email = process.env.GOOGLE_SERVICE_ACCOUNT_EMAIL?.trim();
  const rawKey = process.env.GOOGLE_SERVICE_ACCOUNT_PRIVATE_KEY?.trim();
  const calendarId = process.env.GOOGLE_CALENDAR_ID?.trim() || "primary";
  if (!email || !rawKey) return null;
  return { email, privateKey: rawKey.replace(/\\n/g, "\n"), calendarId };
}

let cachedToken: { token: string; expiresAt: number } | null = null;

async function getAccessToken(): Promise<string | null> {
  const config = getServiceAccountConfig();
  if (!config) return null;

  if (cachedToken && cachedToken.expiresAt > Date.now() + 60_000) {
    return cachedToken.token;
  }

  const now = Math.floor(Date.now() / 1000);
  const header = { alg: "RS256", typ: "JWT" };
  const claims = {
    aud: "https://oauth2.googleapis.com/token",
    exp: now + 3600,
    iat: now,
    iss: config.email,
    scope: "https://www.googleapis.com/auth/calendar",
  };

  const unsigned = `${base64url(JSON.stringify(header))}.${base64url(JSON.stringify(claims))}`;
  const signer = createSign("RSA-SHA256");
  signer.update(unsigned);
  signer.end();
  const signature = base64url(signer.sign(config.privateKey));
  const jwt = `${unsigned}.${signature}`;

  try {
    const res = await fetch("https://oauth2.googleapis.com/token", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        assertion: jwt,
        grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer",
      }),
    });
    if (!res.ok) {
      console.error("Google Calendar: erisim tokeni alinamadi:", await res.text());
      return null;
    }
    const data = (await res.json()) as { access_token: string; expires_in: number };
    cachedToken = { expiresAt: Date.now() + data.expires_in * 1000, token: data.access_token };
    return cachedToken.token;
  } catch (err) {
    console.error("Google Calendar: token istegi basarisiz:", err);
    return null;
  }
}

export type CalendarEventInput = {
  /** Google'ın izin verdiği karakter kümesiyle sınırlı özel etkinlik kimliği (bkz. *CalendarEventId yardımcıları) */
  id: string;
  title: string;
  description?: string;
  /** YYYY-MM-DD — tüm gün etkinliği olarak eklenir */
  date: string;
};

function eventBody(input: CalendarEventInput) {
  // Google "tüm gün" etkinliklerinde end.date, start.date'ten bir gün sonra (dışlayıcı) olmalı.
  const endDate = new Date(`${input.date}T00:00:00`);
  endDate.setDate(endDate.getDate() + 1);

  return {
    description: input.description,
    end: { date: endDate.toISOString().slice(0, 10) },
    id: input.id,
    start: { date: input.date },
    summary: input.title,
  };
}

/**
 * Verilen kimlikle bir etkinlik ekler; zaten varsa (409) günceller.
 * Yapılandırma eksikse veya istek başarısız olursa sessizce döner — bu senkronizasyon
 * hiçbir zaman asıl kaydetme işlemini engellememelidir.
 */
export async function upsertCalendarEvent(input: CalendarEventInput): Promise<void> {
  const config = getServiceAccountConfig();
  const token = await getAccessToken();
  if (!config || !token) return;

  const base = `https://www.googleapis.com/calendar/v3/calendars/${encodeURIComponent(config.calendarId)}/events`;
  const headers = { "Content-Type": "application/json", Authorization: `Bearer ${token}` };
  const body = JSON.stringify(eventBody(input));

  try {
    const insertRes = await fetch(base, { body, headers, method: "POST" });
    if (insertRes.ok) return;
    if (insertRes.status === 409) {
      const updateRes = await fetch(`${base}/${input.id}`, { body, headers, method: "PUT" });
      if (!updateRes.ok) {
        console.error("Google Calendar: etkinlik guncellenemedi:", await updateRes.text());
      }
      return;
    }
    console.error("Google Calendar: etkinlik eklenemedi:", await insertRes.text());
  } catch (err) {
    console.error("Google Calendar: istek basarisiz:", err);
  }
}

export async function deleteCalendarEvent(id: string): Promise<void> {
  const config = getServiceAccountConfig();
  const token = await getAccessToken();
  if (!config || !token) return;

  const url = `https://www.googleapis.com/calendar/v3/calendars/${encodeURIComponent(config.calendarId)}/events/${id}`;
  try {
    const res = await fetch(url, { headers: { Authorization: `Bearer ${token}` }, method: "DELETE" });
    if (!res.ok && res.status !== 404 && res.status !== 410) {
      console.error("Google Calendar: etkinlik silinemedi:", await res.text());
    }
  } catch (err) {
    console.error("Google Calendar: silme istegi basarisiz:", err);
  }
}

/** UUID'deki tireleri kaldırır — sonuç Google'ın izin verdiği [a-v0-9] kümesiyle uyumludur. */
export function tenderCalendarEventId(tenderId: string): string {
  return `tdr${tenderId.replace(/-/g, "")}`;
}

export function taskCalendarEventId(taskId: string): string {
  return `tsk${taskId.replace(/-/g, "")}`;
}
