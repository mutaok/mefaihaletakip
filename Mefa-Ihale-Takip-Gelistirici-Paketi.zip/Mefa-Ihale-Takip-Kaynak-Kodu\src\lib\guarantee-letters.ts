import "server-only";

import type { Database } from "@/lib/supabase/database.types";
import { readStorageJson, writeStorageJson } from "@/lib/storage-kv";
import {
  createSupabaseAdminClient,
  isSupabaseConfigured,
} from "@/lib/supabase/server";

type GuaranteeLetterRow = Database["public"]["Tables"]["guarantee_letters"]["Row"];

export type GuaranteeLetterType = "gecici" | "kesin";

function normalizeLetterType(value: string): GuaranteeLetterType {
  return value === "kesin" ? "kesin" : "gecici";
}

export type GuaranteeLetter = {
  amount: string;
  authority: string;
  bankName: string;
  createdAt: string;
  /** İade edilmemişse mektubun kaç gündür açık olduğu */
  daysOutstanding: number;
  fileSize: number | null;
  id: string;
  jobDescription: string;
  letterType: GuaranteeLetterType;
  originalFilename: string;
  /** İade edildiyse ISO tarih; edilmediyse null */
  returnedAt: string | null;
  storagePath: string;
};

export type GuaranteeLettersResult = {
  activeCount: number;
  dataError: string | null;
  geciciCount: number;
  isConfigured: boolean;
  kesinCount: number;
  letters: GuaranteeLetter[];
  returnedCount: number;
};

const RETURNS_PATH = "_meta/guarantee-letter-returns.json";

type ReturnsMap = Record<string, string>;

/**
 * İade durumu, şema değişikliği gerektirmemek için Storage'daki küçük bir
 * JSON dosyasında tutulur: { [letterId]: iadeTarihiISO }
 */
export async function fetchGuaranteeLetterReturns(): Promise<ReturnsMap> {
  const parsed = await readStorageJson<Record<string, unknown>>(RETURNS_PATH, {});
  const map: ReturnsMap = {};
  for (const [key, value] of Object.entries(parsed)) {
    if (typeof value === "string" && value) map[key] = value;
  }
  return map;
}

export async function saveGuaranteeLetterReturns(returns: ReturnsMap): Promise<boolean> {
  return writeStorageJson(RETURNS_PATH, returns);
}

function daysSince(isoDate: string): number {
  const start = new Date(isoDate).getTime();
  if (Number.isNaN(start)) return 0;
  const diff = Date.now() - start;
  return Math.max(0, Math.floor(diff / (24 * 60 * 60 * 1000)));
}

function mapGuaranteeLetter(
  row: GuaranteeLetterRow,
  returns: ReturnsMap,
): GuaranteeLetter {
  return {
    amount: row.amount,
    authority: row.authority,
    bankName: row.bank_name,
    createdAt: row.created_at,
    daysOutstanding: daysSince(row.created_at),
    fileSize: row.file_size,
    id: row.id,
    jobDescription: row.job_description,
    letterType: normalizeLetterType(row.letter_type),
    originalFilename: row.original_filename,
    returnedAt: returns[row.id] ?? null,
    storagePath: row.storage_path,
  };
}

export async function getGuaranteeLetters(): Promise<GuaranteeLettersResult> {
  const empty: GuaranteeLettersResult = {
    activeCount: 0,
    dataError: null,
    geciciCount: 0,
    isConfigured: false,
    kesinCount: 0,
    letters: [],
    returnedCount: 0,
  };

  if (!isSupabaseConfigured()) return empty;

  const supabase = createSupabaseAdminClient();
  if (!supabase) return empty;

  const [{ data, error }, returns] = await Promise.all([
    supabase
      .from("guarantee_letters")
      .select(
        "id, bank_name, amount, authority, job_description, letter_type, storage_path, original_filename, file_size, created_at",
      )
      .order("created_at", { ascending: false }),
    fetchGuaranteeLetterReturns(),
  ]);

  if (error) {
    return { ...empty, dataError: error.message, isConfigured: true };
  }

  const letters = (data ?? []).map((row) => mapGuaranteeLetter(row, returns));
  const active = letters.filter((letter) => !letter.returnedAt);

  return {
    activeCount: active.length,
    dataError: null,
    geciciCount: active.filter((letter) => letter.letterType === "gecici").length,
    isConfigured: true,
    kesinCount: active.filter((letter) => letter.letterType === "kesin").length,
    letters,
    returnedCount: letters.length - active.length,
  };
}
