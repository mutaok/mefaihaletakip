import "server-only";

import { formatDate, todayDateKey } from "@/lib/format";
import { sendMail } from "@/lib/mailer";
import { readStorageJson, writeStorageJson } from "@/lib/storage-kv";
import { getTasks, type Task } from "@/lib/tasks";

const STATE_PATH = "_meta/reminder-state.json";
const RECIPIENTS = ["tahaoktar@gmail.com", "recepbakir@mefagroup.com"];
const THRESHOLDS = [15, 7, 3] as const;
type Threshold = (typeof THRESHOLDS)[number];

type TaskReminderRecord = {
  /** Hatırlatıcı takibi hangi son tarih için hesaplandı; tarih değişirse sıfırlanır. */
  dueDate: string;
  sent: Partial<Record<Threshold, boolean>>;
};

type ReminderState = {
  lastWeeklySummaryWeek: string | null;
  taskReminders: Record<string, TaskReminderRecord>;
};

const EMPTY_STATE: ReminderState = { lastWeeklySummaryWeek: null, taskReminders: {} };

function daysBetween(fromKey: string, toKey: string): number {
  const from = new Date(`${fromKey}T00:00:00`);
  const to = new Date(`${toKey}T00:00:00`);
  return Math.round((to.getTime() - from.getTime()) / 86_400_000);
}

/** ISO 8601 hafta anahtarı (ör. "2026-W30") — Pazartesi 09:00 özetinin haftada bir gitmesini garantiler. */
function isoWeekKey(date: Date): string {
  const d = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
  const dayNum = (d.getUTCDay() + 6) % 7;
  d.setUTCDate(d.getUTCDate() - dayNum + 3);
  const firstThursday = new Date(Date.UTC(d.getUTCFullYear(), 0, 4));
  const weekNum =
    1 +
    Math.round(
      ((d.getTime() - firstThursday.getTime()) / 86_400_000 -
        3 +
        ((firstThursday.getUTCDay() + 6) % 7)) /
        7,
    );
  return `${d.getUTCFullYear()}-W${String(weekNum).padStart(2, "0")}`;
}

async function sendWeeklySummary(tasks: Task[]): Promise<void> {
  const sorted = [...tasks].sort((a, b) => a.dueDate.localeCompare(b.dueDate));
  const body = sorted.length
    ? sorted.map((t) => `• ${t.title} — Son tarih: ${formatDate(t.dueDate)}`).join("\n")
    : "Şu anda açık görev bulunmuyor.";

  await sendMail({
    to: RECIPIENTS,
    subject: `Haftalık Görev Özeti — ${sorted.length} açık görev`,
    text: `Merhaba,\n\nOperasyonel Takvim Ve Ajanda'daki açık görevleriniz:\n\n${body}\n\nMefa Group İhale Takip`,
  });
}

async function sendTaskThresholdReminder(task: Task, daysLeft: number): Promise<void> {
  const gunIfade = daysLeft <= 0 ? "bugün doluyor" : `için ${daysLeft} gün kaldı`;
  await sendMail({
    to: RECIPIENTS,
    subject: `Hatırlatma: "${task.title}" ${gunIfade}`,
    text: `Merhaba,\n\n"${task.title}" görevinin son tarihi ${formatDate(task.dueDate)} — ${gunIfade}.\n\nMefa Group İhale Takip`,
  });
}

/**
 * Uygulama açılışında ve açıkken saatlik çağrılır. Pazartesi 09:00'dan sonra
 * (o hafta için) haftalık özet, ve her görev için son tarihine 15/7/3 gün
 * kala (her eşik yalnızca bir kez) hatırlatıcı e-postası gönderir.
 * Uygulama tam o saatte kapalıysa, sonraki kontrolde "kaçırılanı" gönderir.
 */
export async function runReminderCheck(): Promise<void> {
  const now = new Date();
  const todayKey = todayDateKey();
  const state = await readStorageJson<ReminderState>(STATE_PATH, EMPTY_STATE);
  let changed = false;

  const { activeTasks } = await getTasks();

  const isMonday = now.getDay() === 1;
  const weekKey = isoWeekKey(now);
  if (isMonday && now.getHours() >= 9 && state.lastWeeklySummaryWeek !== weekKey) {
    await sendWeeklySummary(activeTasks);
    state.lastWeeklySummaryWeek = weekKey;
    changed = true;
  }

  const activeIds = new Set(activeTasks.map((t) => t.id));
  for (const taskId of Object.keys(state.taskReminders)) {
    if (!activeIds.has(taskId)) {
      delete state.taskReminders[taskId];
      changed = true;
    }
  }

  for (const task of activeTasks) {
    let record = state.taskReminders[task.id];
    if (!record || record.dueDate !== task.dueDate) {
      record = { dueDate: task.dueDate, sent: {} };
    }

    const daysLeft = daysBetween(todayKey, task.dueDate);
    let taskChanged = !state.taskReminders[task.id] || state.taskReminders[task.id].dueDate !== task.dueDate;

    for (const threshold of THRESHOLDS) {
      const lowerBound = threshold === 15 ? 8 : threshold === 7 ? 4 : 0;
      if (!record.sent[threshold] && daysLeft <= threshold && daysLeft >= lowerBound) {
        await sendTaskThresholdReminder(task, daysLeft);
        record.sent[threshold] = true;
        taskChanged = true;
      }
    }

    if (taskChanged) {
      state.taskReminders[task.id] = record;
      changed = true;
    }
  }

  if (changed) {
    await writeStorageJson(STATE_PATH, state);
  }
}
