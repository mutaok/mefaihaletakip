"use client";

import { useState } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";

export type DashboardCalendarEvent = {
  date: string; // YYYY-MM-DD
  label: string;
  kind: "tender" | "task";
};

const DOT_CLASS: Record<DashboardCalendarEvent["kind"], string> = {
  tender: "bg-accent",
  task: "bg-amber-500",
};

const WEEKDAYS = ["Pzt", "Sal", "Çar", "Per", "Cum", "Cmt", "Paz"];

const MONTH_FORMAT = new Intl.DateTimeFormat("tr-TR", {
  month: "long",
  year: "numeric",
});

function toDateKey(date: Date): string {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, "0");
  const d = String(date.getDate()).padStart(2, "0");
  return `${y}-${m}-${d}`;
}

export function DashboardCalendar({
  events,
}: {
  events: DashboardCalendarEvent[];
}) {
  const [month, setMonth] = useState(() => {
    const now = new Date();
    return new Date(now.getFullYear(), now.getMonth(), 1);
  });

  const todayKey = toDateKey(new Date());
  const eventsByDay = new Map<string, DashboardCalendarEvent[]>();
  for (const event of events) {
    const list = eventsByDay.get(event.date) ?? [];
    list.push(event);
    eventsByDay.set(event.date, list);
  }

  const daysInMonth = new Date(month.getFullYear(), month.getMonth() + 1, 0).getDate();
  // Pazartesi başlangıçlı ofset
  const firstDayOffset = (month.getDay() + 6) % 7;
  const cells: (number | null)[] = [
    ...Array.from({ length: firstDayOffset }, () => null),
    ...Array.from({ length: daysInMonth }, (_, i) => i + 1),
  ];
  while (cells.length % 7 !== 0) cells.push(null);

  const shiftMonth = (delta: number) =>
    setMonth((m) => new Date(m.getFullYear(), m.getMonth() + delta, 1));

  return (
    <section className="rounded-2xl bg-white p-5 shadow-[0_2px_16px_rgba(21,54,50,0.07)]">
      <div className="mb-3 flex items-center justify-between">
        <button
          type="button"
          onClick={() => shiftMonth(-1)}
          aria-label="Önceki ay"
          className="grid size-8 place-items-center rounded-full text-muted transition hover:bg-line hover:text-foreground"
        >
          <ChevronLeft className="size-4" />
        </button>
        <h3 className="text-base font-bold capitalize text-foreground">
          {MONTH_FORMAT.format(month)}
        </h3>
        <button
          type="button"
          onClick={() => shiftMonth(1)}
          aria-label="Sonraki ay"
          className="grid size-8 place-items-center rounded-full text-muted transition hover:bg-line hover:text-foreground"
        >
          <ChevronRight className="size-4" />
        </button>
      </div>

      <div className="grid grid-cols-7 text-center text-[11px] font-medium text-muted">
        {WEEKDAYS.map((day) => (
          <div key={day} className="pb-2">
            {day}
          </div>
        ))}
      </div>

      <div className="grid grid-cols-7">
        {cells.map((day, index) => {
          if (day === null) {
            return <div key={index} className="min-h-[52px] border-t border-line/60" />;
          }
          const key = toDateKey(new Date(month.getFullYear(), month.getMonth(), day));
          const dayEvents = eventsByDay.get(key) ?? [];
          const isToday = key === todayKey;
          return (
            <div
              key={index}
              className={`min-h-[52px] border-t border-line/60 p-1 ${
                isToday ? "rounded-md bg-accent/15" : ""
              }`}
            >
              <div
                className={`text-xs ${
                  isToday ? "font-bold text-accent" : "font-medium text-foreground/70"
                }`}
              >
                {day}
              </div>
              <div className="mt-0.5 space-y-0.5">
                {dayEvents.slice(0, 2).map((event, i) => (
                  <div key={i} className="flex items-center gap-1" title={event.label}>
                    <span
                      className={`size-1.5 shrink-0 rounded-full ${DOT_CLASS[event.kind]}`}
                    />
                    <span className="truncate text-[9px] leading-tight text-muted">
                      {event.label}
                    </span>
                  </div>
                ))}
                {dayEvents.length > 2 && (
                  <div className="text-[9px] text-muted">+{dayEvents.length - 2}</div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
}
