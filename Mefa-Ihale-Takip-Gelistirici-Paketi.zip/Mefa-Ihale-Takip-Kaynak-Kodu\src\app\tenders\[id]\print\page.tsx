import { notFound } from "next/navigation";

import { PrintToolbar } from "@/components/print/print-toolbar";
import "@/app/print.css";
import {
  deriveTenderOutcome,
  deriveTenderStatus,
  parseBidAmount,
  type TenderResultBid,
} from "@/lib/tender-details";
import { formatBooleanAnswer, formatDate, formatDateTime, todayDateKey } from "@/lib/format";
import { getTenderDetail } from "@/lib/tenders";

export const dynamic = "force-dynamic";

type PageProps = { params: Promise<{ id: string }> };

const STATUS_STAMP: Record<string, { label: string; className: string }> = {
  won: { label: "Kazanıldı", className: "won" },
  lost: { label: "Sözleşme İmzalanmadı", className: "lost" },
  finished: { label: "Sonuçlandı", className: "" },
  open: { label: "Değerlendirmede", className: "warn" },
};

function classifyBids(bids: TenderResultBid[], company: string | null) {
  const normalizedCompany = company ? company.trim().toLocaleLowerCase("tr-TR") : null;
  const parsed = bids.map((bid) => ({ ...bid, amount: parseBidAmount(bid.bidAmount) }));
  const validAmounts = parsed
    .filter((b) => !b.disqualifiedReason && b.amount !== null)
    .map((b) => b.amount as number);
  const lowestValid = validAmounts.length > 0 ? Math.min(...validAmounts) : null;

  return [...parsed]
    .sort((a, b) => {
      if (a.amount === null && b.amount === null) return 0;
      if (a.amount === null) return 1;
      if (b.amount === null) return -1;
      return a.amount - b.amount;
    })
    .map((bid) => {
      const normalizedName = bid.companyName.trim().toLocaleLowerCase("tr-TR");
      const isOurs = normalizedCompany
        ? normalizedName.includes(normalizedCompany) || normalizedCompany.includes(normalizedName)
        : false;
      const isWinner =
        !bid.disqualifiedReason && bid.amount !== null && bid.amount === lowestValid;
      return { ...bid, isOurs, isWinner };
    });
}

export default async function TenderPrintPage({ params }: PageProps) {
  const { id } = await params;
  const result = await getTenderDetail(id);
  if (!result.isConfigured || result.dataError || !result.tender) notFound();

  const tender = result.tender;
  const { details } = tender;
  const status = deriveTenderStatus(deriveTenderOutcome(details), tender.tenderDate, todayDateKey());
  const stamp = STATUS_STAMP[status.kind === "upcoming" ? "open" : status.kind];
  const bids = details.result ? classifyBids(details.result.bids, details.company) : [];

  return (
    <div className="pd-root">
      <PrintToolbar backHref={`/tenders/${tender.id}`} />
      <div className="pd-frame">
        <article className="pd-paper">
          <div className="pd-letterhead">
            <div className="pd-wordmark">
              Mefa Group
              <small>İhale Takip Sistemi</small>
            </div>
            <div className="pd-doc-meta">
              BELGE NO: İHL-{tender.referenceCode?.replace(/[^0-9]/g, "") || tender.id.slice(0, 8)}
              <br />
              OLUŞTURMA: {formatDate(todayDateKey())}
            </div>
          </div>
          <div className="pd-rule-1" />
          <div className="pd-rule-2" />

          <div className="pd-title-row">
            <div className="pd-title-block">
              <span className="pd-eyebrow">İhale Dosyası Raporu</span>
              <h1>{tender.title}</h1>
            </div>
            {status.kind === "upcoming" ? (
              <span className="pd-stamp info">
                {status.daysRemaining} Gün Kaldı
                <small>{formatDate(tender.tenderDate)}</small>
              </span>
            ) : (
              <span className={`pd-stamp ${stamp.className}`}>
                {stamp.label}
                {details.result?.finishedAt && <small>Sonuç: {formatDate(details.result.finishedAt)}</small>}
              </span>
            )}
          </div>

          <div className="pd-grid">
            <div className="pd-field"><label>İdare</label><div className="pd-val">{tender.authority || "—"}</div></div>
            <div className="pd-field"><label>İhale Kayıt No</label><div className="pd-val pd-num">{tender.referenceCode || "—"}</div></div>
            <div className="pd-field"><label>Katılım Usulü</label><div className="pd-val">{details.participationMethod || "—"}</div></div>
            <div className="pd-field"><label>İhale Tarihi</label><div className="pd-val pd-num">{formatDate(tender.tenderDate)}</div></div>
            <div className="pd-field"><label>Firma</label><div className="pd-val">{details.company || "—"}</div></div>
            <div className="pd-field"><label>Teslim Usulü</label><div className="pd-val">{details.submissionMethod || "—"}</div></div>
          </div>

          <div className="pd-section">
            <div className="pd-section-label">Teminatlar</div>
            <div className="pd-grid pd-grid-flush">
              <div className="pd-field"><label>Geçici Teminat</label><div className="pd-val">{details.temporaryGuarantee || "—"}</div></div>
              <div className="pd-field"><label>Kesin Teminat</label><div className="pd-val">{details.finalGuarantee || "—"}</div></div>
              <div className="pd-field"><label>Banka Referans Mektubu</label><div className="pd-val">{formatBooleanAnswer(details.requiresBankReference)}</div></div>
            </div>
          </div>

          {details.priceDifference && (
            <div className="pd-section">
              <div className="pd-section-label">Fiyat Farkı</div>
              <p className="pd-prose">{details.priceDifference}</p>
            </div>
          )}

          {(details.advancePayment !== null || details.advanceAmount) && (
            <div className="pd-section">
              <div className="pd-section-label">Avans</div>
              <div className="pd-grid pd-grid-flush">
                <div className="pd-field"><label>Avans Veriliyor mu?</label><div className="pd-val">{formatBooleanAnswer(details.advancePayment)}</div></div>
                <div className="pd-field"><label>Avans Oranı / Tutarı</label><div className="pd-val">{details.advanceAmount || "—"}</div></div>
              </div>
            </div>
          )}

          {details.workDuration && (
            <div className="pd-section">
              <div className="pd-section-label">İşin Süresi</div>
              <p className="pd-prose">{details.workDuration}</p>
            </div>
          )}

          {details.technicalStaff.length > 0 && (
            <div className="pd-section">
              <div className="pd-section-label">Teknik Personel Zorunluluğu</div>
              <div className="pd-table-scroll">
                <table className="pd-table">
                  <thead><tr><th className="pd-num" style={{ width: "3.5rem" }}>Adet</th><th>Pozisyon</th><th>Şart</th></tr></thead>
                  <tbody>
                    {details.technicalStaff.map((item, i) => (
                      <tr key={i}>
                        <td className="pd-num">{item.quantity || "—"}</td>
                        <td>{item.position || "—"}{item.other ? ` — ${item.other}` : ""}</td>
                        <td>{item.requirements || "—"}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {details.otherNotes && (
            <div className="pd-section">
              <div className="pd-section-label">Diğer Hususlar</div>
              <p className="pd-prose pd-muted" style={{ whiteSpace: "pre-wrap" }}>{details.otherNotes}</p>
            </div>
          )}

          {bids.length > 0 && (
            <div className="pd-section">
              <div className="pd-section-label">İhale Sonucu — Verilen Teklifler</div>
              <div className="pd-table-scroll">
                <table className="pd-table">
                  <thead><tr><th className="pd-num" style={{ width: "2.2rem" }}>#</th><th>Firma</th><th className="pd-num">Teklif</th></tr></thead>
                  <tbody>
                    {bids.map((bid, i) => (
                      <tr
                        key={i}
                        className={bid.disqualifiedReason ? "pd-dq" : bid.isWinner ? "pd-win" : bid.isOurs ? "pd-ours" : ""}
                      >
                        <td className="pd-num">{i + 1}</td>
                        <td className="pd-name">
                          {bid.companyName}
                          {bid.isWinner && <span className="pd-row-note pd-won">✓ İhale Kazananı</span>}
                          {!bid.isWinner && bid.isOurs && <span className="pd-row-note pd-accent">Bizim teklifimiz</span>}
                          {bid.disqualifiedReason && <span className="pd-row-note pd-reason">{bid.disqualifiedReason}</span>}
                        </td>
                        <td className="pd-num">{bid.bidAmount || "—"}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          <div className="pd-sign-grid">
            <div className="pd-sign-block"><div className="pd-line" /><label>Hazırlayan · Tarih</label></div>
            <div className="pd-sign-block"><div className="pd-line" /><label>Kontrol Eden · Tarih</label></div>
          </div>

          <div className="pd-footnote">Bu belge Mefa Group İhale Takip sisteminden otomatik oluşturulmuştur · {formatDateTime(new Date().toISOString())}</div>
        </article>
      </div>
    </div>
  );
}
