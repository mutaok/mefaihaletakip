import Link from "next/link";
import type { LucideIcon } from "lucide-react";
import type { ReactNode } from "react";

export function NavTile({
  href,
  icon: Icon,
  title,
  subtitle,
  badge,
  action,
}: {
  href: string;
  icon: LucideIcon;
  title: string;
  subtitle: string;
  badge?: number;
  action?: ReactNode;
}) {
  return (
    <div className="relative">
      <Link
        href={href}
        className="group flex items-center gap-4 rounded-3xl border border-line bg-white/70 px-6 py-5 text-left shadow-sm transition hover:border-accent/40 hover:bg-white"
      >
        <span className="grid size-12 flex-shrink-0 place-items-center rounded-2xl bg-accent text-white shadow-lg transition group-hover:scale-105">
          <Icon className="size-6" />
        </span>
        <span className="min-w-0 flex-1">
          <span className="flex items-center gap-2">
            <span className="text-base font-semibold text-foreground">{title}</span>
            {typeof badge === "number" && badge > 0 && (
              <span className="rounded-full bg-accent-strong px-2 py-0.5 text-xs font-semibold text-white">
                {badge}
              </span>
            )}
          </span>
          <span className="mt-0.5 block text-xs text-muted">{subtitle}</span>
        </span>
      </Link>
      {action && <div className="absolute right-4 top-1/2 -translate-y-1/2">{action}</div>}
    </div>
  );
}
