"use client";

import { useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { FolderOpen, Loader2, X, AlertTriangle } from "lucide-react";

import { uploadSingleFileForFolderReturnAction } from "@/app/actions";

type FolderOption = { id: string; name: string };

const ACCEPTED_EXTS = [".pdf", ".doc", ".docx", ".xls", ".xlsx"];

const ERROR_LABELS: Record<string, string> = {
  "supabase-missing": "Supabase bağlantısı eksik.",
  "folder-not-found": "İhale bulunamadı.",
  "no-valid-files": "Desteklenen dosya (PDF/Word/Excel) bulunamadı.",
  "upload-failed": "Hiçbir dosya yüklenemedi. Bağlantıyı kontrol edin.",
};

function fileExt(name: string): string {
  const m = /\.([a-z0-9]+)$/i.exec(name);
  return m ? m[1].toUpperCase() : "?";
}

function fileTypeBadgeCls(name: string): string {
  const lower = name.toLowerCase();
  if (lower.endsWith(".pdf")) return "bg-rose-100 text-rose-700";
  if (lower.endsWith(".docx") || lower.endsWith(".doc"))
    return "bg-blue-100 text-blue-700";
  if (lower.endsWith(".xlsx") || lower.endsWith(".xls"))
    return "bg-emerald-100 text-emerald-700";
  return "bg-line text-muted";
}

export function FolderUploadForm({
  tenderId,
  documentFolders = [],
}: {
  tenderId: string;
  documentFolders?: FolderOption[];
}) {
  const router = useRouter();
  const inputRef = useRef<HTMLInputElement>(null);
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [selectedFolderName, setSelectedFolderName] = useState("");
  const [errorCode, setErrorCode] = useState<string | null>(null);

  // Yükleme durumu
  const [uploading, setUploading] = useState(false);
  const [progress, setProgress] = useState<{ done: number; total: number } | null>(null);

  function handleChange(e: React.ChangeEvent<HTMLInputElement>) {
    setErrorCode(null);
    const files = Array.from(e.target.files ?? []).filter((f) => {
      const name = f.name.toLowerCase();
      return ACCEPTED_EXTS.some((ext) => name.endsWith(ext));
    });
    setSelectedFiles(files);
  }

  function clearSelection() {
    setSelectedFiles([]);
    setErrorCode(null);
    setProgress(null);
    if (inputRef.current) inputRef.current.value = "";
  }

  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (selectedFiles.length === 0 || uploading) return;

    setErrorCode(null);
    setUploading(true);
    setProgress({ done: 0, total: selectedFiles.length });

    let successCount = 0;

    for (let i = 0; i < selectedFiles.length; i++) {
      const file = selectedFiles[i];

      const formData = new FormData();
      formData.append("tenderId", tenderId);
      if (selectedFolderName) formData.append("folderName", selectedFolderName);
      formData.append("file", file);

      const result = await uploadSingleFileForFolderReturnAction(formData);
      if (result.ok) successCount++;

      setProgress({ done: i + 1, total: selectedFiles.length });
    }

    setUploading(false);
    setProgress(null);

    if (successCount === 0) {
      setErrorCode("upload-failed");
    } else {
      router.push(`/tenders/${tenderId}?success=folder-upload-complete`);
      router.refresh();
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-3">
      {/* Gizli dosya input — webkitdirectory */}
      <input
        ref={inputRef}
        type="file"
        multiple
        // @ts-expect-error webkitdirectory non-standard
        webkitdirectory=""
        className="hidden"
        onChange={handleChange}
      />

      <div className="flex flex-wrap items-end gap-3">
        {/* Klasör seçici butonu */}
        <button
          type="button"
          disabled={uploading}
          onClick={() => inputRef.current?.click()}
          className="inline-flex items-center gap-2 rounded-xl border border-dashed border-accent/50 bg-accent/5 px-4 py-2.5 text-sm font-medium text-accent transition hover:border-accent hover:bg-accent/10 disabled:cursor-not-allowed disabled:opacity-60"
        >
          <FolderOpen className="size-4" />
          {selectedFiles.length > 0
            ? `${selectedFiles.length} dosya seçildi`
            : "Klasör Seç"}
        </button>

        {/* Hedef klasör dropdown */}
        {documentFolders.length > 0 && (
          <div className="flex-1 min-w-[160px]">
            <label className="block">
              <span className="mb-1 block text-xs font-semibold uppercase tracking-wide text-muted">
                Hedef Klasör
              </span>
              <select
                value={selectedFolderName}
                onChange={(e) => setSelectedFolderName(e.target.value)}
                disabled={uploading}
                className="w-full rounded-xl border border-line bg-white px-3 py-2.5 text-sm text-foreground outline-none transition focus:border-accent focus:ring-2 focus:ring-accent/15 disabled:opacity-60"
              >
                <option value="">Ana Klasör</option>
                {documentFolders.map((f) => (
                  <option key={f.id} value={f.name}>
                    {f.name}
                  </option>
                ))}
              </select>
            </label>
          </div>
        )}

        {selectedFiles.length > 0 && (
          <div className="flex items-end gap-2">
            {!uploading && (
              <button
                type="button"
                onClick={clearSelection}
                className="inline-flex items-center gap-1.5 rounded-lg border border-line px-3 py-2.5 text-xs text-muted transition hover:bg-line/30"
              >
                <X className="size-3.5" /> Temizle
              </button>
            )}
            <button
              type="submit"
              disabled={uploading}
              className="inline-flex items-center gap-2 rounded-xl bg-accent px-5 py-2.5 text-sm font-semibold text-white transition hover:bg-accent/90 disabled:opacity-70"
            >
              {uploading && progress ? (
                <>
                  <Loader2 className="size-4 animate-spin" />
                  {progress.done} / {progress.total} yükleniyor…
                </>
              ) : (
                "Klasörü Yükle"
              )}
            </button>
          </div>
        )}
      </div>

      {/* Hata mesajı */}
      {errorCode && (
        <div className="flex items-center gap-2 rounded-xl border border-rose-200 bg-rose-50 px-4 py-2.5 text-sm text-rose-700">
          <AlertTriangle className="size-4 flex-shrink-0" />
          {ERROR_LABELS[errorCode] ?? "Beklenmeyen bir hata oluştu."}
        </div>
      )}

      {/* Dosya önizleme listesi */}
      {selectedFiles.length > 0 && (
        <div className="max-h-44 overflow-y-auto rounded-xl border border-line bg-white/60 p-3">
          <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted">
            Yüklenecek ({selectedFiles.length} dosya)
          </p>
          <ul className="space-y-1">
            {selectedFiles.slice(0, 60).map((f, i) => (
              <li key={i} className="flex items-center gap-2 text-xs text-foreground">
                <span className={`inline-block rounded px-1.5 py-0.5 text-[10px] font-bold uppercase ${fileTypeBadgeCls(f.name)}`}>
                  {fileExt(f.name)}
                </span>
                <span className="truncate">{f.name}</span>
                <span className="ml-auto flex-shrink-0 text-muted">
                  {(f.size / 1024 / 1024).toFixed(1)} MB
                </span>
              </li>
            ))}
            {selectedFiles.length > 60 && (
              <li className="text-xs text-muted">
                +{selectedFiles.length - 60} dosya daha…
              </li>
            )}
          </ul>
        </div>
      )}

      <p className="text-xs text-muted">
        Desteklenen: PDF · Word (.docx/.doc) · Excel (.xlsx/.xls) · Maks. 200 MB/dosya
      </p>
    </form>
  );
}
