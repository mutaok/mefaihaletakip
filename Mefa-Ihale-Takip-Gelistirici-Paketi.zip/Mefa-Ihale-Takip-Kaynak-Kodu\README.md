# Mefa Group İhale Takip

MEFA GROUP için geliştirilmiş, masaüstünde çalışan bir **ihale takip ve yönetim
sistemi**. Firmanın katıldığı ihaleleri (belgeleriyle birlikte), teminat
mektuplarını, operasyonel görevleri tek yerde toplar; e-posta hatırlatıcıları
ve Google Takvim senkronizasyonuyla ekibi otomatik olarak uyarır.

Bu doküman, projeye yeni katılan bir geliştiricinin ihtiyaç duyacağı her şeyi
içerir: mimari, kurulum, derleme/yayınlama süreci ve **canlıda karşılaşılıp
çözülmüş gerçek hatalar** (tekrar keşfetmemeniz için).

---

## 1. Uygulama ne yapar?

- **İhale dosyaları**: başlık, kurum, referans no, tarih, il/ilçe + harita
  konumu; avans, teminat oranları, iş süresi, teknik personel şartı, katılım/
  teslim şekli gibi tüm detaylar.
- **Belge yönetimi**: her ihaleye PDF/Word/Excel yükleme, klasörleme, indirme
  (Supabase Storage'da saklanır).
- **İhale sonucu**: teklif veren firmalar + tutarlar + diskalifiye nedenleri
  girilir; kazanma/kaybetme, girilen firma adının en düşük geçerli teklife
  göre otomatik karşılaştırılmasıyla belirlenir (bkz. `lib/tender-details.ts`
  → `deriveTenderOutcome` / `deriveTenderStatus`).
- **Teminat mektupları**: Geçici/Kesin, banka, tutar, PDF; "İade Edildi"
  takibi ve kaç gündür açık olduğunun gösterimi.
- **Operasyonel Takvim Ve Ajanda**: son tarihli görevler, aylık takvim
  görünümü, Gecikti/Bugün/Yakında durumu.
- **Yönetici özeti (ana sayfa)**: açık ihale sayısı, aktif teminatlar,
  kazanılan/sonuçlanmayan ihale istatistikleri, takvim ve görev listesi tek
  ekranda.
- **Yazdırma şablonları**: ihale dosyası raporu, teminat mektubu formu, görev
  listesi, aktif ihaleler raporu — her biri kağıda özel, ayrı tasarımlı
  (`/tenders/[id]/print`, `/teminat-mektuplari/[id]/print`, `/gorevler/print`,
  `/aktif-ihaleler/print`).
- **E-posta hatırlatıcıları**: her Pazartesi 09:00 sonrası haftalık açık
  görev özeti + görev son tarihine 15/7/3 gün kala hatırlatma (Gmail SMTP).
- **Google Takvim senkronizasyonu**: ihale/görev eklendiğinde/silindiğinde
  tek yönlü olarak (uygulama → Google) bir Google Takvim'e otomatik yansır.
- **Otomatik güncelleme**: uygulama açılışta yeni sürüm olup olmadığını
  Supabase üzerinden kontrol eder, varsa indirip kendini günceller.
- **Çoklu bilgisayar**: veriler ortak bulut veritabanında (Supabase) durur;
  her bilgisayar aynı veriyi görür.

## 2. Mimari

```
┌─────────────────────────────────────────────┐
│  Electron (electron/main.js)                 │
│  - Pencereyi açar                             │
│  - İçeride bir Next.js "standalone" sunucu    │
│    başlatır (node server.js, rastgele boş     │
│    porttan)                                    │
│  - Açılışta Supabase Storage'daki version.json │
│    ile kendi sürümünü karşılaştırır, gerekirse │
│    kendini günceller (bkz. §6)                 │
└──────────────────┬────────────────────────────┘
                     │ http://localhost:<port>
┌──────────────────▼────────────────────────────┐
│  Next.js 16 (App Router, standalone çıktı)     │
│  - Server Components + Server Actions          │
│  - Tüm iş mantığı burada (src/app/actions.ts)  │
└──────────────────┬────────────────────────────┘
                     │ REST / Storage API
┌──────────────────▼────────────────────────────┐
│  Supabase (bulut)                              │
│  - PostgreSQL veritabanı                       │
│  - Storage (belge/PDF depolama)                │
│  - Aynı proje, TÜM bilgisayarlar tarafından     │
│    paylaşılıyor                                 │
└─────────────────────────────────────────────────┘
```

Önemli nokta: **kaynak kod her makinede farklı olabilir** — bu proje şu an
`Documents\New project` altında, en güncel hali burada. Bulut (Supabase)
ortak olduğu için hangi bilgisayardan veri girilirse girilsin her yerde
görünür; ama **uygulamanın kendisi** (arayüz, özellikler) her bilgisayara
ancak yayınlanan bir güncellemeyle ulaşır.

## 3. Teknoloji yığını

| Katman | Teknoloji |
|---|---|
| Dil | TypeScript (uygulama), JavaScript (Electron kabuğu) |
| Arayüz | React 19 |
| Uygulama çatısı | Next.js 16 (App Router, `output: "standalone"`) |
| Stil | Tailwind CSS 4 |
| Masaüstü kabuk | Electron (paketleme: `electron-builder` + `@electron/asar`) |
| Veritabanı + depo | Supabase (PostgreSQL + Storage) |
| Harita | Leaflet + react-leaflet |
| E-posta | Nodemailer (Gmail SMTP) |
| Takvim | Google Calendar API (servis hesabı, saf `fetch` + `crypto` — `googleapis` paketi kullanılmıyor) |
| İkonlar | lucide-react |
| Diğer | exceljs, pdf-parse, clsx |

## 4. Proje yapısı

```
electron/
  main.js                     # Electron ana süreç: pencere, sunucu, OTOMATİK GÜNCELLEME (bkz §6)
scripts/
  build-electron.js           # Next standalone çıktısını Electron paketine yerleştirir
  publish-update.js           # Güncelleme paketini Supabase Storage'a yükler
  create-shortcut.ps1         # Masaüstü kısayolu oluşturur (opsiyonel)
src/
  instrumentation.ts          # Next.js sunucu-açılış kancası — e-posta hatırlatıcı zamanlayıcısını kurar
  app/
    page.tsx                  # Ana sayfa / yönetici özeti dashboard'u
    actions.ts                # TÜM server action'lar (CRUD + takvim/kalıcılık yan etkileri) — en büyük dosya
    layout.tsx                # Root layout, fontlar
    globals.css / print.css   # Ekran teması / yazdırma tasarım sistemi (ayrı, kasıtlı olarak birbirinden bağımsız)
    tenders/[id]/page.tsx      # İhale detay sayfası
    tenders/[id]/print/        # İhale yazdırma şablonu
    teminat-mektuplari/        # Teminat mektupları listesi + tekil yazdırma şablonu
    gorevler/                  # Operasyonel Takvim Ve Ajanda + yazdırma şablonu
    aktif-ihaleler/print/      # "Aktif ihaleler" yazdırma şablonu
    gecmis-ihaleler/, trash/   # Geçmiş ihaleler, çöp kutusu
  components/                 # Sunum bileşenleri (form dialogları, dashboard kartları, harita, print toolbar…)
  lib/
    tenders.ts, tasks.ts, guarantee-letters.ts   # Supabase sorgu katmanları
    tender-details.ts         # İhale details (jsonb) şeması + durum türetme mantığı
    storage-kv.ts             # Şema gerektirmeyen küçük durumlar için Storage'da JSON okuma/yazma (önbellek kırıcı!)
    mailer.ts, reminders.ts   # E-posta gönderimi + hatırlatıcı zamanlama mantığı
    google-calendar.ts        # Google Calendar servis hesabı entegrasyonu
    provinces.ts              # 81 il + koordinatları
    format.ts, flash.ts       # Biçimlendirme yardımcıları, bildirim mesajları
    supabase/server.ts        # Supabase admin client (yalnızca sunucu tarafı)
    supabase/database.types.ts # Elle tutulan tablo tipleri (otomatik codegen değil)
supabase/
  schema.sql, migrate-*.sql   # Veritabanı şeması ve geçmiş migrasyonlar (elle, Supabase Dashboard SQL Editor'de çalıştırılır — CLI kullanılmıyor)
```

## 5. Veri modeli (Supabase tabloları)

Migrasyon/CLI altyapısı yok — şema değişiklikleri Supabase Dashboard'un SQL
Editor'ünde elle çalıştırılıyor (`supabase/*.sql` dosyaları referans için
saklanıyor). Ana tablolar:

- **`tender_folders`** — ihale kayıtları. `details` (jsonb) sütunu esnek
  şemalı: avans, teminat, teknik personel, `result.bids[]` (ihale sonucu),
  `_deletedAt` (yumuşak silme) gibi alanları tutar — bkz.
  `lib/tender-details.ts`. NOT NULL: `title, latitude, longitude, il, details`.
- **`tender_documents`** — yüklenen belgeler (Storage'daki dosya yoluna işaret eder).
- **`guarantee_letters`** — teminat mektupları. `letter_type`: `gecici`/`kesin`.
  İade durumu bu tabloda değil, ayrıca Storage'da tutulur (aşağıya bakın).
- **`tasks`** — görevler (`due_date`, `completed`).

**Şemasız küçük durumlar** (iade takibi, hatırlatıcı gönderim kaydı) tablo
eklemek yerine Supabase Storage'da küçük JSON dosyaları olarak tutuluyor
(`tender-files/_meta/*.json`), `lib/storage-kv.ts` üzerinden okunup yazılıyor.
**Bu dosyaları okurken/yazarken mutlaka önbellek kırıcı davranın** (bkz. §7,
madde 1) — aksi halde saatlerce eski veri görülebilir.

## 6. Geliştirme ortamı kurulumu

1. Node.js 20+ kurulu olmalı.
2. `npm install`
3. `.env.local` dosyası oluşturun (proje kökünde), aşağıdaki anahtarları
   doldurun — **bu dosya asla kaynak kod paylaşımlarına dahil edilmez**:

   ```env
   # Supabase (zorunlu)
   NEXT_PUBLIC_SUPABASE_URL=https://XXXXX.supabase.co
   SUPABASE_SERVICE_ROLE_KEY=eyJhbG...        # service_role, anon DEĞİL
   SUPABASE_STORAGE_BUCKET=tender-files

   # E-posta hatırlatıcıları (opsiyonel — yoksa özellik sessizce devre dışı kalır)
   GMAIL_USER=ornek@gmail.com
   GMAIL_APP_PASSWORD=xxxx xxxx xxxx xxxx      # normal şifre DEĞİL, Google "Uygulama Şifresi"

   # Google Takvim senkronizasyonu (opsiyonel — yoksa sessizce devre dışı kalır)
   GOOGLE_SERVICE_ACCOUNT_EMAIL=xxx@xxx.iam.gserviceaccount.com
   GOOGLE_SERVICE_ACCOUNT_PRIVATE_KEY="-----BEGIN PRIVATE KEY-----\n...\n-----END PRIVATE KEY-----\n"
   GOOGLE_CALENDAR_ID=primary
   ```

4. `npm run dev` → http://localhost:3000
   - Dev modda Turbopack'in Windows + Türkçe karakterli yol kombinasyonunda
     sorun çıkarabildiği görüldü; sorun olursa `next dev --webpack` deneyin.
5. Masaüstü (Electron) kabukla denemek için: `npm run electron:dev`

### Üretim derlemesi (Electron paketi)

```bash
npm run build                    # Next.js standalone build
node scripts/build-electron.js   # Electron paketine yerleştirir (dist-electron/win-unpacked)
npx @electron/asar pack dist-electron/win-unpacked/resources/app dist-electron/win-unpacked/resources/app.asar
```
(`asar pack`'ten sonra `resources/app` klasörünü silin — sadece `app.asar`
kalmalı.) Sürüm numarasını **hem** `package.json` **hem** `electron/main.js`
içindeki `APP_VERSION` sabitinde güncellemeyi unutmayın; ikisi de manuel
tutuluyor, otomatik senkron değil.

> **İki ayrı derleme yolu var, karıştırmayın:** `package.json`'da
> `electron-builder` için tam bir NSIS kurulum yapılandırması da tanımlı
> (`npm run electron:build`) — bu, imzalı/kurulum sihirbazlı bir `.exe`
> üretir. Ancak **güncelleme yayınlama akışı bunu kullanmıyor**; onun yerine
> yukarıdaki manuel `build-electron.js` + `asar pack` yolu, doğrudan
> `dist-electron/win-unpacked` altında "portable" bir çıktı üretip
> `resources/server` + `app.asar`'ı doğrudan kopyalayarak/robocopy ile
> güncelliyor. Bu proje şu an ikinci yolu kullanıyor; NSIS yolu yalnızca
> sıfırdan yeni bir kurulum paketi (ilk kurulum `.exe`'si) gerektiğinde
> anlamlı.

## 7. Güncelleme yayınlama ve otomatik güncelleme — DİKKATLİCE OKUYUN

```bash
node scripts/publish-update.js
```
Bu betik, derlenmiş `resources/server` + `app.asar`'ı zip'leyip Supabase
Storage'a (`tender-files/_updates/update-X.Y.Z.zip` + `version.json`) yükler.
Kurulu her uygulama, açılışta bu adresi kontrol edip kendini günceller
(`electron/main.js` → `checkForUpdates`).

**Bu mekanizma uzun süre çalışmıyordu ve kaynağı çok zor bulunan 3 ayrı hata
vardı — hepsi düzeltildi (v1.3.18), ama gelecekte benzer bir "özellik X
canlıda tuhaf davranıyor ama yerelde çalışıyor" durumuyla karşılaşırsanız
aşağıdaki dersler muhtemelen ilgilidir:**

1. **Supabase Storage nesneleri varsayılan olarak `max-age=3600` ile CDN'de
   önbelleğe alınır.** Bir dosyayı güncelleyip hemen okursanız (veya farklı
   bir CDN ucu eski/yarım bir kopyayı önbelleklemişse) saatlerce eski/bozuk
   veri görebilirsiniz. Çözüm: hem yüklerken `Cache-Control: no-cache,
   max-age=0` header'ı gönderin, hem okurken URL'ye `?t=${Date.now()}` gibi
   önbellek kırıcı bir sorgu parametresi ekleyip `cache: "no-store"`
   kullanın. Bu iki kez bizi ısırdı: bir kez teminat mektubu "İade Edildi"
   durumunun geri alınamaması olarak (`lib/storage-kv.ts` şimdi bunu merkezi
   olarak çözüyor), bir kez de güncelleme paketinin bozuk inmesi olarak
   (`electron/main.js`, `hasValidZipSignature` ile de ayrıca doğruluyor).

2. **Windows İş Nesnesi (Job Object), Electron'un çocuk süreçlerini ana
   süreç kapanınca öldürür — `spawn(..., {detached: true})` buna karşı
   YETERLİ DEĞİL.** Güncelleme uygulayan PowerShell betiği, doğrudan
   `spawn("powershell.exe", {detached:true})` ile başlatılırsa, Electron
   `app.quit()` çağırdığı an sessizce öldürülüyordu — hiçbir hata, hiçbir
   iz. Çözüm: `cmd.exe /c start` ile sarmalayarak başlatmak, süreci İş
   Nesnesinden koparıyor. Bu TEK BAŞINA, güncellemenin "hiç çalışmamasının"
   ana sebebiydi; izole bir test yazmadan (basit bir .ps1 dosyası spawn edip
   ebeveyn hemen çıkınca ne olduğuna bakarak) bulunamadı.

3. **`fs.realpathSync()` Windows kısa adlarını (8.3, ör. `TLAY~1`) ÇÖZMEZ** —
   yalnızca sembolik bağları çözer. `os.tmpdir()` bazı profillerde kısa ad
   döndürüyor, bu da `Expand-Archive` gibi bazı .NET tabanlı çağrıların
   "yol bulunamadı" hatası vermesine yol açıyordu. `fs.realpathSync.native()`
   (işletim sisteminin kendi çağrısı) doğru şekilde uzun ada çeviriyor.

**Genel ders**: bu sınıftaki hatalar (önbellek, iş nesnesi, kısa ad) kodu
okuyarak DEĞİL, gerçek bir sürüm yükseltme döngüsünü uçtan uca çalıştırıp
izleyerek bulundu — bir throwaway test sürümü yayınlayıp kurulu eski sürümün
kendini güncellemesini gözlemlemek, bu tarz koddaki hataları yakalamanın tek
güvenilir yolu.

Ayrıca: `checkForUpdates` artık her adımı `%APPDATA%\mefa-ihale-takip\
update-log.txt` dosyasına (hem Node tarafı hem spawn edilen PowerShell
betiğinin kendisi) kalıcı olarak kaydediyor — önceden her hata sessizce
yutuluyordu (`console.error`, paketlenmiş uygulamada görünmez), bu da bu
hataların canlıda teşhis edilmesini imkânsız kılıyordu. **Bir kullanıcı
"güncelleme çalışmıyor" derse önce bu dosyayı isteyin.**

Manuel/acil onarım aracı: `Desktop\MEFA-Guncelle.cmd` (kullanıcının
bilgisayarında) — otomatik güncelleyici bir şekilde bozulmuş/eski bir
sürümde takılı kalmış makineleri tek seferlik elle kurtarmak için, aynı
önbellek-kırma ve doğrulama mantığıyla yazıldı.

## 8. Sürüm geçmişi (özet)

- **v1.0–1.2**: Temel ihale/belge/harita takibi.
- **v1.3.0–1.3.2**: Şirket alanı, ihale sonucu tablosu, teminat mektubu
  türleri, yaklaşan görevler.
- **v1.3.3**: Yeni yönetici özeti dashboard tasarımı (mevcut ana sayfa).
- **v1.3.4–1.3.5**: Teminat mektubu iade takibi + ilişkili önbellek hatası düzeltmesi.
- **v1.3.6**: Büyük paket — isim değişikliği (Mefa Group), "Operasyonel
  Takvim Ve Ajanda" yeniden adlandırma, ihale durum mantığı yenilenmesi
  (yaklaşan ihale için gün sayacı, "Sözleşme İmzalanmadı"), 4 yazdırma
  şablonu, pastel durum renkleri.
- **v1.3.7**: E-posta hatırlatıcı sistemi + Google Takvim entegrasyonu.
- **v1.3.8–1.3.18**: Otomatik güncelleme sistemindeki 3 kritik hatanın
  bulunup düzeltilmesi (bkz. §7) — kalıcı günlükleme, pencere görünürlük
  garantisi dahil.

## 9. Bilinmesi gereken diğer tasarım kararları

- Yazdırma şablonları (`print.css`) **kasıtlı olarak** ekranın Tailwind
  temasından bağımsız — kağıt her zaman kağıt görünmeli, ekran karanlık
  modda olsa bile. Yeni bir yazdırma şablonu eklerken bu ayrımı koruyun.
  Eski, tek-buton `window.print()` yaklaşımı (`PrintButton` bileşeni)
  kaldırıldı — artık her belge türünün kendi `/print` rotası var.
- Sunucu action'larında (özellikle takvim/e-posta gibi "en iyi çaba"
  yan etkilerinde) **fire-and-forget (`void fn()`) yerine `await` kullanın**
  — self-hosted (Vercel olmayan) bir Next.js standalone sunucusunda,
  awaitlenmeyen promise'lerin bir request/action tamamlandıktan sonra
  tamamlanacağı garanti değil. `lib/google-calendar.ts` ve
  `lib/mailer.ts`'teki fonksiyonlar bu yüzden kendi içlerinde tüm hataları
  yutuyor (asla reject/throw etmiyorlar) — çağıran taraf güvenle `await`
  edebilir, hiçbir zaman asıl işlemi bloke/başarısız etmez.
- Google Takvim entegrasyonu `googleapis` paketi KULLANMIYOR — servis hesabı
  JWT'si Node'un yerleşik `crypto` modülüyle elle imzalanıyor
  (`lib/google-calendar.ts`). Bağımlılık eklemeden önce bu dosyaya bakın.
