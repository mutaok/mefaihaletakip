-- Bu sorguyu Supabase SQL Editor'de calistirin
-- tender_date ve details sutunlarini ekler (yoksa)

alter table public.tender_folders
  add column if not exists tender_date date;

alter table public.tender_folders
  add column if not exists details jsonb not null default '{}'::jsonb;

-- Mevcut satirlarda details null ise bos obje ata
update public.tender_folders
  set details = '{}'::jsonb
  where details is null;
