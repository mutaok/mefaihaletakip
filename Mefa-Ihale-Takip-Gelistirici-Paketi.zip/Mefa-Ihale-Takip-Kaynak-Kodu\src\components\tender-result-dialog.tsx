"use client";

import { useState } from "react";
import { createPortal } from "react-dom";
import { CheckCircle2, Plus, X } from "lucide-react";

import { setTenderResultAction } from "@/app/actions";
import { SubmitButton } from "@/components/submit-button";
import type { TenderResultBid } from "@/lib/tender-details";

type BidRow = {
  companyName: string;
  bidAmount: string;
  disqualifiedReason: string;
};

const emptyRow = (): BidRow => ({
  companyName: "",
  bidAmount: "",
  disqualifiedReason: "",
});

const cellInputCls =
  "w-full rounded-lg border border-line px-2.5 py-1.5 text-sm outline-none focus:border-accent";

export function TenderResultDialog({
  tenderId,
  existingResult,
}: {
  tenderId: string;
  existingResult: { bids: TenderResultBid[] } | null;
}) {
  const [open, setOpen] = useState(false);
  const [rows, setRows] = useState<BidRow[]>(
    existingResult && existingResult.bids.length > 0
      ? existingResult.bids.map((bid) => ({
          bidAmount: bid.bidAmount,
          companyName: bid.companyName,
          disqualifiedReason: bid.disqualifiedReason ?? "",
        }))
      : [emptyRow()],
  );

  const addRow = () => setRows((prev) => [...prev, emptyRow()]);
  const removeRow = (i: number) =>
    setRows((prev) => prev.filter((_, idx) => idx !== i));
  const updateRow = (i: number, field: keyof BidRow, val: string) =>
    setRows((prev) => {
      const next = [...prev];
      next[i] = { ...next[i], [field]: val };
      return next;
    });

  const bidsJson = JSON.stringify(
    rows
      .filter((row) => row.companyName.trim())
      .map((row) => ({
        bidAmount: row.bidAmount,
        companyName: row.companyName,
        disqualifiedReason: row.disqualifiedReason.trim() || null,
      })),
  );

  return (
    <>
      <button
        type="button"
        onClick={() => setOpen(true)}
        className="inline-flex items-center gap-2 rounded-xl border border-emerald-300 bg-emerald-50 px-4 py-2 text-sm font-semibold text-emerald-700 transition hover:bg-emerald-100"
      >
        <CheckCircle2 className="size-4" />
        {existingResult ? "Sonucu Düzenle" : "İhale Bitti"}
      </button>

      {open &&
        createPortal(
          <div className="fixed inset-0 z-50 overflow-y-auto" role="dialog" aria-modal="true">
            <div
              className="fixed inset-0 bg-black/50 backdrop-blur-sm"
              onClick={() => setOpen(false)}
            />

            <div className="relative mx-auto my-6 w-full max-w-3xl px-4">
              <div className="overflow-hidden rounded-3xl bg-white shadow-2xl">
                <div className="flex items-center justify-between border-b border-line px-8 py-5">
                  <h2 className="text-xl font-bold tracking-tight text-foreground">
                    İhale Sonucu
                  </h2>
                  <button
                    type="button"
                    onClick={() => setOpen(false)}
                    className="grid size-9 place-items-center rounded-full border border-line text-muted transition hover:bg-line"
                  >
                    <X className="size-4" />
                  </button>
                </div>

                <form action={setTenderResultAction}>
                  <input type="hidden" name="tenderId" value={tenderId} />
                  <input type="hidden" name="bidsJson" value={bidsJson} />

                  <div className="space-y-4 p-8">
                    <p className="text-sm text-muted">
                      İhaleye giren firmaları, verdikleri teklifi ve (varsa)
                      ihale dışı kalma sebebini girin.
                    </p>
                    <div className="overflow-x-auto rounded-xl border border-line">
                      <table className="w-full text-sm">
                        <thead>
                          <tr className="bg-line/30">
                            <th className="px-3 py-2.5 text-left text-xs font-semibold uppercase tracking-wide text-muted">
                              Firma İsmi
                            </th>
                            <th className="px-3 py-2.5 text-left text-xs font-semibold uppercase tracking-wide text-muted">
                              Verilen Teklif
                            </th>
                            <th className="px-3 py-2.5 text-left text-xs font-semibold uppercase tracking-wide text-muted">
                              İhale Dışı Kalma Sebebi (varsa)
                            </th>
                            <th className="w-8" />
                          </tr>
                        </thead>
                        <tbody>
                          {rows.map((row, i) => (
                            <tr key={i} className="border-t border-line">
                              <td className="p-1.5">
                                <input
                                  value={row.companyName}
                                  onChange={(e) =>
                                    updateRow(i, "companyName", e.target.value)
                                  }
                                  placeholder="Firma adı"
                                  className={cellInputCls}
                                />
                              </td>
                              <td className="p-1.5">
                                <input
                                  value={row.bidAmount}
                                  onChange={(e) =>
                                    updateRow(i, "bidAmount", e.target.value)
                                  }
                                  placeholder="Örn: 1.250.000 TL"
                                  className={cellInputCls}
                                />
                              </td>
                              <td className="p-1.5">
                                <input
                                  value={row.disqualifiedReason}
                                  onChange={(e) =>
                                    updateRow(i, "disqualifiedReason", e.target.value)
                                  }
                                  placeholder="Boş bırakılabilir"
                                  className={cellInputCls}
                                />
                              </td>
                              <td className="p-1.5">
                                {rows.length > 1 && (
                                  <button
                                    type="button"
                                    onClick={() => removeRow(i)}
                                    className="grid size-7 place-items-center rounded-lg text-muted transition hover:bg-rose-50 hover:text-rose-600"
                                  >
                                    <X className="size-3.5" />
                                  </button>
                                )}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                    <button
                      type="button"
                      onClick={addRow}
                      className="inline-flex items-center gap-2 rounded-xl border border-dashed border-accent/40 px-4 py-2 text-sm font-medium text-accent transition hover:border-accent hover:bg-accent/5"
                    >
                      <Plus className="size-4" />
                      Firma Ekle
                    </button>
                  </div>

                  <div className="flex items-center justify-end gap-3 border-t border-line px-8 py-5">
                    <button
                      type="button"
                      onClick={() => setOpen(false)}
                      className="rounded-xl border border-line px-5 py-2.5 text-sm font-semibold text-foreground transition hover:bg-line/30"
                    >
                      İptal
                    </button>
                    <SubmitButton
                      className="rounded-xl bg-accent px-6 py-2.5 text-sm font-semibold text-white transition hover:bg-accent/90 disabled:opacity-70"
                      pendingLabel="Kaydediliyor..."
                    >
                      Sonucu Kaydet
                    </SubmitButton>
                  </div>
                </form>
              </div>
            </div>
          </div>,
          document.body,
        )}
    </>
  );
}
