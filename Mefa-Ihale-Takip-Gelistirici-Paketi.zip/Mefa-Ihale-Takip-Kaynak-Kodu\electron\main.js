const { app, BrowserWindow, dialog } = require("electron");
const { spawn } = require("child_process");
const path = require("path");
const fs = require("fs");
const net = require("net");
const https = require("https");
const os = require("os");

const isDev = !app.isPackaged;
const PORT = 3000;
const APP_VERSION = "1.3.18";

let mainWindow;
let serverProcess;

// ────────── Güncelleme günlüğü ──────────
// Sessiz başarısızlıkları teşhis edilebilir kılmak için: her önemli adım,
// uygulama nereye kurulu olursa olsun her zaman yazılabilir olan
// userData klasörüne (ör. %APPDATA%\mefa-ihale-takip) kaydedilir.

let updateLogPath = null;

function getUpdateLogPath() {
  if (!updateLogPath) {
    updateLogPath = path.join(app.getPath("userData"), "update-log.txt");
  }
  return updateLogPath;
}

function logUpdate(line) {
  try {
    const logPath = getUpdateLogPath();
    const stamp = new Date().toISOString();
    fs.appendFileSync(logPath, `[${stamp}] ${line}\n`, "utf-8");
    // Yıllar içinde sınırsız büyümesin — 500 KB'ı geçerse sıfırla.
    const stat = fs.statSync(logPath);
    if (stat.size > 500 * 1024) {
      fs.writeFileSync(logPath, `[${stamp}] (gunluk sifirlandi, boyut asildi)\n`, "utf-8");
    }
  } catch {
    // Günlük yazılamıyorsa bile güncelleme akışı bundan etkilenmemeli.
  }
}

// ────────── Helpers ──────────

function getServerDir() {
  if (isDev) {
    return path.join(__dirname, "..");
  }
  return path.join(process.resourcesPath, "server");
}

function findFreePort(startPort) {
  return new Promise((resolve) => {
    const server = net.createServer();
    server.listen(startPort, () => {
      const port = server.address().port;
      server.close(() => resolve(port));
    });
    server.on("error", () => resolve(findFreePort(startPort + 1)));
  });
}

function loadEnvFile(dir) {
  const envPath = path.join(dir, ".env.local");
  if (!fs.existsSync(envPath)) return {};
  const content = fs.readFileSync(envPath, "utf-8");
  const vars = {};
  for (const line of content.split("\n")) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith("#")) continue;
    const eqIndex = trimmed.indexOf("=");
    if (eqIndex === -1) continue;
    const key = trimmed.slice(0, eqIndex).trim();
    let value = trimmed.slice(eqIndex + 1).trim();
    if (
      (value.startsWith('"') && value.endsWith('"')) ||
      (value.startsWith("'") && value.endsWith("'"))
    ) {
      value = value.slice(1, -1);
    }
    vars[key] = value;
  }
  return vars;
}

// ────────── Server ──────────

function startServer(port) {
  const serverDir = getServerDir();

  if (isDev) {
    const npmCmd = process.platform === "win32" ? "npm.cmd" : "npm";
    serverProcess = spawn(npmCmd, ["run", "dev", "--", "--webpack"], {
      cwd: serverDir,
      env: { ...process.env, PORT: String(port) },
      shell: true,
    });
  } else {
    const serverEntry = path.join(serverDir, "server.js");
    const envVars = loadEnvFile(serverDir);

    serverProcess = spawn(process.execPath, [serverEntry], {
      cwd: serverDir,
      env: {
        ...process.env,
        ...envVars,
        ELECTRON_RUN_AS_NODE: "1",
        PORT: String(port),
        HOSTNAME: "localhost",
        NODE_ENV: "production",
      },
    });
  }

  serverProcess.stdout?.on("data", (d) => console.log(String(d)));
  serverProcess.stderr?.on("data", (d) => console.error(String(d)));
  serverProcess.on("error", (err) => {
    console.error("Server failed to start:", err);
    dialog.showErrorBox(
      "Sunucu Hatasi",
      "Next.js sunucusu baslatilamadi. Detay: " + err.message,
    );
  });
}

function waitForServer(port, retries = 60) {
  return new Promise((resolve, reject) => {
    const check = (attempt) => {
      const req = net.createConnection({ port, host: "localhost" }, () => {
        req.destroy();
        resolve();
      });
      req.on("error", () => {
        if (attempt >= retries) {
          reject(new Error("Server did not start in time"));
        } else {
          setTimeout(() => check(attempt + 1), 500);
        }
      });
    };
    check(0);
  });
}

// ────────── Window ──────────

function createWindow(port) {
  const iconPath = isDev
    ? path.join(__dirname, "..", "public", "mefa-logo.png")
    : path.join(process.resourcesPath, "icon.png");

  mainWindow = new BrowserWindow({
    width: 1400,
    height: 900,
    minWidth: 800,
    minHeight: 600,
    show: false, // show after maximize
    icon: iconPath,
    title: "Mefa Group İhale Takip",
    autoHideMenuBar: true,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
    },
  });

  mainWindow.loadURL(`http://localhost:${port}`);

  // Maximize before showing to avoid flicker
  mainWindow.once("ready-to-show", () => {
    mainWindow.maximize();
    mainWindow.show();
    mainWindow.focus();
    // Güncelleme kontrolünü, pencere gerçekten görünür hale geldikten
    // SONRA tetikle — aksi halde soru penceresi kullanıcı görmeden
    // arka planda açılıp cevapsız kalabiliyordu (bkz. logUpdate notları).
    setTimeout(checkForUpdates, 2000);
  });

  mainWindow.on("closed", () => {
    mainWindow = null;
  });
}

// ────────── Auto-update ──────────

function compareVersions(a, b) {
  const pa = String(a).split(".").map(Number);
  const pb = String(b).split(".").map(Number);
  for (let i = 0; i < 3; i++) {
    if ((pa[i] || 0) > (pb[i] || 0)) return 1;
    if ((pa[i] || 0) < (pb[i] || 0)) return -1;
  }
  return 0;
}

function httpGetBuffer(url, headers) {
  return new Promise((resolve, reject) => {
    const makeReq = (reqUrl) => {
      https
        .get(reqUrl, { headers }, (res) => {
          if (
            res.statusCode >= 300 &&
            res.statusCode < 400 &&
            res.headers.location
          ) {
            return makeReq(res.headers.location);
          }
          const chunks = [];
          res.on("data", (c) => chunks.push(c));
          res.on("end", () =>
            resolve({ status: res.statusCode, body: Buffer.concat(chunks) }),
          );
        })
        .on("error", reject);
    };
    makeReq(url);
  });
}

function downloadToFile(url, headers, destPath) {
  return new Promise((resolve, reject) => {
    const makeReq = (reqUrl) => {
      https
        .get(reqUrl, { headers }, (res) => {
          if (
            res.statusCode >= 300 &&
            res.statusCode < 400 &&
            res.headers.location
          ) {
            return makeReq(res.headers.location);
          }
          const out = fs.createWriteStream(destPath);
          res.pipe(out);
          out.on("finish", () => out.close(resolve));
          out.on("error", (err) => {
            fs.unlink(destPath, () => {});
            reject(err);
          });
        })
        .on("error", reject);
    };
    makeReq(url);
  });
}

/**
 * Bir ZIP dosyasının sonunda geçerli bir "End of Central Directory" (EOCD)
 * imzası (PK\x05\x06) olup olmadığını kontrol eder. Boyutu yeterli görünen
 * ama yarım/bozuk inmiş dosyaları (indirme kesintiye uğradığında veya bir
 * CDN eski/kısmi bir kopyayı sunduğunda olur) dosya değiştirme adımına
 * geçmeden önce yakalamak için kullanılır.
 */
function hasValidZipSignature(filePath) {
  try {
    const stat = fs.statSync(filePath);
    const searchWindow = Math.min(stat.size, 65_557); // EOCD (22) + azami yorum (65535)
    const buf = Buffer.alloc(searchWindow);
    const fd = fs.openSync(filePath, "r");
    fs.readSync(fd, buf, 0, searchWindow, stat.size - searchWindow);
    fs.closeSync(fd);
    for (let i = buf.length - 4; i >= 0; i--) {
      if (buf[i] === 0x50 && buf[i + 1] === 0x4b && buf[i + 2] === 0x05 && buf[i + 3] === 0x06) {
        return true;
      }
    }
    return false;
  } catch {
    return false;
  }
}

let updateCheckInProgress = false;

async function checkForUpdates() {
  if (isDev) return; // skip in dev mode

  // Ayni anda iki kontrolun calismasini engelle — cakisan iki calisma,
  // ayni hedef klasoru es zamanli degistirmeye calisip "Dizin bos degil"
  // gibi dosya kilidi hatalarina yol acabiliyordu.
  if (updateCheckInProgress) {
    logUpdate("Guncelleme kontrolu zaten calisiyor, bu cagri atlandi.");
    return;
  }
  updateCheckInProgress = true;

  logUpdate(`Guncelleme kontrolu basladi (mevcut surum: v${APP_VERSION})`);

  try {
    const serverDir = getServerDir();
    const envVars = loadEnvFile(serverDir);
    const supabaseUrl = envVars["NEXT_PUBLIC_SUPABASE_URL"];
    const serviceRoleKey = envVars["SUPABASE_SERVICE_ROLE_KEY"];
    if (!supabaseUrl || !serviceRoleKey) {
      logUpdate("HATA: .env.local icinde Supabase baglanti bilgileri yok, kontrol iptal.");
      return;
    }

    const bucket = "tender-files";
    const headers = { Authorization: `Bearer ${serviceRoleKey}` };
    // Onbellek kirici sorgu parametresi: Supabase Storage/CDN eski surum
    // dosyasini bir sure sunmaya devam edebiliyordu.
    const versionUrl = `${supabaseUrl}/storage/v1/object/${bucket}/_updates/version.json?t=${Date.now()}`;

    const res = await httpGetBuffer(versionUrl, headers);
    if (res.status !== 200) {
      logUpdate(`Surum dosyasi henuz yok veya erisilemedi (HTTP ${res.status}) - normal, sessizce cikiliyor.`);
      return;
    }

    let info;
    try {
      info = JSON.parse(res.body.toString("utf-8"));
    } catch (err) {
      logUpdate(`HATA: version.json ayristirilamadi: ${err.message}`);
      return;
    }

    const latestVersion = info.version;
    if (!latestVersion || compareVersions(latestVersion, APP_VERSION) <= 0) {
      logUpdate(`Zaten guncel (sunucudaki surum: v${latestVersion || "?"})`);
      return;
    }

    logUpdate(`Yeni surum bulundu: v${latestVersion} - kullaniciya soruluyor.`);

    // Pencerenin gorunur ve odakli oldugundan emin ol; aksi halde soru
    // penceresi arka planda acilip kullanici tarafindan hic gorulmeyebilir
    // (yavas acilan bilgisayarlarda gecmiste yasanan sessiz atlama sebebi).
    const win = mainWindow || null;
    if (win && !win.isDestroyed()) {
      if (!win.isVisible()) win.show();
      if (win.isMinimized()) win.restore();
      win.focus();
    }

    // Ask user
    const { response } = await dialog.showMessageBox(win, {
      type: "info",
      title: "Güncelleme Mevcut",
      message: `Yeni sürüm mevcut: v${latestVersion}`,
      detail:
        "Güncelleme indirilecek ve uygulama otomatik olarak yeniden başlatılacak.\n" +
        `Mevcut sürüm: v${APP_VERSION}`,
      buttons: ["Şimdi Güncelle", "Daha Sonra"],
      defaultId: 0,
      cancelId: 1,
    });

    if (response !== 0) {
      logUpdate("Kullanici 'Daha Sonra' secti, guncelleme ertelendi.");
      return;
    }
    logUpdate("Kullanici 'Simdi Guncelle' secti, indirme basliyor.");

    // Prepare download
    const zipFileName = info.file || `update-${latestVersion}.zip`;
    let tmpDir = path.join(os.tmpdir(), "mefa-update");
    fs.mkdirSync(tmpDir, { recursive: true });
    // os.tmpdir() bazı Windows profillerinde kısa ad (8.3, ör. TLAY~1) ile
    // donuyor; bazi PowerShell/.NET cagrilari (Expand-Archive gibi) bu kisa
    // adi guvenilir sekilde cozemiyor. realpathSync tam/uzun yola cevirir.
    try {
      // fs.realpathSync() (saf JS uygulaması) kısa adları (8.3) ÇÖZMÜYOR —
      // yalnızca sembolik bağları çözer, aynı kısa yolu geri döndürür.
      // fs.realpathSync.native() işletim sisteminin kendi çağrısını kullanır
      // ve kısa adı doğru şekilde uzun ada çevirir (test edilip doğrulandı).
      tmpDir = fs.realpathSync.native(tmpDir);
    } catch {
      // olmazsa orijinal yolla devam
    }
    const zipPath = path.join(tmpDir, zipFileName);

    // Onbellek kirici sorgu parametresi + en fazla 3 deneme: bir CDN ucu
    // eski/yarim kalmis bir kopyayi sunuyorsa, her deneme farkli bir URL
    // istegi olarak gorulup taze kopyayi almayi dener.
    let validDownload = false;
    let lastReason = "";
    for (let attempt = 1; attempt <= 3 && !validDownload; attempt++) {
      const zipUrl = `${supabaseUrl}/storage/v1/object/${bucket}/_updates/${zipFileName}?t=${Date.now()}-${attempt}`;
      logUpdate(`Indirme deneme ${attempt}/3: ${zipUrl}`);
      await downloadToFile(zipUrl, headers, zipPath);

      const downloadedSize = fs.existsSync(zipPath) ? fs.statSync(zipPath).size : 0;
      if (downloadedSize < 100_000) {
        lastReason = `dosya cok kucuk (${downloadedSize} bayt)`;
        logUpdate(`Deneme ${attempt} basarisiz: ${lastReason}`);
        continue;
      }
      if (!hasValidZipSignature(zipPath)) {
        lastReason = "ZIP bütünlük imzası (End of Central Directory) bulunamadı — dosya yarım/bozuk indirilmiş";
        logUpdate(`Deneme ${attempt} basarisiz: ${lastReason}`);
        continue;
      }
      validDownload = true;
      logUpdate(`Indirme tamamlandi ve dogrulandi: ${zipPath} (${downloadedSize} bayt)`);
    }

    if (!validDownload) {
      logUpdate(`HATA: 3 denemeden sonra gecerli bir guncelleme dosyasi alinamadi (${lastReason}).`);
      dialog.showErrorBox(
        "Güncelleme Başarısız",
        `Güncelleme dosyası 3 denemede de bozuk indi (${lastReason}). ` +
          "İnternet bağlantınızı kontrol edip uygulamayı daha sonra tekrar açmayı deneyin. " +
          `Ayrıntılar: ${getUpdateLogPath()}`,
      );
      fs.unlink(zipPath, () => {});
      return;
    }

    // Confirm restart
    dialog.showMessageBoxSync(win, {
      type: "info",
      title: "Güncelleme Hazır",
      message: "Güncelleme başarıyla indirildi.",
      detail: "Tamam'a basın — uygulama yeniden başlatılacak.",
      buttons: ["Tamam"],
    });

    // Build PowerShell updater script
    let resourcesPath = process.resourcesPath;
    try {
      resourcesPath = fs.realpathSync.native(resourcesPath);
    } catch {
      // olmazsa orijinal yolla devam
    }
    const serverPath = path.join(resourcesPath, "server");
    const exePath = process.execPath;
    const psLog = getUpdateLogPath();

    // Single-quoted PS strings: only apostrophes need escaping (doubled)
    const q = (p) => `'${p.replace(/'/g, "''")}'`;

    const psLines = [
      "$ErrorActionPreference = 'Stop'",
      `$zip  = ${q(zipPath)}`,
      `$dest = ${q(resourcesPath)}`,
      `$srv  = ${q(serverPath)}`,
      `$exe  = ${q(exePath)}`,
      `$log  = ${q(psLog)}`,
      "function Log($msg) { \"[$(Get-Date -Format o)] [PS] $msg\" | Out-File -FilePath $log -Append -Encoding utf8 }",
      "Log 'Updater.ps1 baslatildi.'",
      "try {",
      "  # Uygulama tamamen kapanana kadar bekle (en fazla 15 sn)",
      "  $exeName = [System.IO.Path]::GetFileNameWithoutExtension($exe)",
      "  $closed = $false",
      "  for ($i = 0; $i -lt 30; $i++) {",
      "    if (-not (Get-Process -Name $exeName -ErrorAction SilentlyContinue)) { $closed = $true; break }",
      "    Start-Sleep -Milliseconds 500",
      "  }",
      "  Log \"Uygulama kapanma bekleme sonucu: kapandi=$closed\"",
      "  Start-Sleep -Seconds 1",
      "  # Once gecici klasore cikar; basarisiz olursa mevcut kurulum bozulmaz",
      "  $staging = Join-Path (Split-Path $zip) 'staging'",
      "  if (Test-Path $staging) { Remove-Item -Recurse -Force $staging }",
      "  Expand-Archive -Path $zip -DestinationPath $staging -Force",
      "  Log 'Zip acildi, dosyalar tasiniyor.'",
      "  # Cikarilan her ogeyi (server, app.asar, vb.) hedefe tasi",
      "  Get-ChildItem -LiteralPath $staging | ForEach-Object {",
      "    $target = Join-Path $dest $_.Name",
      "    if (Test-Path $target) { Remove-Item -Recurse -Force $target }",
      "    Move-Item -LiteralPath $_.FullName -Destination $target",
      "  }",
      "  Remove-Item -Recurse -Force $staging -ErrorAction SilentlyContinue",
      "  Remove-Item -Force $zip -ErrorAction SilentlyContinue",
      "  Log 'Guncelleme basariyla uygulandi, uygulama yeniden baslatiliyor.'",
      "  Start-Process $exe",
      "} catch {",
      "  Log \"HATA: $($_.Exception.Message)\"",
      "  Add-Type -AssemblyName System.Windows.Forms",
      "  [System.Windows.Forms.MessageBox]::Show(\"Guncelleme basarisiz: \" + $_.Exception.Message + \" Detay: \" + $log, 'MEFA Guncelleme') | Out-Null",
      "  Start-Process $exe",
      "}",
    ];

    const psPath = path.join(tmpDir, "updater.ps1");
    // BOM sart: BOM'suz dosyayi PowerShell 5.1 ANSI okur ve Turkce
    // karakterli yollar (or. C:\Users\BILGISAYARIM) bozulur
    fs.writeFileSync(psPath, "\uFEFF" + psLines.join("\r\n"), "utf-8");

    logUpdate(`PowerShell guncelleyici baslatiliyor: ${psPath}`);
    // ÖNEMLİ: powershell.exe'yi doğrudan spawn(detached:true) ile başlatmak
    // GÜVENİLMEZ — Electron'un çalıştığı Windows İş Nesnesi (Job Object),
    // ana süreç kapanınca "detached" alt süreci de öldürebiliyor; bu da
    // güncellemenin sessizce hiç uygulanmamasının ana sebebiydi (test edilip
    // doğrulandı). cmd.exe /c start ile sarmalamak, süreci İş Nesnesinden
    // koparıp ana uygulama kapansa bile tamamlanmasını garanti ediyor.
    const updaterProcess = spawn(
      "cmd.exe",
      [
        "/c",
        "start",
        "",
        "/min",
        "powershell.exe",
        "-ExecutionPolicy",
        "Bypass",
        "-WindowStyle",
        "Hidden",
        "-File",
        psPath,
      ],
      { detached: true, stdio: "ignore", windowsHide: true },
    );
    updaterProcess.on("error", (err) => {
      // cmd.exe/powershell.exe baslatilamadi (antivirus engeli, PATH sorunu vb.)
      logUpdate(`HATA: Guncelleyici baslatilamadi: ${err.message}`);
    });
    updaterProcess.unref();

    app.quit();
  } catch (err) {
    logUpdate(`HATA: Guncelleme kontrolu basarisiz oldu: ${err.stack || err.message}`);
    dialog.showErrorBox(
      "Güncelleme Kontrolü Başarısız",
      `Güncelleme kontrol edilirken bir hata oluştu: ${err.message}\n\n` +
        `Ayrıntılar için: ${getUpdateLogPath()}`,
    );
  } finally {
    updateCheckInProgress = false;
  }
}

// ────────── App lifecycle ──────────

app.on("ready", async () => {
  try {
    const port = await findFreePort(PORT);
    startServer(port);
    await waitForServer(port);
    createWindow(port);
    // Not: güncelleme kontrolü artık pencere gerçekten görünür olduğunda
    // (ready-to-show içinde) tetikleniyor, burada değil.
  } catch (err) {
    dialog.showErrorBox("Baslangic Hatasi", err.message);
    app.quit();
  }
});

app.on("window-all-closed", () => {
  if (serverProcess) {
    serverProcess.kill();
  }
  app.quit();
});

app.on("before-quit", () => {
  if (serverProcess) {
    serverProcess.kill();
  }
});
