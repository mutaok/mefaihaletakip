"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";

import { slugify } from "@/lib/format";
import {
  buildTenderDetails,
  normalizeTechnicalStaff,
  normalizeTenderResultBids,
  readDeletedAt,
  readDocumentFolders,
  readRequiredDocuments,
  readTenderResult,
  type TechnicalStaffItem,
  type TenderResultBid,
  withDeletedAt,
  withDocumentFolders,
  withRequiredDocuments,
  withTenderResult,
} from "@/lib/tender-details";
import {
  fetchGuaranteeLetterReturns,
  saveGuaranteeLetterReturns,
} from "@/lib/guarantee-letters";
import {
  deleteCalendarEvent,
  taskCalendarEventId,
  tenderCalendarEventId,
  upsertCalendarEvent,
} from "@/lib/google-calendar";
import {
  createSupabaseAdminClient,
  SUPABASE_BUCKET,
} from "@/lib/supabase/server";

function readText(value: FormDataEntryValue | null): string {
  return typeof value === "string" ? value.trim() : "";
}

function readOptionalText(value: FormDataEntryValue | null): string | null {
  const text = readText(value);
  return text ? text : null;
}

function readDate(value: FormDataEntryValue | null): string | null {
  const text = readText(value);
  return /^\d{4}-\d{2}-\d{2}$/.test(text) ? text : null;
}

function readBooleanChoice(value: FormDataEntryValue | null): boolean | null {
  const text = readText(value);

  if (text === "yes") {
    return true;
  }

  if (text === "no") {
    return false;
  }

  return null;
}

function readTechnicalStaff(value: FormDataEntryValue | null): TechnicalStaffItem[] {
  if (typeof value !== "string" || !value.trim()) {
    return [];
  }

  try {
    return normalizeTechnicalStaff(JSON.parse(value));
  } catch {
    return [];
  }
}

function redirectWithCode(
  pathname: string,
  kind: "error" | "success",
  code: string,
): never {
  const params = new URLSearchParams({ [kind]: code });
  redirect(`${pathname}?${params.toString()}`);
}

const MAX_UPLOAD_FILE_SIZE = 200 * 1024 * 1024; // 200 MB

async function ensureStorageBucketLimit(
  supabase: ReturnType<typeof createSupabaseAdminClient>,
) {
  if (!supabase) return;
  // Bucket'ın dosya boyutu limitini 200 MB olarak ayarla (sessiz başarısızlık)
  try {
    await supabase.storage.updateBucket(SUPABASE_BUCKET, {
      public: false,
      fileSizeLimit: MAX_UPLOAD_FILE_SIZE,
    });
  } catch {
    // Sessizce geç — bu çağrı zorunlu değil
  }
}

const DOCUMENT_MIME_BY_EXTENSION: Record<string, string> = {
  ".doc": "application/msword",
  ".docx":
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  ".pdf": "application/pdf",
  ".xls": "application/vnd.ms-excel",
  ".xlsx":
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
};

const SUPPORTED_DOCUMENT_MIME_TYPES = new Set(
  Object.values(DOCUMENT_MIME_BY_EXTENSION),
);

function getFileExtension(fileName: string): string {
  const match = /\.[a-z0-9]+$/i.exec(fileName);
  return match ? match[0].toLowerCase() : "";
}

function getDocumentMimeType(file: File): string | null {
  const normalizedType = file.type.toLowerCase();

  if (SUPPORTED_DOCUMENT_MIME_TYPES.has(normalizedType)) {
    return normalizedType;
  }

  const extension = getFileExtension(file.name);
  return DOCUMENT_MIME_BY_EXTENSION[extension] ?? null;
}

function buildDocumentStoragePath(params: {
  displayName: string;
  fileName: string;
  folderSegment?: string | null;
  tenderId: string;
}): string {
  const extension = getFileExtension(params.fileName);
  const folderPrefix = params.folderSegment ? `${params.folderSegment}/` : "";

  return `${params.tenderId}/${folderPrefix}${Date.now()}-${crypto.randomUUID()}-${slugify(params.displayName)}${extension}`;
}

function normalizeFolderNameForCompare(value: string): string {
  return value.trim().toLocaleLowerCase("tr-TR");
}

export async function createTenderDocumentFolderAction(formData: FormData) {
  const supabase = createSupabaseAdminClient();
  const tenderId = readText(formData.get("tenderId"));

  if (!supabase) {
    redirectWithCode(`/tenders/${tenderId || ""}`, "error", "supabase-missing");
  }

  if (!tenderId) {
    redirectWithCode("/", "error", "folder-not-found");
  }

  const folderName = readText(formData.get("folderName"));

  if (!folderName) {
    redirectWithCode(
      `/tenders/${tenderId}`,
      "error",
      "invalid-document-folder-name",
    );
  }

  const { data: tender, error: tenderError } = await supabase
    .from("tender_folders")
    .select("id, details")
    .eq("id", tenderId)
    .maybeSingle();

  if (tenderError || !tender) {
    redirectWithCode(`/tenders/${tenderId}`, "error", "folder-not-found");
  }

  const existingFolders = readDocumentFolders(tender.details);

  if (
    existingFolders.some(
      (existingFolder) =>
        normalizeFolderNameForCompare(existingFolder) ===
        normalizeFolderNameForCompare(folderName),
    )
  ) {
    redirectWithCode(`/tenders/${tenderId}`, "error", "document-folder-name-taken");
  }

  const { error } = await supabase
    .from("tender_folders")
    .update({
      details: withDocumentFolders(tender.details, [...existingFolders, folderName]),
    })
    .eq("id", tenderId);

  if (error) {
    redirectWithCode(
      `/tenders/${tenderId}`,
      "error",
      "document-folder-create-failed",
    );
  }

  revalidatePath("/");
  revalidatePath(`/tenders/${tenderId}`);
  redirect(`/tenders/${tenderId}?success=document-folder-created`);
}

export async function createTenderFolderAction(formData: FormData) {
  const supabase = createSupabaseAdminClient();

  if (!supabase) {
    redirectWithCode("/", "error", "supabase-missing");
  }

  const title = readText(formData.get("title"));
  const referenceCode = readText(formData.get("referenceCode"));
  const authority = readText(formData.get("authority"));
  const tenderDate = readDate(formData.get("tenderDate"));

  if (!title) {
    redirectWithCode("/", "error", "invalid-folder-data");
  }

  const details = buildTenderDetails({
    advanceAmount: readOptionalText(formData.get("advanceAmount")),
    advancePayment: readBooleanChoice(formData.get("advancePayment")),
    company: readOptionalText(formData.get("company")),
    currency: readOptionalText(formData.get("currency")),
    deliveryDuration: readOptionalText(formData.get("deliveryDuration")),
    evaluationCriteria: null,
    finalGuarantee: readOptionalText(formData.get("finalGuarantee")),
    otherNotes: readOptionalText(formData.get("otherNotes")),
    participationMethod: readOptionalText(formData.get("participationMethod")),
    priceDifference: readOptionalText(formData.get("priceDifference")),
    requiredDocuments: [],
    requiresBankReference: readBooleanChoice(
      formData.get("requiresBankReference"),
    ),
    submissionMethod: readOptionalText(formData.get("submissionMethod")),
    technicalStaff: readTechnicalStaff(formData.get("technicalStaffJson")),
    temporaryGuarantee: readOptionalText(formData.get("temporaryGuarantee")),
    workDuration: readOptionalText(formData.get("workDuration")),
  });

  const { data, error } = await supabase
    .from("tender_folders")
    .insert({
      authority,
      description: "",
      details,
      il: "",
      ilce: "",
      latitude: 0,
      location_name: "",
      longitude: 0,
      reference_code: referenceCode,
      tender_date: tenderDate,
      title,
    })
    .select("id")
    .single();

  if (error || !data) {
    redirectWithCode("/", "error", "folder-create-failed");
  }

  if (tenderDate) {
    await upsertCalendarEvent({
      date: tenderDate,
      id: tenderCalendarEventId(data.id),
      title: title,
    });
  }

  revalidatePath("/");
  redirect(`/tenders/${data.id}?success=folder-created`);
}

export async function updateTenderAction(formData: FormData) {
  const supabase = createSupabaseAdminClient();

  if (!supabase) {
    redirectWithCode("/", "error", "supabase-missing");
  }

  const tenderId = readText(formData.get("tenderId"));
  const title = readText(formData.get("title"));
  const referenceCode = readText(formData.get("referenceCode"));
  const authority = readText(formData.get("authority"));
  const tenderDate = readDate(formData.get("tenderDate"));

  if (!tenderId || !title) {
    redirectWithCode(`/tenders/${tenderId}`, "error", "invalid-folder-data");
  }

  const { data: existingTender, error: existingTenderError } = await supabase
    .from("tender_folders")
    .select("details")
    .eq("id", tenderId)
    .maybeSingle();

  if (existingTenderError || !existingTender) {
    redirectWithCode(`/tenders/${tenderId}`, "error", "folder-not-found");
  }

  const details = withDeletedAt(
    withTenderResult(
      withRequiredDocuments(
        withDocumentFolders(
          buildTenderDetails({
            advanceAmount: readOptionalText(formData.get("advanceAmount")),
            advancePayment: readBooleanChoice(formData.get("advancePayment")),
            company: readOptionalText(formData.get("company")),
            currency: readOptionalText(formData.get("currency")),
            deliveryDuration: readOptionalText(formData.get("deliveryDuration")),
            evaluationCriteria: null,
            finalGuarantee: readOptionalText(formData.get("finalGuarantee")),
            otherNotes: readOptionalText(formData.get("otherNotes")),
            participationMethod: readOptionalText(formData.get("participationMethod")),
            priceDifference: readOptionalText(formData.get("priceDifference")),
            requiredDocuments: [],
            requiresBankReference: readBooleanChoice(
              formData.get("requiresBankReference"),
            ),
            submissionMethod: readOptionalText(formData.get("submissionMethod")),
            technicalStaff: readTechnicalStaff(formData.get("technicalStaffJson")),
            temporaryGuarantee: readOptionalText(formData.get("temporaryGuarantee")),
            workDuration: readOptionalText(formData.get("workDuration")),
          }),
          readDocumentFolders(existingTender.details),
        ),
        readRequiredDocuments(existingTender.details),
      ),
      readTenderResult(existingTender.details),
    ),
    readDeletedAt(existingTender.details),
  );

  const { error } = await supabase
    .from("tender_folders")
    .update({
      authority: authority || null,
      details,
      reference_code: referenceCode || null,
      tender_date: tenderDate,
      title,
    })
    .eq("id", tenderId);
    // Not: latitude/longitude/il/ilce/description güncellenmez, INSERT'te varsayılan değer verildi

  if (error) {
    redirectWithCode(`/tenders/${tenderId}`, "error", "update-failed");
  }

  if (tenderDate) {
    await upsertCalendarEvent({ date: tenderDate, id: tenderCalendarEventId(tenderId), title });
  } else {
    await deleteCalendarEvent(tenderCalendarEventId(tenderId));
  }

  revalidatePath("/");
  revalidatePath(`/tenders/${tenderId}`);
  redirect(`/tenders/${tenderId}?success=tender-updated`);
}

function readTenderResultBids(value: FormDataEntryValue | null): TenderResultBid[] {
  if (typeof value !== "string" || !value.trim()) {
    return [];
  }

  try {
    return normalizeTenderResultBids(JSON.parse(value));
  } catch {
    return [];
  }
}

export async function setTenderResultAction(formData: FormData) {
  const supabase = createSupabaseAdminClient();
  const tenderId = readText(formData.get("tenderId"));

  if (!supabase) {
    redirectWithCode(`/tenders/${tenderId || ""}`, "error", "supabase-missing");
  }

  if (!tenderId) {
    redirectWithCode("/", "error", "folder-not-found");
  }

  const bids = readTenderResultBids(formData.get("bidsJson"));

  if (bids.length === 0) {
    redirectWithCode(`/tenders/${tenderId}`, "error", "invalid-tender-result");
  }

  const { data: tender, error: fetchError } = await supabase
    .from("tender_folders")
    .select("id, details")
    .eq("id", tenderId)
    .maybeSingle();

  if (fetchError || !tender) {
    redirectWithCode(`/tenders/${tenderId}`, "error", "folder-not-found");
  }

  const { error } = await supabase
    .from("tender_folders")
    .update({
      details: withTenderResult(tender.details, {
        bids,
        finishedAt: new Date().toISOString(),
      }),
    })
    .eq("id", tenderId);

  if (error) {
    redirectWithCode(`/tenders/${tenderId}`, "error", "update-failed");
  }

  revalidatePath("/");
  revalidatePath("/gecmis-ihaleler");
  revalidatePath(`/tenders/${tenderId}`);
  redirect(`/tenders/${tenderId}?success=tender-result-saved`);
}

export async function uploadTenderDocumentAction(formData: FormData) {
  const supabase = createSupabaseAdminClient();
  const tenderId = readText(formData.get("tenderId"));

  if (!supabase) {
    redirectWithCode(`/tenders/${tenderId || ""}`, "error", "supabase-missing");
  }

  if (!tenderId) {
    redirectWithCode("/", "error", "folder-not-found");
  }

  // Bucket limitini 200 MB olarak güncelle
  await ensureStorageBucketLimit(supabase);

  const displayName = readText(formData.get("displayName"));
  const folderName = readOptionalText(formData.get("folderName"));
  const file = formData.get("file");

  if (!displayName) {
    redirectWithCode(
      `/tenders/${tenderId}`,
      "error",
      "invalid-document-name",
    );
  }

  if (!(file instanceof File) || file.size === 0) {
    redirectWithCode(`/tenders/${tenderId}`, "error", "invalid-document");
  }

  if (file.size > MAX_UPLOAD_FILE_SIZE) {
    redirectWithCode(`/tenders/${tenderId}`, "error", "file-too-large");
  }

  const mimeType = getDocumentMimeType(file);

  if (!mimeType) {
    redirectWithCode(`/tenders/${tenderId}`, "error", "invalid-document");
  }

  const { data: tender, error: tenderError } = await supabase
    .from("tender_folders")
    .select("id, details")
    .eq("id", tenderId)
    .maybeSingle();

  if (tenderError || !tender) {
    redirectWithCode(`/tenders/${tenderId}`, "error", "folder-not-found");
  }

  const existingFolders = readDocumentFolders(tender.details);

  if (
    folderName &&
    !existingFolders.some(
      (existingFolder) =>
        normalizeFolderNameForCompare(existingFolder) ===
        normalizeFolderNameForCompare(folderName),
    )
  ) {
    redirectWithCode(`/tenders/${tenderId}`, "error", "invalid-document-folder");
  }

  const folderSegment = folderName ? slugify(folderName) : null;
  const storagePath = buildDocumentStoragePath({
    displayName,
    fileName: file.name,
    folderSegment,
    tenderId,
  });

  const { error: uploadError } = await supabase.storage
    .from(SUPABASE_BUCKET)
    .upload(storagePath, Buffer.from(await file.arrayBuffer()), {
      contentType: mimeType,
      upsert: false,
    });

  if (uploadError) {
    redirectWithCode(`/tenders/${tenderId}`, "error", "upload-failed");
  }

  const { error: insertError } = await supabase.from("tender_documents").insert({
    display_name: displayName,
    file_size: file.size,
    mime_type: mimeType,
    original_filename: file.name,
    storage_path: storagePath,
    tender_id: tenderId,
  });

  if (insertError) {
    await supabase.storage.from(SUPABASE_BUCKET).remove([storagePath]);
    redirectWithCode(`/tenders/${tenderId}`, "error", "upload-failed");
  }

  revalidatePath("/");
  revalidatePath(`/tenders/${tenderId}`);
  redirect(`/tenders/${tenderId}?success=upload-complete`);
}

export async function uploadFolderDocumentsAction(formData: FormData) {
  const supabase = createSupabaseAdminClient();
  const tenderId = readText(formData.get("tenderId"));

  if (!supabase) {
    redirectWithCode(`/tenders/${tenderId || ""}`, "error", "supabase-missing");
  }

  if (!tenderId) {
    redirectWithCode("/", "error", "folder-not-found");
  }

  // Bucket limitini 200 MB olarak güncelle
  await ensureStorageBucketLimit(supabase);

  const folderName = readOptionalText(formData.get("folderName"));
  const folderSegment = folderName ? slugify(folderName) : null;

  const rawFiles = formData.getAll("files");
  const files = rawFiles.filter(
    (f): f is File => f instanceof File && f.size > 0,
  );

  const validFiles = files.filter(
    (f) => getDocumentMimeType(f) !== null && f.size <= MAX_UPLOAD_FILE_SIZE,
  );

  if (validFiles.length === 0) {
    redirectWithCode(`/tenders/${tenderId}`, "error", "no-valid-files");
  }

  const results = await Promise.allSettled(
    validFiles.map(async (file) => {
      const mimeType = getDocumentMimeType(file)!;
      const displayName = file.name.replace(/\.[^.]+$/, "");
      const storagePath = buildDocumentStoragePath({
        displayName,
        fileName: file.name,
        folderSegment,
        tenderId,
      });

      const { error: uploadError } = await supabase!.storage
        .from(SUPABASE_BUCKET)
        .upload(storagePath, Buffer.from(await file.arrayBuffer()), {
          contentType: mimeType,
          upsert: false,
        });

      if (uploadError) throw new Error(uploadError.message);

      const { error: insertError } = await supabase!
        .from("tender_documents")
        .insert({
          display_name: displayName,
          file_size: file.size,
          mime_type: mimeType,
          original_filename: file.name,
          storage_path: storagePath,
          tender_id: tenderId,
        });

      if (insertError) {
        await supabase!.storage.from(SUPABASE_BUCKET).remove([storagePath]);
        throw new Error(insertError.message);
      }
    }),
  );

  const hasSuccess = results.some((r) => r.status === "fulfilled");
  if (!hasSuccess) {
    redirectWithCode(`/tenders/${tenderId}`, "error", "upload-failed");
  }

  revalidatePath("/");
  revalidatePath(`/tenders/${tenderId}`);
  redirect(`/tenders/${tenderId}?success=folder-upload-complete`);
}

export async function getDocumentDownloadUrl(
  tenderId: string,
  documentId: string,
): Promise<string | null> {
  const supabase = createSupabaseAdminClient();
  if (!supabase || !tenderId || !documentId) return null;

  const { data: doc } = await supabase
    .from("tender_documents")
    .select("storage_path")
    .eq("id", documentId)
    .eq("tender_id", tenderId)
    .maybeSingle();

  if (!doc) return null;

  const { data } = await supabase.storage
    .from(SUPABASE_BUCKET)
    .createSignedUrl(doc.storage_path, 60 * 60);

  return data?.signedUrl ?? null;
}

export async function deleteTenderDocumentAction(formData: FormData) {
  const supabase = createSupabaseAdminClient();
  const tenderId = readText(formData.get("tenderId"));
  const documentId = readText(formData.get("documentId"));

  if (!supabase) {
    redirectWithCode(`/tenders/${tenderId || ""}`, "error", "supabase-missing");
  }

  if (!tenderId || !documentId) {
    redirectWithCode(
      `/tenders/${tenderId || ""}`,
      "error",
      "document-not-found",
    );
  }

  const { data: doc } = await supabase
    .from("tender_documents")
    .select("storage_path")
    .eq("id", documentId)
    .eq("tender_id", tenderId)
    .maybeSingle();

  if (!doc) {
    redirectWithCode(`/tenders/${tenderId}`, "error", "document-not-found");
  }

  await supabase.storage.from(SUPABASE_BUCKET).remove([doc.storage_path]);

  const { error } = await supabase
    .from("tender_documents")
    .delete()
    .eq("id", documentId)
    .eq("tender_id", tenderId);

  if (error) {
    redirectWithCode(`/tenders/${tenderId}`, "error", "delete-failed");
  }

  revalidatePath("/");
  revalidatePath(`/tenders/${tenderId}`);
  redirect(`/tenders/${tenderId}?success=document-deleted`);
}

export async function deleteTenderFolderAction(formData: FormData) {
  const supabase = createSupabaseAdminClient();
  const tenderId = readText(formData.get("tenderId"));

  if (!supabase) {
    redirectWithCode("/", "error", "supabase-missing");
  }

  if (!tenderId) {
    redirectWithCode("/", "error", "folder-not-found");
  }

  const { data: docs } = await supabase
    .from("tender_documents")
    .select("storage_path")
    .eq("tender_id", tenderId);

  if (docs && docs.length > 0) {
    const paths = docs.map((d) => d.storage_path);
    await supabase.storage.from(SUPABASE_BUCKET).remove(paths);
  }

  const { error } = await supabase
    .from("tender_folders")
    .delete()
    .eq("id", tenderId);

  if (error) {
    redirectWithCode("/", "error", "folder-delete-failed");
  }

  revalidatePath("/");
  redirect("/?success=folder-deleted");
}

export async function renameTenderDocumentAction(formData: FormData) {
  const supabase = createSupabaseAdminClient();
  const tenderId = readText(formData.get("tenderId"));
  const documentId = readText(formData.get("documentId"));
  const displayName = readText(formData.get("displayName"));

  if (!supabase) {
    redirectWithCode(`/tenders/${tenderId || ""}`, "error", "supabase-missing");
  }

  if (!tenderId) {
    redirectWithCode("/", "error", "folder-not-found");
  }

  if (!documentId) {
    redirectWithCode(`/tenders/${tenderId}`, "error", "document-not-found");
  }

  if (!displayName) {
    redirectWithCode(
      `/tenders/${tenderId}`,
      "error",
      "invalid-document-name",
    );
  }

  const { data, error } = await supabase
    .from("tender_documents")
    .update({ display_name: displayName })
    .eq("id", documentId)
    .eq("tender_id", tenderId)
    .select("id")
    .maybeSingle();

  if (error || !data) {
    redirectWithCode(`/tenders/${tenderId}`, "error", "rename-failed");
  }

  revalidatePath(`/tenders/${tenderId}`);
  redirect(`/tenders/${tenderId}?success=document-renamed`);
}

// ── Tek dosya yükleme (klasör yükleme için, client döngüsünde kullanılır) ────
export async function uploadSingleFileForFolderReturnAction(
  formData: FormData,
): Promise<{ ok: true } | { ok: false; error: string }> {
  const supabase = createSupabaseAdminClient();
  const tenderId = readText(formData.get("tenderId"));

  if (!supabase) return { ok: false, error: "supabase-missing" };
  if (!tenderId) return { ok: false, error: "no-tender" };

  const folderName = readOptionalText(formData.get("folderName"));
  const folderSegment = folderName ? slugify(folderName) : null;

  const file = formData.get("file");
  if (!(file instanceof File) || file.size === 0) return { ok: false, error: "no-file" };

  const mimeType = getDocumentMimeType(file);
  if (!mimeType) return { ok: false, error: "invalid-type" };
  if (file.size > MAX_UPLOAD_FILE_SIZE) return { ok: false, error: "too-large" };

  const displayName = file.name.replace(/\.[^.]+$/, "");
  const storagePath = buildDocumentStoragePath({
    displayName,
    fileName: file.name,
    folderSegment,
    tenderId,
  });

  const { error: uploadError } = await supabase.storage
    .from(SUPABASE_BUCKET)
    .upload(storagePath, Buffer.from(await file.arrayBuffer()), {
      contentType: mimeType,
      upsert: false,
    });

  if (uploadError) return { ok: false, error: uploadError.message };

  const { error: insertError } = await supabase.from("tender_documents").insert({
    display_name: displayName,
    file_size: file.size,
    mime_type: mimeType,
    original_filename: file.name,
    storage_path: storagePath,
    tender_id: tenderId,
  });

  if (insertError) {
    await supabase.storage.from(SUPABASE_BUCKET).remove([storagePath]);
    return { ok: false, error: insertError.message };
  }

  return { ok: true };
}

// ── Return-based folder upload (client yönlendirmesi için) ──────────────────
export async function uploadFolderDocumentsReturnAction(
  formData: FormData,
): Promise<{ ok: true; redirectTo: string } | { ok: false; errorCode: string }> {
  const supabase = createSupabaseAdminClient();
  const tenderId = readText(formData.get("tenderId"));

  if (!supabase) return { ok: false, errorCode: "supabase-missing" };
  if (!tenderId) return { ok: false, errorCode: "folder-not-found" };

  await ensureStorageBucketLimit(supabase);

  const folderName = readOptionalText(formData.get("folderName"));
  const folderSegment = folderName ? slugify(folderName) : null;

  const rawFiles = formData.getAll("files");
  const files = rawFiles.filter(
    (f): f is File => f instanceof File && f.size > 0,
  );
  const validFiles = files.filter(
    (f) => getDocumentMimeType(f) !== null && f.size <= MAX_UPLOAD_FILE_SIZE,
  );

  if (validFiles.length === 0) {
    return { ok: false, errorCode: "no-valid-files" };
  }

  const results = await Promise.allSettled(
    validFiles.map(async (file) => {
      const mimeType = getDocumentMimeType(file)!;
      const displayName = file.name.replace(/\.[^.]+$/, "");
      const storagePath = buildDocumentStoragePath({
        displayName,
        fileName: file.name,
        folderSegment,
        tenderId,
      });

      const { error: uploadError } = await supabase!.storage
        .from(SUPABASE_BUCKET)
        .upload(storagePath, Buffer.from(await file.arrayBuffer()), {
          contentType: mimeType,
          upsert: false,
        });

      if (uploadError) throw new Error(uploadError.message);

      const { error: insertError } = await supabase!
        .from("tender_documents")
        .insert({
          display_name: displayName,
          file_size: file.size,
          mime_type: mimeType,
          original_filename: file.name,
          storage_path: storagePath,
          tender_id: tenderId,
        });

      if (insertError) {
        await supabase!.storage.from(SUPABASE_BUCKET).remove([storagePath]);
        throw new Error(insertError.message);
      }
    }),
  );

  const hasSuccess = results.some((r) => r.status === "fulfilled");
  if (!hasSuccess) return { ok: false, errorCode: "upload-failed" };

  revalidatePath("/");
  revalidatePath(`/tenders/${tenderId}`);
  return { ok: true, redirectTo: `/tenders/${tenderId}?success=folder-upload-complete` };
}

// ── Cop Kutusu (Soft Delete / Restore / Permanent Delete) ─────────────────

export async function softDeleteTenderAction(formData: FormData) {
  const supabase = createSupabaseAdminClient();
  const tenderId = readText(formData.get("tenderId"));

  if (!supabase) redirectWithCode("/", "error", "supabase-missing");
  if (!tenderId) redirectWithCode("/", "error", "folder-not-found");

  const { data: tender, error: fetchError } = await supabase
    .from("tender_folders")
    .select("id, details")
    .eq("id", tenderId)
    .maybeSingle();

  if (fetchError || !tender) redirectWithCode("/", "error", "folder-not-found");

  const { error } = await supabase
    .from("tender_folders")
    .update({ details: withDeletedAt(tender.details, new Date().toISOString()) })
    .eq("id", tenderId);

  if (error) redirectWithCode("/", "error", "folder-delete-failed");

  await deleteCalendarEvent(tenderCalendarEventId(tenderId));

  revalidatePath("/");
  revalidatePath("/trash");
  redirect("/?success=tender-trashed");
}

export async function restoreTenderAction(formData: FormData) {
  const supabase = createSupabaseAdminClient();
  const tenderId = readText(formData.get("tenderId"));

  if (!supabase) redirectWithCode("/trash", "error", "supabase-missing");
  if (!tenderId) redirectWithCode("/trash", "error", "folder-not-found");

  const { data: tender, error: fetchError } = await supabase
    .from("tender_folders")
    .select("id, details, title, tender_date")
    .eq("id", tenderId)
    .maybeSingle();

  if (fetchError || !tender) redirectWithCode("/trash", "error", "folder-not-found");

  const { error } = await supabase
    .from("tender_folders")
    .update({ details: withDeletedAt(tender.details, null) })
    .eq("id", tenderId);

  if (error) redirectWithCode("/trash", "error", "update-failed");

  if (tender.tender_date) {
    await upsertCalendarEvent({
      date: tender.tender_date,
      id: tenderCalendarEventId(tenderId),
      title: tender.title,
    });
  }

  revalidatePath("/");
  revalidatePath("/trash");
  revalidatePath(`/tenders/${tenderId}`);
  redirect("/trash?success=tender-restored");
}

export async function permanentDeleteTenderAction(formData: FormData) {
  const supabase = createSupabaseAdminClient();
  const tenderId = readText(formData.get("tenderId"));

  if (!supabase) redirectWithCode("/trash", "error", "supabase-missing");
  if (!tenderId) redirectWithCode("/trash", "error", "folder-not-found");

  const { data: docs } = await supabase
    .from("tender_documents")
    .select("storage_path")
    .eq("tender_id", tenderId);

  if (docs && docs.length > 0) {
    await supabase.storage.from(SUPABASE_BUCKET).remove(docs.map((d) => d.storage_path));
  }

  const { error } = await supabase
    .from("tender_folders")
    .delete()
    .eq("id", tenderId);

  if (error) redirectWithCode("/trash", "error", "folder-delete-failed");

  await deleteCalendarEvent(tenderCalendarEventId(tenderId));

  revalidatePath("/");
  revalidatePath("/trash");
  redirect("/trash?success=tender-permanently-deleted");
}

// ── Istenilen Evraklar Checklist ──────────────────────────────────────────

export async function addRequiredDocumentAction(formData: FormData) {
  const supabase = createSupabaseAdminClient();
  const tenderId = readText(formData.get("tenderId"));

  if (!supabase) redirectWithCode(`/tenders/${tenderId || ""}`, "error", "supabase-missing");
  if (!tenderId) redirectWithCode("/", "error", "folder-not-found");

  const documentName = readText(formData.get("documentName"));
  if (!documentName) redirectWithCode(`/tenders/${tenderId}`, "error", "invalid-document-name");

  const { data: tender, error: fetchError } = await supabase
    .from("tender_folders")
    .select("id, details")
    .eq("id", tenderId)
    .maybeSingle();

  if (fetchError || !tender) redirectWithCode(`/tenders/${tenderId}`, "error", "folder-not-found");

  const existing = readRequiredDocuments(tender.details);
  existing.push({ name: documentName, checked: false });

  const { error } = await supabase
    .from("tender_folders")
    .update({ details: withRequiredDocuments(tender.details, existing) })
    .eq("id", tenderId);

  if (error) redirectWithCode(`/tenders/${tenderId}`, "error", "update-failed");

  revalidatePath(`/tenders/${tenderId}`);
  redirect(`/tenders/${tenderId}?success=required-document-added`);
}

export async function toggleRequiredDocumentAction(formData: FormData) {
  const supabase = createSupabaseAdminClient();
  const tenderId = readText(formData.get("tenderId"));
  const indexStr = readText(formData.get("documentIndex"));
  const checked = readText(formData.get("checked")) === "true";

  if (!supabase) redirectWithCode(`/tenders/${tenderId || ""}`, "error", "supabase-missing");
  if (!tenderId) redirectWithCode("/", "error", "folder-not-found");

  const index = parseInt(indexStr, 10);
  if (isNaN(index)) redirectWithCode(`/tenders/${tenderId}`, "error", "update-failed");

  const { data: tender, error: fetchError } = await supabase
    .from("tender_folders")
    .select("id, details")
    .eq("id", tenderId)
    .maybeSingle();

  if (fetchError || !tender) redirectWithCode(`/tenders/${tenderId}`, "error", "folder-not-found");

  const docs = readRequiredDocuments(tender.details);
  if (index >= 0 && index < docs.length) {
    docs[index] = { ...docs[index], checked };
  }

  const { error } = await supabase
    .from("tender_folders")
    .update({ details: withRequiredDocuments(tender.details, docs) })
    .eq("id", tenderId);

  if (error) redirectWithCode(`/tenders/${tenderId}`, "error", "update-failed");

  revalidatePath(`/tenders/${tenderId}`);
  redirect(`/tenders/${tenderId}`);
}

// ── Teminat Mektupları ─────────────────────────────────────────────────────

function isPdfFile(file: File): boolean {
  if (file.type.toLowerCase() === "application/pdf") return true;
  return getFileExtension(file.name) === ".pdf";
}

function buildGuaranteeLetterStoragePath(params: {
  bankName: string;
  fileName: string;
}): string {
  const extension = getFileExtension(params.fileName) || ".pdf";
  return `guarantee-letters/${Date.now()}-${crypto.randomUUID()}-${slugify(params.bankName)}${extension}`;
}

export async function createGuaranteeLetterAction(formData: FormData) {
  const supabase = createSupabaseAdminClient();

  if (!supabase) {
    redirectWithCode("/teminat-mektuplari", "error", "supabase-missing");
  }

  const bankName = readText(formData.get("bankName"));
  const amount = readText(formData.get("amount"));
  const authority = readText(formData.get("authority"));
  const jobDescription = readText(formData.get("jobDescription"));
  const letterTypeRaw = readText(formData.get("letterType"));
  const letterType = letterTypeRaw === "kesin" ? "kesin" : "gecici";
  const file = formData.get("file");

  if (!bankName || !amount || !authority || !jobDescription) {
    redirectWithCode(
      "/teminat-mektuplari",
      "error",
      "invalid-guarantee-letter-data",
    );
  }

  if (!(file instanceof File) || file.size === 0) {
    redirectWithCode("/teminat-mektuplari", "error", "invalid-guarantee-letter-pdf");
  }

  if (!isPdfFile(file)) {
    redirectWithCode("/teminat-mektuplari", "error", "invalid-guarantee-letter-pdf");
  }

  if (file.size > MAX_UPLOAD_FILE_SIZE) {
    redirectWithCode("/teminat-mektuplari", "error", "file-too-large");
  }

  await ensureStorageBucketLimit(supabase);

  const storagePath = buildGuaranteeLetterStoragePath({
    bankName,
    fileName: file.name,
  });

  const { error: uploadError } = await supabase.storage
    .from(SUPABASE_BUCKET)
    .upload(storagePath, Buffer.from(await file.arrayBuffer()), {
      contentType: "application/pdf",
      upsert: false,
    });

  if (uploadError) {
    redirectWithCode("/teminat-mektuplari", "error", "guarantee-letter-upload-failed");
  }

  const { error: insertError } = await supabase.from("guarantee_letters").insert({
    amount,
    authority,
    bank_name: bankName,
    file_size: file.size,
    job_description: jobDescription,
    letter_type: letterType,
    original_filename: file.name,
    storage_path: storagePath,
  });

  if (insertError) {
    await supabase.storage.from(SUPABASE_BUCKET).remove([storagePath]);
    redirectWithCode("/teminat-mektuplari", "error", "guarantee-letter-upload-failed");
  }

  revalidatePath("/teminat-mektuplari");
  redirect("/teminat-mektuplari?success=guarantee-letter-created");
}

export async function deleteGuaranteeLetterAction(formData: FormData) {
  const supabase = createSupabaseAdminClient();
  const letterId = readText(formData.get("letterId"));

  if (!supabase) {
    redirectWithCode("/teminat-mektuplari", "error", "supabase-missing");
  }

  if (!letterId) {
    redirectWithCode("/teminat-mektuplari", "error", "guarantee-letter-not-found");
  }

  const { data: letter } = await supabase
    .from("guarantee_letters")
    .select("storage_path")
    .eq("id", letterId)
    .maybeSingle();

  if (!letter) {
    redirectWithCode("/teminat-mektuplari", "error", "guarantee-letter-not-found");
  }

  await supabase.storage.from(SUPABASE_BUCKET).remove([letter.storage_path]);

  const { error } = await supabase
    .from("guarantee_letters")
    .delete()
    .eq("id", letterId);

  if (error) {
    redirectWithCode("/teminat-mektuplari", "error", "delete-failed");
  }

  revalidatePath("/teminat-mektuplari");
  redirect("/teminat-mektuplari?success=guarantee-letter-deleted");
}

export async function toggleGuaranteeLetterReturnedAction(formData: FormData) {
  const supabase = createSupabaseAdminClient();
  const letterId = readText(formData.get("letterId"));
  const returned = readText(formData.get("returned")) === "true";

  if (!supabase) {
    redirectWithCode("/teminat-mektuplari", "error", "supabase-missing");
  }

  if (!letterId) {
    redirectWithCode("/teminat-mektuplari", "error", "guarantee-letter-not-found");
  }

  const { data: letter } = await supabase
    .from("guarantee_letters")
    .select("id")
    .eq("id", letterId)
    .maybeSingle();

  if (!letter) {
    redirectWithCode("/teminat-mektuplari", "error", "guarantee-letter-not-found");
  }

  const returns = await fetchGuaranteeLetterReturns();
  if (returned) {
    returns[letterId] = new Date().toISOString();
  } else {
    delete returns[letterId];
  }

  const saved = await saveGuaranteeLetterReturns(returns);
  if (!saved) {
    redirectWithCode("/teminat-mektuplari", "error", "update-failed");
  }

  revalidatePath("/teminat-mektuplari");
  revalidatePath("/");
  redirect(
    `/teminat-mektuplari?success=${returned ? "guarantee-letter-returned" : "guarantee-letter-unreturned"}`,
  );
}

export async function getGuaranteeLetterDownloadUrl(
  letterId: string,
): Promise<string | null> {
  const supabase = createSupabaseAdminClient();
  if (!supabase || !letterId) return null;

  const { data: letter } = await supabase
    .from("guarantee_letters")
    .select("storage_path")
    .eq("id", letterId)
    .maybeSingle();

  if (!letter) return null;

  const { data } = await supabase.storage
    .from(SUPABASE_BUCKET)
    .createSignedUrl(letter.storage_path, 60 * 60);

  return data?.signedUrl ?? null;
}

// ── Görevler / Takvim ───────────────────────────────────────────────────────

export async function createTaskAction(formData: FormData) {
  const supabase = createSupabaseAdminClient();

  if (!supabase) {
    redirectWithCode("/gorevler", "error", "supabase-missing");
  }

  const title = readText(formData.get("title"));
  const dueDate = readDate(formData.get("dueDate"));
  const description = readOptionalText(formData.get("description"));

  if (!title || !dueDate) {
    redirectWithCode("/gorevler", "error", "invalid-task-data");
  }

  const taskId = crypto.randomUUID();
  const { error } = await supabase.from("tasks").insert({
    description,
    due_date: dueDate,
    id: taskId,
    title,
  });

  if (error) {
    redirectWithCode("/gorevler", "error", "invalid-task-data");
  }

  await upsertCalendarEvent({
    date: dueDate,
    description: description ?? undefined,
    id: taskCalendarEventId(taskId),
    title,
  });

  revalidatePath("/gorevler");
  redirect("/gorevler?success=task-created");
}

export async function toggleTaskCompletedAction(formData: FormData) {
  const supabase = createSupabaseAdminClient();
  const taskId = readText(formData.get("taskId"));
  const completed = readText(formData.get("completed")) === "true";
  const redirectToRaw = readText(formData.get("redirectTo"));
  const redirectTo =
    redirectToRaw.startsWith("/") && !redirectToRaw.startsWith("//")
      ? redirectToRaw
      : "/gorevler";

  if (!supabase) {
    redirectWithCode(redirectTo, "error", "supabase-missing");
  }

  if (!taskId) {
    redirectWithCode(redirectTo, "error", "task-not-found");
  }

  const { error } = await supabase
    .from("tasks")
    .update({
      completed,
      completed_at: completed ? new Date().toISOString() : null,
    })
    .eq("id", taskId);

  if (error) {
    redirectWithCode(redirectTo, "error", "update-failed");
  }

  revalidatePath("/gorevler");
  revalidatePath("/");
  redirect(`${redirectTo}?success=task-updated`);
}

export async function deleteTaskAction(formData: FormData) {
  const supabase = createSupabaseAdminClient();
  const taskId = readText(formData.get("taskId"));

  if (!supabase) {
    redirectWithCode("/gorevler", "error", "supabase-missing");
  }

  if (!taskId) {
    redirectWithCode("/gorevler", "error", "task-not-found");
  }

  const { error } = await supabase.from("tasks").delete().eq("id", taskId);

  if (error) {
    redirectWithCode("/gorevler", "error", "delete-failed");
  }

  await deleteCalendarEvent(taskCalendarEventId(taskId));

  revalidatePath("/gorevler");
  redirect("/gorevler?success=task-deleted");
}

export async function removeRequiredDocumentAction(formData: FormData) {
  const supabase = createSupabaseAdminClient();
  const tenderId = readText(formData.get("tenderId"));
  const indexStr = readText(formData.get("documentIndex"));

  if (!supabase) redirectWithCode(`/tenders/${tenderId || ""}`, "error", "supabase-missing");
  if (!tenderId) redirectWithCode("/", "error", "folder-not-found");

  const index = parseInt(indexStr, 10);
  if (isNaN(index)) redirectWithCode(`/tenders/${tenderId}`, "error", "update-failed");

  const { data: tender, error: fetchError } = await supabase
    .from("tender_folders")
    .select("id, details")
    .eq("id", tenderId)
    .maybeSingle();

  if (fetchError || !tender) redirectWithCode(`/tenders/${tenderId}`, "error", "folder-not-found");

  const docs = readRequiredDocuments(tender.details);
  if (index >= 0 && index < docs.length) {
    docs.splice(index, 1);
  }

  const { error } = await supabase
    .from("tender_folders")
    .update({ details: withRequiredDocuments(tender.details, docs) })
    .eq("id", tenderId);

  if (error) redirectWithCode(`/tenders/${tenderId}`, "error", "update-failed");

  revalidatePath(`/tenders/${tenderId}`);
  redirect(`/tenders/${tenderId}?success=required-document-removed`);
}
