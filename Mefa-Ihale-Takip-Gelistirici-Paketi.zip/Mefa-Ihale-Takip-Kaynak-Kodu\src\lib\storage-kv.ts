import "server-only";

import { getSupabaseConfig, SUPABASE_BUCKET } from "@/lib/supabase/server";

/**
 * Şema değişikliği gerektirmeyen küçük değişken durumlar (iade takibi,
 * hatırlatıcı gönderim kaydı vb.) için Supabase Storage'da JSON dosyası
 * olarak saklama/okuma. Supabase CDN nesneleri varsayılan olarak
 * `max-age=3600` ile önbelleğe alır; bu yüzden okuma her zaman
 * `cache: "no-store"` + zaman damgalı sorgu parametresiyle yapılır,
 * yazma da önbelleğe alınmaz (v1.3.5'te bulunan "Geri Al" hatasının
 * aynısına düşmemek için).
 */
export async function readStorageJson<T>(path: string, fallback: T): Promise<T> {
  const config = getSupabaseConfig();
  if (!config) return fallback;

  const url = `${config.url}/storage/v1/object/${SUPABASE_BUCKET}/${path}?t=${Date.now()}`;

  let res: Response;
  try {
    res = await fetch(url, {
      headers: {
        apikey: config.serviceRoleKey,
        Authorization: `Bearer ${config.serviceRoleKey}`,
      },
      cache: "no-store",
    });
  } catch {
    return fallback;
  }

  if (!res.ok) return fallback;

  try {
    return JSON.parse(await res.text()) as T;
  } catch {
    return fallback;
  }
}

export async function writeStorageJson(path: string, value: unknown): Promise<boolean> {
  const config = getSupabaseConfig();
  if (!config) return false;

  const url = `${config.url}/storage/v1/object/${SUPABASE_BUCKET}/${path}`;

  try {
    const res = await fetch(url, {
      method: "POST",
      headers: {
        apikey: config.serviceRoleKey,
        Authorization: `Bearer ${config.serviceRoleKey}`,
        "Content-Type": "application/json",
        "Cache-Control": "no-cache, max-age=0",
        "x-upsert": "true",
      },
      body: JSON.stringify(value, null, 2),
      cache: "no-store",
    });
    return res.ok;
  } catch {
    return false;
  }
}
