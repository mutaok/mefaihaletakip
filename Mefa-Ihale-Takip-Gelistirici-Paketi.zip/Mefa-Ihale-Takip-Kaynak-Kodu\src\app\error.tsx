"use client";

import { useEffect } from "react";
import Link from "next/link";
import { AlertTriangle, RefreshCw } from "lucide-react";

export default function GlobalError({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    console.error("[App Error]", error);
  }, [error]);

  return (
    <div className="flex flex-1 flex-col items-center justify-center gap-5 p-8 text-center">
      <span className="grid size-16 place-items-center rounded-2xl bg-rose-100 text-rose-600">
        <AlertTriangle className="size-8" />
      </span>

      <div className="space-y-1.5">
        <h2 className="text-xl font-bold text-foreground">Bir hata oluştu</h2>
        {error.message && error.message !== "An error occurred in the Server Components render." && (
          <p className="mx-auto max-w-md text-sm text-muted">{error.message}</p>
        )}
        {error.digest && (
          <p className="text-xs text-muted/70">Kod: {error.digest}</p>
        )}
      </div>

      <div className="flex items-center gap-3">
        <button
          onClick={reset}
          className="inline-flex items-center gap-2 rounded-xl bg-accent px-5 py-2.5 text-sm font-semibold text-white transition hover:bg-accent/90"
        >
          <RefreshCw className="size-4" /> Tekrar Dene
        </button>
        <Link
          href="/"
          className="inline-flex items-center gap-2 rounded-xl border border-line px-5 py-2.5 text-sm font-semibold text-foreground transition hover:bg-line/30"
        >
          Ana Sayfaya Dön
        </Link>
      </div>
    </div>
  );
}
