const fs = require("fs");
const path = require("path");
const { execSync } = require("child_process");

function removeDir(dir) {
  if (!fs.existsSync(dir)) return;
  try {
    execSync(`powershell -Command "Remove-Item -Recurse -Force '${dir.replace(/'/g, "''")}'"`, { stdio: "pipe" });
  } catch {
    fs.rmSync(dir, { recursive: true, force: true });
  }
}

const projectDir = path.join(__dirname, "..");
const pkg = JSON.parse(fs.readFileSync(path.join(projectDir, "package.json"), "utf-8"));
const unpackedDir = path.join(projectDir, "dist-electron", "win-unpacked");
const resourcesDir = path.join(unpackedDir, "resources");
const appDir = path.join(resourcesDir, "app");
const serverDir = path.join(resourcesDir, "server");

function copyRecursive(src, dest) {
  if (!fs.existsSync(src)) {
    console.log("  SKIP (not found):", src);
    return;
  }
  const stat = fs.statSync(src);
  if (stat.isDirectory()) {
    fs.mkdirSync(dest, { recursive: true });
    for (const entry of fs.readdirSync(src)) {
      copyRecursive(path.join(src, entry), path.join(dest, entry));
    }
  } else {
    fs.mkdirSync(path.dirname(dest), { recursive: true });
    fs.copyFileSync(src, dest);
  }
}

console.log("=== MEFA Ihale Takip - Electron Build ===\n");

// Check prerequisites
if (!fs.existsSync(unpackedDir)) {
  console.error("ERROR: Electron binary not found at", unpackedDir);
  console.error("Run: npx electron-builder --dir first to download Electron");
  process.exit(1);
}

const standaloneDir = path.join(projectDir, ".next", "standalone");
if (!fs.existsSync(standaloneDir)) {
  console.error("ERROR: Next.js standalone output not found.");
  console.error("Run: npm run build first");
  process.exit(1);
}

// Step 1: Create app directory with electron main process
console.log("1. Creating app directory...");
removeDir(appDir);
fs.mkdirSync(path.join(appDir, "electron"), { recursive: true });

// Copy electron main.js
fs.copyFileSync(
  path.join(projectDir, "electron", "main.js"),
  path.join(appDir, "electron", "main.js"),
);

// Create minimal package.json for the app
const appPackage = {
  name: "mefa-ihale-takip",
  version: pkg.version,
  main: "electron/main.js",
  description: "Mefa Group Ihale Takip Uygulamasi",
  author: "Mefa Group",
};
fs.writeFileSync(
  path.join(appDir, "package.json"),
  JSON.stringify(appPackage, null, 2),
);
console.log("   OK");

// Step 2: Copy Next.js standalone server
console.log("2. Copying Next.js standalone server...");
removeDir(serverDir);
copyRecursive(standaloneDir, serverDir);
console.log("   OK");

// Step 3: Copy static files
console.log("3. Copying static files...");
const staticSrc = path.join(projectDir, ".next", "static");
const staticDest = path.join(serverDir, ".next", "static");
copyRecursive(staticSrc, staticDest);
console.log("   OK");

// Step 4: Copy public files
console.log("4. Copying public files...");
const publicSrc = path.join(projectDir, "public");
const publicDest = path.join(serverDir, "public");
copyRecursive(publicSrc, publicDest);
console.log("   OK");

// Step 5: Copy .env.local
console.log("5. Copying .env.local...");
const envSrc = path.join(projectDir, ".env.local");
const envDest = path.join(serverDir, ".env.local");
if (fs.existsSync(envSrc)) {
  fs.copyFileSync(envSrc, envDest);
  console.log("   OK");
} else {
  console.log("   WARN: .env.local not found, skipping");
}

// Step 6: Copy icon
console.log("6. Copying icon...");
const iconSrc = path.join(projectDir, "public", "mefa-logo.png");
const iconDest = path.join(resourcesDir, "icon.png");
if (fs.existsSync(iconSrc)) {
  fs.copyFileSync(iconSrc, iconDest);
  console.log("   OK");
}

// Step 7: Rename electron.exe
console.log("7. Renaming executable...");
const exeSrc = path.join(unpackedDir, "electron.exe");
const exeDest = path.join(unpackedDir, "MEFA Ihale Takip.exe");
if (fs.existsSync(exeSrc)) {
  if (fs.existsSync(exeDest)) {
    fs.unlinkSync(exeDest);
  }
  fs.renameSync(exeSrc, exeDest);
  console.log("   OK -> MEFA Ihale Takip.exe");
} else if (fs.existsSync(exeDest)) {
  console.log("   Already renamed");
} else {
  console.log("   WARN: electron.exe not found");
}

console.log("\n=== Build complete! ===");
console.log("Output:", unpackedDir);
console.log('Run "MEFA Ihale Takip.exe" to start the application.');
