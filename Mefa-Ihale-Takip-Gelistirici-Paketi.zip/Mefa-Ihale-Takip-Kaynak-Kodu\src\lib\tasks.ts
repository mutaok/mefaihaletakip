import "server-only";

import type { Database } from "@/lib/supabase/database.types";
import {
  createSupabaseAdminClient,
  isSupabaseConfigured,
} from "@/lib/supabase/server";

type TaskRow = Database["public"]["Tables"]["tasks"]["Row"];

export type Task = {
  completed: boolean;
  completedAt: string | null;
  createdAt: string;
  description: string | null;
  dueDate: string;
  id: string;
  title: string;
};

export type TasksResult = {
  activeTasks: Task[];
  completedTasks: Task[];
  dataError: string | null;
  isConfigured: boolean;
};

function mapTask(row: TaskRow): Task {
  return {
    completed: row.completed,
    completedAt: row.completed_at,
    createdAt: row.created_at,
    description: row.description,
    dueDate: row.due_date,
    id: row.id,
    title: row.title,
  };
}

export async function getTasks(): Promise<TasksResult> {
  if (!isSupabaseConfigured()) {
    return {
      activeTasks: [],
      completedTasks: [],
      dataError: null,
      isConfigured: false,
    };
  }

  const supabase = createSupabaseAdminClient();

  if (!supabase) {
    return {
      activeTasks: [],
      completedTasks: [],
      dataError: null,
      isConfigured: false,
    };
  }

  const { data, error } = await supabase
    .from("tasks")
    .select("id, title, description, due_date, completed, completed_at, created_at")
    .order("due_date", { ascending: true });

  if (error) {
    return {
      activeTasks: [],
      completedTasks: [],
      dataError: error.message,
      isConfigured: true,
    };
  }

  const tasks = (data ?? []).map(mapTask);

  return {
    activeTasks: tasks.filter((task) => !task.completed),
    completedTasks: tasks
      .filter((task) => task.completed)
      .sort((a, b) => Date.parse(b.completedAt ?? b.createdAt) - Date.parse(a.completedAt ?? a.createdAt)),
    dataError: null,
    isConfigured: true,
  };
}
