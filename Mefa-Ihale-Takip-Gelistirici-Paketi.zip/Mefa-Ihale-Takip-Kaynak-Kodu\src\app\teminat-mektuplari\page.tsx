import Link from "next/link";
import { ArrowLeft, CheckCircle2, Landmark, Printer, RotateCcw, Trash2, FileText } from "lucide-react";

import {
  deleteGuaranteeLetterAction,
  getGuaranteeLetterDownloadUrl,
  toggleGuaranteeLetterReturnedAction,
} from "@/app/actions";
import { GuaranteeLetterCreateDialog } from "@/components/guarantee-letter-create-dialog";
import { StatusBanner } from "@/components/status-banner";
import { SubmitButton } from "@/components/submit-button";
import { resolveFlashMessage } from "@/lib/flash";
import { formatDateTime, formatFileSize } from "@/lib/format";
import { getGuaranteeLetters } from "@/lib/guarantee-letters";

export const dynamic = "force-dynamic";

type PageProps = {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
};

export default async function GuaranteeLettersPage({ searchParams }: PageProps) {
  const params = await searchParams;
  const flash = resolveFlashMessage(params);
  const result = await getGuaranteeLetters();

  const downloadUrls = new Map<string, string | null>();
  await Promise.all(
    result.letters.map(async (letter) => {
      const url = await getGuaranteeLetterDownloadUrl(letter.id);
      downloadUrls.set(letter.id, url);
    }),
  );

  return (
    <div className="flex flex-1 flex-col overflow-hidden">
      <header className="flex flex-shrink-0 flex-wrap items-center gap-4 border-b border-line bg-white/50 px-6 py-3 backdrop-blur-sm">
        <Link
          href="/"
          className="inline-flex flex-shrink-0 items-center gap-2 rounded-xl border border-line bg-white px-3.5 py-2 text-sm font-medium text-foreground transition hover:border-accent/30"
        >
          <ArrowLeft className="size-4" /> Geri
        </Link>
        <div className="flex items-center gap-3">
          <Landmark className="size-5 text-accent" />
          <h1 className="text-base font-bold text-foreground">Teminat Mektupları</h1>
          <span className="rounded-full bg-accent/10 px-2.5 py-0.5 text-xs font-semibold text-accent">
            {result.letters.length}
          </span>
        </div>
        <div className="ml-auto">
          <GuaranteeLetterCreateDialog disabled={!result.isConfigured} />
        </div>
      </header>

      <div className="flex-1 overflow-y-auto">
        <div className="mx-auto max-w-3xl space-y-4 p-6">
          {flash ? <StatusBanner flash={flash} /> : null}

          {result.isConfigured && !result.dataError && (
            <div className="flex flex-wrap gap-3">
              <span className="inline-flex items-center gap-2 rounded-xl border border-line bg-white/80 px-4 py-2 text-sm">
                <span className="font-semibold text-foreground">{result.geciciCount}</span>
                <span className="text-muted">Geçici Teminat Mektubu</span>
              </span>
              <span className="inline-flex items-center gap-2 rounded-xl border border-line bg-white/80 px-4 py-2 text-sm">
                <span className="font-semibold text-foreground">{result.kesinCount}</span>
                <span className="text-muted">Kesin Teminat Mektubu</span>
              </span>
              {result.returnedCount > 0 && (
                <span className="inline-flex items-center gap-2 rounded-xl border border-line bg-white/60 px-4 py-2 text-sm">
                  <span className="font-semibold text-muted">{result.returnedCount}</span>
                  <span className="text-muted">İade Edilen</span>
                </span>
              )}
            </div>
          )}

          {!result.isConfigured && (
            <div className="rounded-2xl border border-sky-200 bg-sky-50/90 px-4 py-3 text-xs leading-6 text-sky-900">
              Supabase bağlantısı henüz aktif değil.
            </div>
          )}

          {result.dataError && (
            <div className="rounded-2xl border border-rose-200 bg-rose-50/90 px-4 py-3 text-xs leading-6 text-rose-900">
              {result.dataError}
            </div>
          )}

          {result.letters.length > 0 ? (
            <div className="space-y-2">
              {[...result.letters]
                .sort((a, b) => Number(Boolean(a.returnedAt)) - Number(Boolean(b.returnedAt)))
                .map((letter) => {
                const url = downloadUrls.get(letter.id);
                const returned = Boolean(letter.returnedAt);
                return (
                  <div
                    key={letter.id}
                    className={`flex flex-wrap items-start justify-between gap-4 rounded-2xl border border-line px-5 py-4 transition ${
                      returned ? "bg-white/40 opacity-55 grayscale-[0.4]" : "bg-white/80"
                    }`}
                  >
                    <div className="min-w-0 flex-1 space-y-1">
                      <p className="text-sm font-semibold text-foreground">
                        {letter.bankName}
                        <span
                          className={`ml-2 rounded-full px-2 py-0.5 text-xs font-semibold ${
                            letter.letterType === "kesin"
                              ? "bg-accent-strong/15 text-accent-strong"
                              : "bg-accent/10 text-accent"
                          }`}
                        >
                          {letter.letterType === "kesin" ? "Kesin Teminat" : "Geçici Teminat"}
                        </span>
                        <span className="ml-2 rounded-full bg-line/50 px-2 py-0.5 text-xs font-semibold text-foreground">
                          {letter.amount}
                        </span>
                        {returned ? (
                          <span className="ml-2 inline-flex items-center gap-1 rounded-full bg-emerald-100 px-2 py-0.5 text-xs font-semibold text-emerald-700">
                            <CheckCircle2 className="size-3" /> İade Edildi ·{" "}
                            {formatDateTime(letter.returnedAt)}
                          </span>
                        ) : (
                          <span
                            className={`ml-2 rounded-full px-2 py-0.5 text-xs font-semibold ${
                              letter.daysOutstanding >= 90
                                ? "bg-rose-100 text-rose-700"
                                : "bg-amber-100 text-amber-700"
                            }`}
                          >
                            {letter.daysOutstanding} gündür iade edilmedi
                          </span>
                        )}
                      </p>
                      <p className="text-xs text-muted">
                        <span className="font-medium text-foreground">İdare:</span>{" "}
                        {letter.authority}
                      </p>
                      <p className="text-xs text-muted">
                        <span className="font-medium text-foreground">İş:</span>{" "}
                        {letter.jobDescription}
                      </p>
                      <p className="text-xs text-muted">
                        {formatDateTime(letter.createdAt)} ·{" "}
                        {formatFileSize(letter.fileSize)}
                      </p>
                    </div>
                    <div className="flex flex-shrink-0 items-center gap-2">
                      {url ? (
                        <a
                          href={url}
                          target="_blank"
                          rel="noreferrer"
                          className="inline-flex items-center gap-2 rounded-xl border border-accent/30 bg-accent/10 px-4 py-2 text-sm font-semibold text-accent transition hover:bg-accent/20"
                        >
                          <FileText className="size-4" /> PDF Görüntüle
                        </a>
                      ) : null}
                      <Link
                        href={`/teminat-mektuplari/${letter.id}/print`}
                        title="Yazdır"
                        className="inline-flex items-center gap-2 rounded-xl border border-line bg-white px-3 py-2 text-sm font-semibold text-foreground transition hover:border-accent/30"
                      >
                        <Printer className="size-4" />
                      </Link>
                      <form action={toggleGuaranteeLetterReturnedAction}>
                        <input name="letterId" type="hidden" value={letter.id} />
                        <input name="returned" type="hidden" value={returned ? "false" : "true"} />
                        {returned ? (
                          <SubmitButton
                            className="inline-flex items-center gap-2 rounded-xl border border-line bg-white px-4 py-2 text-sm font-semibold text-muted transition hover:text-foreground disabled:opacity-70"
                            pendingLabel="Geri alınıyor..."
                          >
                            <RotateCcw className="size-4" /> Geri Al
                          </SubmitButton>
                        ) : (
                          <SubmitButton
                            className="inline-flex items-center gap-2 rounded-xl border border-emerald-300 bg-emerald-50 px-4 py-2 text-sm font-semibold text-emerald-700 transition hover:bg-emerald-100 disabled:opacity-70"
                            pendingLabel="İşaretleniyor..."
                          >
                            <CheckCircle2 className="size-4" /> İade Edildi
                          </SubmitButton>
                        )}
                      </form>
                      <form action={deleteGuaranteeLetterAction}>
                        <input name="letterId" type="hidden" value={letter.id} />
                        <SubmitButton
                          className="inline-flex items-center gap-2 rounded-xl border border-rose-300 bg-rose-50 px-4 py-2 text-sm font-semibold text-rose-700 transition hover:bg-rose-100 disabled:opacity-70"
                          pendingLabel="Siliniyor..."
                        >
                          <Trash2 className="size-4" /> Sil
                        </SubmitButton>
                      </form>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="flex flex-col items-center gap-3 py-16 text-center">
              <Landmark className="size-10 text-muted/30" />
              <p className="text-sm text-muted">Henüz teminat mektubu eklenmedi</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
