"use client";

import { provinces } from "@/lib/provinces";

const fieldClass =
  "w-full rounded-[22px] border border-line bg-white/90 px-4 py-3 text-sm text-foreground outline-none transition focus:border-accent focus:ring-4 focus:ring-accent/12";

export function ProvinceSelect({ disabled }: { disabled?: boolean }) {
  return (
    <div className="grid gap-4 sm:grid-cols-2">
      <label className="block">
        <span className="mb-2 block text-xs font-semibold uppercase tracking-[0.22em] text-muted">
          Il
        </span>
        <select className={fieldClass} name="il" required disabled={disabled}>
          <option value="">Il secin</option>
          {provinces.map((p) => (
            <option key={p.name} value={p.name}>
              {p.name}
            </option>
          ))}
        </select>
      </label>
      <label className="block">
        <span className="mb-2 block text-xs font-semibold uppercase tracking-[0.22em] text-muted">
          Ilce
        </span>
        <input
          className={fieldClass}
          name="ilce"
          placeholder="Ilce adi girin"
          disabled={disabled}
        />
      </label>
    </div>
  );
}
