import "server-only";

import { slugify, todayDateKey } from "@/lib/format";
import type { Database } from "@/lib/supabase/database.types";
import {
  deriveTenderOutcome,
  parseTenderDetails,
  readDeletedAt,
  readDocumentFolders,
  readTenderResult,
  type TenderDetails,
  type TenderOutcome,
} from "@/lib/tender-details";
import {
  createSupabaseAdminClient,
  isSupabaseConfigured,
} from "@/lib/supabase/server";

type FolderRow = Database["public"]["Tables"]["tender_folders"]["Row"];
type DocumentRow = Database["public"]["Tables"]["tender_documents"]["Row"];
type DocumentQueryRow = Pick<
  DocumentRow,
  | "display_name"
  | "file_size"
  | "id"
  | "mime_type"
  | "original_filename"
  | "storage_path"
  | "tender_id"
  | "uploaded_at"
>;

type FolderRowWithDocuments = FolderRow & {
  tender_documents?: { id: string }[] | null;
};

export type TenderSummary = {
  authority: string | null;
  createdAt: string;
  documentCount: number;
  id: string;
  outcome: TenderOutcome | null;
  referenceCode: string | null;
  resultBidCount: number | null;
  tenderDate: string | null;
  title: string;
};

export type TenderDocument = {
  displayName: string;
  fileSize: number | null;
  folderId: string | null;
  folderName: string | null;
  id: string;
  mimeType: string;
  originalFilename: string;
  storagePath: string;
  uploadedAt: string;
};

export type TenderDocumentFolder = {
  createdAt: string;
  documentCount: number;
  id: string;
  name: string;
};

export type TenderDetail = TenderSummary & {
  details: TenderDetails;
  documentFolders: TenderDocumentFolder[];
  documents: TenderDocument[];
};

export type TenderDashboardData = {
  dataError: string | null;
  isConfigured: boolean;
  tenders: TenderSummary[];
  totalDocuments: number;
};

export type TenderDetailResult = {
  dataError: string | null;
  isConfigured: boolean;
  tender: TenderDetail | null;
};

function mapTenderSummary(row: FolderRowWithDocuments): TenderSummary {
  return {
    authority: row.authority,
    createdAt: row.created_at,
    documentCount: row.tender_documents?.length ?? 0,
    id: row.id,
    outcome: deriveTenderOutcome(row.details as Record<string, unknown>),
    referenceCode: row.reference_code,
    resultBidCount: readTenderResult(row.details as Record<string, unknown>)?.bids.length ?? null,
    tenderDate: row.tender_date,
    title: row.title,
  };
}

function mapTenderDocument(
  row: DocumentQueryRow,
  folderNameBySlug: Map<string, string>,
): TenderDocument {
  const folderSlug = getFolderSlugFromStoragePath(row.storage_path, row.tender_id);
  const folderName = folderSlug ? folderNameBySlug.get(folderSlug) ?? folderSlug : null;

  return {
    displayName: row.display_name,
    fileSize: row.file_size,
    folderId: folderName,
    folderName,
    id: row.id,
    mimeType: row.mime_type,
    originalFilename: row.original_filename,
    storagePath: row.storage_path,
    uploadedAt: row.uploaded_at,
  };
}

function mapTenderDocumentFolder(
  folderName: string,
  documentCount: number,
): TenderDocumentFolder {
  return {
    createdAt: "",
    documentCount,
    id: folderName,
    name: folderName,
  };
}

function getFolderSlugFromStoragePath(
  storagePath: string,
  tenderId: string,
): string | null {
  const parts = storagePath.split("/").filter(Boolean);

  if (parts.length < 3 || parts[0] !== tenderId) {
    return null;
  }

  return parts[1] ?? null;
}

function compareTendersByDate(a: TenderSummary, b: TenderSummary): number {
  const aTime = a.tenderDate ? Date.parse(`${a.tenderDate}T00:00:00`) : 0;
  const bTime = b.tenderDate ? Date.parse(`${b.tenderDate}T00:00:00`) : 0;

  if (aTime !== bTime) {
    return bTime - aTime;
  }

  return Date.parse(b.createdAt) - Date.parse(a.createdAt);
}

export async function getTenderDashboardData(): Promise<TenderDashboardData> {
  if (!isSupabaseConfigured()) {
    return {
      dataError: null,
      isConfigured: false,
      tenders: [],
      totalDocuments: 0,
    };
  }

  const supabase = createSupabaseAdminClient();

  if (!supabase) {
    return {
      dataError: null,
      isConfigured: false,
      tenders: [],
      totalDocuments: 0,
    };
  }

  const { data, error } = await supabase
    .from("tender_folders")
    .select(
      "id, title, reference_code, authority, tender_date, created_at, details, tender_documents(id)",
    )
    .order("created_at", { ascending: false });

  if (error) {
    return {
      dataError: error.message,
      isConfigured: true,
      tenders: [],
      totalDocuments: 0,
    };
  }

  const tenders = ((data ?? []) as (FolderRowWithDocuments & { details: unknown })[])
    .filter((row) => !readDeletedAt(row.details as Record<string, unknown>))
    .map(mapTenderSummary)
    .sort(compareTendersByDate);

  return {
    dataError: null,
    isConfigured: true,
    tenders,
    totalDocuments: tenders.reduce(
      (sum, tender) => sum + tender.documentCount,
      0,
    ),
  };
}

export async function getTenderDetail(id: string): Promise<TenderDetailResult> {
  if (!isSupabaseConfigured()) {
    return {
      dataError: null,
      isConfigured: false,
      tender: null,
    };
  }

  const supabase = createSupabaseAdminClient();

  if (!supabase) {
    return {
      dataError: null,
      isConfigured: false,
      tender: null,
    };
  }

  const [folderResult, documentsResult] = await Promise.all([
    supabase
      .from("tender_folders")
      .select(
        "id, title, reference_code, authority, tender_date, details, created_at",
      )
      .eq("id", id)
      .maybeSingle(),
    supabase
      .from("tender_documents")
      .select(
        "id, tender_id, display_name, original_filename, storage_path, file_size, mime_type, uploaded_at",
      )
      .eq("tender_id", id)
      .order("uploaded_at", { ascending: false }),
  ]);

  if (folderResult.error) {
    return {
      dataError: folderResult.error.message,
      isConfigured: true,
      tender: null,
    };
  }

  if (documentsResult.error) {
    return {
      dataError: documentsResult.error.message,
      isConfigured: true,
      tender: null,
    };
  }

  if (!folderResult.data || readDeletedAt(folderResult.data.details as Record<string, unknown>)) {
    return {
      dataError: null,
      isConfigured: true,
      tender: null,
    };
  }

  const configuredDocumentFolders = readDocumentFolders(folderResult.data.details);
  const folderNameBySlug = new Map(
    configuredDocumentFolders.map((folderName) => [slugify(folderName), folderName]),
  );
  const documentCountByFolderId = new Map<string, number>();

  for (const document of documentsResult.data ?? []) {
    const folderSlug = getFolderSlugFromStoragePath(document.storage_path, id);

    if (!folderSlug) {
      continue;
    }

    documentCountByFolderId.set(
      folderSlug,
      (documentCountByFolderId.get(folderSlug) ?? 0) + 1,
    );
  }

  const documents = (documentsResult.data ?? []).map((document) =>
    mapTenderDocument(document, folderNameBySlug),
  );
  const tenderBase = mapTenderSummary({
    ...(folderResult.data as unknown as FolderRow),
    tender_documents: documents.map((document) => ({ id: document.id })),
  });

  return {
    dataError: null,
    isConfigured: true,
    tender: {
      ...tenderBase,
      details: parseTenderDetails(folderResult.data.details),
      documentFolders: configuredDocumentFolders.map((folderName) =>
        mapTenderDocumentFolder(
          folderName,
          documentCountByFolderId.get(slugify(folderName)) ?? 0,
        ),
      ),
      documents,
    },
  };
}

export type PastTendersResult = {
  dataError: string | null;
  isConfigured: boolean;
  tenders: TenderSummary[];
};

export async function getPastTenders(): Promise<PastTendersResult> {
  if (!isSupabaseConfigured()) {
    return { dataError: null, isConfigured: false, tenders: [] };
  }

  const supabase = createSupabaseAdminClient();

  if (!supabase) {
    return { dataError: null, isConfigured: false, tenders: [] };
  }

  const { data, error } = await supabase
    .from("tender_folders")
    .select(
      "id, title, reference_code, authority, tender_date, created_at, details, tender_documents(id)",
    )
    .lt("tender_date", todayDateKey())
    .order("tender_date", { ascending: false });

  if (error) {
    return { dataError: error.message, isConfigured: true, tenders: [] };
  }

  const tenders = ((data ?? []) as (FolderRowWithDocuments & { details: unknown })[])
    .filter((row) => !readDeletedAt(row.details as Record<string, unknown>))
    .map(mapTenderSummary);

  return { dataError: null, isConfigured: true, tenders };
}

export type DeletedTenderSummary = TenderSummary & { deletedAt: string };

export type DeletedTendersResult = {
  dataError: string | null;
  isConfigured: boolean;
  tenders: DeletedTenderSummary[];
};

export async function getDeletedTenders(): Promise<DeletedTendersResult> {
  if (!isSupabaseConfigured()) {
    return { dataError: null, isConfigured: false, tenders: [] };
  }

  const supabase = createSupabaseAdminClient();
  if (!supabase) {
    return { dataError: null, isConfigured: false, tenders: [] };
  }

  const { data, error } = await supabase
    .from("tender_folders")
    .select(
      "id, title, reference_code, authority, tender_date, created_at, details, tender_documents(id)",
    )
    .order("created_at", { ascending: false });

  if (error) {
    return { dataError: error.message, isConfigured: true, tenders: [] };
  }

  const tenders = ((data ?? []) as (FolderRowWithDocuments & { details: unknown })[])
    .filter((row) => {
      const deletedAt = readDeletedAt(row.details as Record<string, unknown>);
      return !!deletedAt;
    })
    .map((row) => ({
      ...mapTenderSummary(row),
      deletedAt: readDeletedAt(row.details as Record<string, unknown>)!,
    }))
    .sort((a, b) => Date.parse(b.deletedAt) - Date.parse(a.deletedAt));

  return { dataError: null, isConfigured: true, tenders };
}
