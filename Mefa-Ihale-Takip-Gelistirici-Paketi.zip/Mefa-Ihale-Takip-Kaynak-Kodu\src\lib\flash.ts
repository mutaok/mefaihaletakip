import { getSingleQueryValue } from "@/lib/format";

export type FlashVariant = "success" | "error" | "info";

export type FlashMessage = {
  variant: FlashVariant;
  title: string;
  description: string;
};

const successMessages: Record<string, FlashMessage> = {
  "folder-created": {
    variant: "success",
    title: "Ihale klasoru hazir",
    description: "Yeni ihale klasoru olusturuldu ve detay ekranina yonlendirildiniz.",
  },
  "upload-complete": {
    variant: "success",
    title: "Dosya yuklendi",
    description: "Dosya Supabase Storage uzerine kaydedildi.",
  },
  "folder-upload-complete": {
    variant: "success",
    title: "Klasor yuklendi",
    description: "Klasordeki dosyalar basariyla yuklendi.",
  },
  "document-renamed": {
    variant: "success",
    title: "Dosya adi guncellendi",
    description: "Gorunen dosya adi basariyla degistirildi.",
  },
  "document-deleted": {
    variant: "success",
    title: "Dokuman silindi",
    description: "Dokuman arsivden ve depolamadan kaldirildi.",
  },
  "folder-deleted": {
    variant: "success",
    title: "Ihale klasoru silindi",
    description: "Klasor ve tum iliskili dokumanlar basariyla kaldirildi.",
  },
  "tender-updated": {
    variant: "success",
    title: "Ihale guncellendi",
    description: "Ihale bilgileri basariyla kaydedildi.",
  },
  "document-folder-created": {
    variant: "success",
    title: "Klasor olusturuldu",
    description: "Belge klasoru basariyla olusturuldu.",
  },
  "tender-trashed": {
    variant: "success",
    title: "Ihale cop kutusuna tasindi",
    description: "Cop kutusundan geri yukleyebilirsiniz.",
  },
  "tender-restored": {
    variant: "success",
    title: "Ihale geri yuklendi",
    description: "Ihale ana listeye geri eklendi.",
  },
  "tender-permanently-deleted": {
    variant: "success",
    title: "Ihale kalici olarak silindi",
    description: "Ihale ve tum dokumanlari kalici olarak silindi.",
  },
  "required-document-added": {
    variant: "success",
    title: "Evrak eklendi",
    description: "Istenilen evrak listesine yeni kayit eklendi.",
  },
  "required-document-removed": {
    variant: "success",
    title: "Evrak kaldirildi",
    description: "Istenilen evrak listesinden kayit silindi.",
  },
  "guarantee-letter-created": {
    variant: "success",
    title: "Teminat mektubu eklendi",
    description: "Teminat mektubu ve PDF dosyasi basariyla kaydedildi.",
  },
  "guarantee-letter-deleted": {
    variant: "success",
    title: "Teminat mektubu silindi",
    description: "Kayit ve PDF dosyasi kaldirildi.",
  },
  "guarantee-letter-returned": {
    variant: "success",
    title: "Teminat mektubu iade edildi",
    description: "Mektup iade edildi olarak isaretlendi.",
  },
  "guarantee-letter-unreturned": {
    variant: "success",
    title: "Iade geri alindi",
    description: "Mektup yeniden aktif olarak isaretlendi.",
  },
  "task-created": {
    variant: "success",
    title: "Gorev eklendi",
    description: "Yeni gorev takvime ve gorevler listesine eklendi.",
  },
  "task-updated": {
    variant: "success",
    title: "Gorev guncellendi",
    description: "Gorev durumu basariyla degistirildi.",
  },
  "task-deleted": {
    variant: "success",
    title: "Gorev silindi",
    description: "Gorev listeden kaldirildi.",
  },
  "tender-result-saved": {
    variant: "success",
    title: "Ihale sonucu kaydedildi",
    description: "Firma teklifleri basariyla kaydedildi.",
  },
};

const errorMessages: Record<string, FlashMessage> = {
  "supabase-missing": {
    variant: "error",
    title: "Supabase ayarlari eksik",
    description:
      ".env.local dosyasinda NEXT_PUBLIC_SUPABASE_URL ve SUPABASE_SERVICE_ROLE_KEY alanlarini doldurun.",
  },
  "invalid-folder-data": {
    variant: "error",
    title: "Klasor bilgileri eksik",
    description: "Ihale klasoru olusturmak icin baslik ve gecerli koordinatlar girin.",
  },
  "folder-create-failed": {
    variant: "error",
    title: "Klasor olusturulamadi",
    description: "Supabase kaydi basarisiz oldu. Baglanti ve tablo yapisini kontrol edin.",
  },
  "folder-not-found": {
    variant: "error",
    title: "Ihale bulunamadi",
    description: "Islem yapmaya calistiginiz klasor mevcut degil.",
  },
  "invalid-pdf": {
    variant: "error",
    title: "Desteklenmeyen dosya turu",
    description: "Yalnizca PDF, Word (.docx/.doc) ve Excel (.xlsx/.xls) dosyalari yuklenebilir.",
  },
  "invalid-file-type": {
    variant: "error",
    title: "Desteklenmeyen dosya turu",
    description: "Yalnizca PDF, Word (.docx/.doc) ve Excel (.xlsx/.xls) dosyalari yuklenebilir.",
  },
  "no-valid-files": {
    variant: "error",
    title: "Gecerli dosya bulunamadi",
    description: "Secilen klasorde desteklenen dosya (PDF, Word, Excel) bulunamadi.",
  },
  "upload-failed": {
    variant: "error",
    title: "Yukleme tamamlanamadi",
    description: "Dosya Storage veya veritabani tarafina yazilamadi.",
  },
  "invalid-document-name": {
    variant: "error",
    title: "Dosya adi gecersiz",
    description: "Dosyalar icin bos olmayan bir gorunen ad girin.",
  },
  "document-not-found": {
    variant: "error",
    title: "Dosya bulunamadi",
    description: "Yeniden adlandirmaya calistiginiz kayit bulunamadi.",
  },
  "rename-failed": {
    variant: "error",
    title: "Dosya adi degistirilemedi",
    description: "Kayit guncellenemedi. Supabase baglantisini kontrol edin.",
  },
  "delete-failed": {
    variant: "error",
    title: "Silme islemi basarisiz",
    description: "Kayit silinemedi. Supabase baglantisini kontrol edin.",
  },
  "folder-delete-failed": {
    variant: "error",
    title: "Klasor silinemedi",
    description: "Ihale klasoru kaldirilamadi. Baglanti veya yetki durumunu kontrol edin.",
  },
  "file-too-large": {
    variant: "error",
    title: "Dosya cok buyuk",
    description: "Yuklenebilecek maksimum dosya boyutu 50 MB ile sinirlidir.",
  },
  "update-failed": {
    variant: "error",
    title: "Guncelleme basarisiz",
    description: "Ihale bilgileri kaydedilemedi. Baglanti durumunu kontrol edin.",
  },
  "invalid-document-folder-name": {
    variant: "error",
    title: "Klasor adi gecersiz",
    description: "Bos olmayan bir belge klasoru adi girin.",
  },
  "invalid-document-folder": {
    variant: "error",
    title: "Belge klasoru bulunamadi",
    description: "Sectiginiz klasor bu ihale icin bulunamadi.",
  },
  "document-folder-name-taken": {
    variant: "error",
    title: "Klasor adi kullanimda",
    description: "Ayni isimde bir belge klasoru zaten mevcut.",
  },
  "document-folder-create-failed": {
    variant: "error",
    title: "Belge klasoru olusturulamadi",
    description: "Klasor kaydedilemedi. Baglanti veya yetki durumunu kontrol edin.",
  },
  "invalid-guarantee-letter-data": {
    variant: "error",
    title: "Teminat mektubu bilgileri eksik",
    description: "Banka adi, tutar, idare ve is aciklamasi alanlarini doldurun.",
  },
  "invalid-guarantee-letter-pdf": {
    variant: "error",
    title: "Gecersiz PDF dosyasi",
    description: "Yalnizca PDF formatinda dosya yuklenebilir.",
  },
  "guarantee-letter-upload-failed": {
    variant: "error",
    title: "Teminat mektubu yuklenemedi",
    description: "Dosya Storage veya veritabani tarafina yazilamadi.",
  },
  "guarantee-letter-not-found": {
    variant: "error",
    title: "Teminat mektubu bulunamadi",
    description: "Islem yapmaya calistiginiz kayit mevcut degil.",
  },
  "invalid-task-data": {
    variant: "error",
    title: "Gorev bilgileri eksik",
    description: "Baslik ve tarih alanlarini doldurun.",
  },
  "task-not-found": {
    variant: "error",
    title: "Gorev bulunamadi",
    description: "Islem yapmaya calistiginiz gorev mevcut degil.",
  },
  "invalid-tender-result": {
    variant: "error",
    title: "Ihale sonucu eksik",
    description: "En az bir firma satiri girin.",
  },
};

export function resolveFlashMessage(
  searchParams: Record<string, string | string[] | undefined>,
): FlashMessage | null {
  const errorCode = getSingleQueryValue(searchParams.error);
  if (errorCode && errorMessages[errorCode]) {
    return errorMessages[errorCode];
  }

  const successCode = getSingleQueryValue(searchParams.success);
  if (successCode && successMessages[successCode]) {
    return successMessages[successCode];
  }

  return null;
}
