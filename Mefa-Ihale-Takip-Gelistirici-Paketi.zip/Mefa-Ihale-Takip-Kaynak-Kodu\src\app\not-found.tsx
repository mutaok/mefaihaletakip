import Link from "next/link";
import { ArrowLeft, FolderSearch } from "lucide-react";

export default function NotFound() {
  return (
    <main className="mx-auto flex min-h-screen w-full max-w-4xl flex-col items-center justify-center px-4 py-10 text-center sm:px-6">
      <div className="panel-shadow w-full rounded-[36px] border border-white/70 bg-surface/90 px-6 py-10 backdrop-blur-xl sm:px-10">
        <FolderSearch className="mx-auto size-12 text-accent" />
        <h1 className="mt-6 text-4xl font-semibold tracking-[-0.05em] text-foreground">
          Ihale klasoru bulunamadi
        </h1>
        <p className="mx-auto mt-4 max-w-2xl text-base leading-7 text-muted">
          Acmaya calistiginiz ihale kaydi silinmis olabilir ya da URL yanlis
          olabilir. Ana sayfaya donerek mevcut klasorleri tekrar listeleyin.
        </p>
        <Link
          href="/"
          className="mt-8 inline-flex items-center gap-2 rounded-full border border-foreground px-5 py-3 text-sm font-semibold text-foreground transition hover:bg-foreground hover:text-white"
        >
          <ArrowLeft className="size-4" />
          Ana sayfaya don
        </Link>
      </div>
    </main>
  );
}
