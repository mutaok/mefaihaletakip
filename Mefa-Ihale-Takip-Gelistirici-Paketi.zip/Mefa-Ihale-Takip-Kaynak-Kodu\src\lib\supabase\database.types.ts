export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[];

export type Database = {
  public: {
    Tables: {
      guarantee_letters: {
        Row: {
          amount: string;
          authority: string;
          bank_name: string;
          created_at: string;
          file_size: number | null;
          id: string;
          job_description: string;
          letter_type: string;
          original_filename: string;
          storage_path: string;
        };
        Insert: {
          amount: string;
          authority: string;
          bank_name: string;
          created_at?: string;
          file_size?: number | null;
          id?: string;
          job_description: string;
          letter_type?: string;
          original_filename: string;
          storage_path: string;
        };
        Update: {
          amount?: string;
          authority?: string;
          bank_name?: string;
          created_at?: string;
          file_size?: number | null;
          id?: string;
          job_description?: string;
          letter_type?: string;
          original_filename?: string;
          storage_path?: string;
        };
        Relationships: [];
      };
      tasks: {
        Row: {
          completed: boolean;
          completed_at: string | null;
          created_at: string;
          description: string | null;
          due_date: string;
          id: string;
          title: string;
        };
        Insert: {
          completed?: boolean;
          completed_at?: string | null;
          created_at?: string;
          description?: string | null;
          due_date: string;
          id?: string;
          title: string;
        };
        Update: {
          completed?: boolean;
          completed_at?: string | null;
          created_at?: string;
          description?: string | null;
          due_date?: string;
          id?: string;
          title?: string;
        };
        Relationships: [];
      };
      tender_document_folders: {
        Row: {
          created_at: string;
          id: string;
          name: string;
          tender_id: string;
        };
        Insert: {
          created_at?: string;
          id?: string;
          name: string;
          tender_id: string;
        };
        Update: {
          created_at?: string;
          id?: string;
          name?: string;
          tender_id?: string;
        };
        Relationships: [
          {
            foreignKeyName: "tender_document_folders_tender_id_fkey";
            columns: ["tender_id"];
            isOneToOne: false;
            referencedRelation: "tender_folders";
            referencedColumns: ["id"];
          },
        ];
      };
      tender_documents: {
        Row: {
          display_name: string;
          file_size: number | null;
          folder_id: string | null;
          id: string;
          mime_type: string;
          original_filename: string;
          storage_path: string;
          tender_id: string;
          uploaded_at: string;
        };
        Insert: {
          display_name: string;
          file_size?: number | null;
          folder_id?: string | null;
          id?: string;
          mime_type?: string;
          original_filename: string;
          storage_path: string;
          tender_id: string;
          uploaded_at?: string;
        };
        Update: {
          display_name?: string;
          file_size?: number | null;
          folder_id?: string | null;
          id?: string;
          mime_type?: string;
          original_filename?: string;
          storage_path?: string;
          tender_id?: string;
          uploaded_at?: string;
        };
        Relationships: [
          {
            foreignKeyName: "tender_documents_tender_id_fkey";
            columns: ["tender_id"];
            isOneToOne: false;
            referencedRelation: "tender_folders";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "tender_documents_folder_id_fkey";
            columns: ["folder_id"];
            isOneToOne: false;
            referencedRelation: "tender_document_folders";
            referencedColumns: ["id"];
          },
        ];
      };
      tender_folders: {
        Row: {
          authority: string | null;
          created_at: string;
          details: Json;
          description: string | null;
          id: string;
          il: string | null;
          ilce: string | null;
          latitude: number | null;
          location_name: string | null;
          longitude: number | null;
          reference_code: string | null;
          tender_date: string | null;
          title: string;
        };
        Insert: {
          authority?: string | null;
          created_at?: string;
          details?: Json;
          description?: string | null;
          id?: string;
          il?: string | null;
          ilce?: string | null;
          latitude?: number | null;
          location_name?: string | null;
          longitude?: number | null;
          reference_code?: string | null;
          tender_date?: string | null;
          title: string;
        };
        Update: {
          authority?: string | null;
          created_at?: string;
          details?: Json;
          description?: string | null;
          id?: string;
          il?: string | null;
          ilce?: string | null;
          latitude?: number | null;
          location_name?: string | null;
          longitude?: number | null;
          reference_code?: string | null;
          tender_date?: string | null;
          title?: string;
        };
        Relationships: [];
      };
    };
    Views: Record<string, never>;
    Functions: Record<string, never>;
    Enums: Record<string, never>;
    CompositeTypes: Record<string, never>;
  };
};
