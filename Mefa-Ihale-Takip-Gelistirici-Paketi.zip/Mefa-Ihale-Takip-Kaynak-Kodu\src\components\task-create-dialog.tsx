"use client";

import { useState } from "react";
import { createPortal } from "react-dom";
import { CalendarPlus, X } from "lucide-react";

import { createTaskAction } from "@/app/actions";
import { SubmitButton } from "@/components/submit-button";

const inputCls =
  "w-full rounded-xl border border-line bg-white px-3.5 py-2.5 text-sm text-foreground outline-none transition focus:border-accent focus:ring-2 focus:ring-accent/15";

const labelCls =
  "mb-1.5 block text-xs font-semibold uppercase tracking-wide text-muted";

export function TaskCreateDialog({
  defaultDate,
  disabled,
}: {
  defaultDate?: string;
  disabled?: boolean;
}) {
  const [open, setOpen] = useState(false);

  return (
    <>
      <button
        type="button"
        onClick={() => setOpen(true)}
        disabled={disabled}
        className="inline-flex items-center gap-2 rounded-xl bg-accent px-5 py-2.5 text-sm font-semibold text-white transition hover:bg-accent/90 disabled:cursor-not-allowed disabled:opacity-50"
      >
        <CalendarPlus className="size-4" />
        Yeni Görev Ekle
      </button>

      {open &&
        createPortal(
          <div className="fixed inset-0 z-50 overflow-y-auto" role="dialog" aria-modal="true">
            <div
              className="fixed inset-0 bg-black/50 backdrop-blur-sm"
              onClick={() => setOpen(false)}
            />

            <div className="relative mx-auto my-6 w-full max-w-md px-4">
              <div className="overflow-hidden rounded-3xl bg-white shadow-2xl">
                <div className="flex items-center justify-between border-b border-line px-8 py-5">
                  <h2 className="text-xl font-bold tracking-tight text-foreground">
                    Yeni Görev
                  </h2>
                  <button
                    type="button"
                    onClick={() => setOpen(false)}
                    className="grid size-9 place-items-center rounded-full border border-line text-muted transition hover:bg-line"
                  >
                    <X className="size-4" />
                  </button>
                </div>

                <form action={createTaskAction}>
                  <div className="space-y-5 p-8">
                    <label className="block">
                      <span className={labelCls}>
                        Başlık<span className="ml-1 text-rose-500">*</span>
                      </span>
                      <input
                        name="title"
                        type="text"
                        placeholder="Görev başlığı"
                        required
                        className={inputCls}
                      />
                    </label>

                    <label className="block">
                      <span className={labelCls}>
                        Tarih<span className="ml-1 text-rose-500">*</span>
                      </span>
                      <input
                        name="dueDate"
                        type="date"
                        required
                        defaultValue={defaultDate}
                        className={inputCls}
                      />
                    </label>

                    <label className="block">
                      <span className={labelCls}>Açıklama</span>
                      <textarea
                        name="description"
                        placeholder="Görevle ilgili notlar..."
                        className="w-full resize-y rounded-xl border border-line bg-white px-3.5 py-2.5 text-sm text-foreground outline-none transition focus:border-accent focus:ring-2 focus:ring-accent/15 min-h-[90px]"
                      />
                    </label>
                  </div>

                  <div className="flex items-center justify-end gap-3 border-t border-line px-8 py-5">
                    <button
                      type="button"
                      onClick={() => setOpen(false)}
                      className="rounded-xl border border-line px-5 py-2.5 text-sm font-semibold text-foreground transition hover:bg-line/30"
                    >
                      İptal
                    </button>
                    <SubmitButton
                      className="rounded-xl bg-accent px-6 py-2.5 text-sm font-semibold text-white transition hover:bg-accent/90 disabled:opacity-70"
                      pendingLabel="Kaydediliyor..."
                    >
                      Görev Ekle
                    </SubmitButton>
                  </div>
                </form>
              </div>
            </div>
          </div>,
          document.body,
        )}
    </>
  );
}
