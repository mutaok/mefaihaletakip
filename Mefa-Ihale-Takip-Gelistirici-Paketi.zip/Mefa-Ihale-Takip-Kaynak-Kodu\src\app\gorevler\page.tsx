import Link from "next/link";
import { ArrowLeft, CalendarDays, Printer } from "lucide-react";

import { StatusBanner } from "@/components/status-banner";
import { TaskBoard } from "@/components/task-board";
import { TaskCreateDialog } from "@/components/task-create-dialog";
import { resolveFlashMessage } from "@/lib/flash";
import { getTasks } from "@/lib/tasks";

export const dynamic = "force-dynamic";

type PageProps = {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
};

export default async function TasksPage({ searchParams }: PageProps) {
  const params = await searchParams;
  const flash = resolveFlashMessage(params);
  const result = await getTasks();

  return (
    <div className="flex flex-1 flex-col overflow-hidden">
      <header className="flex flex-shrink-0 flex-wrap items-center gap-4 border-b border-line bg-white/50 px-6 py-3 backdrop-blur-sm">
        <Link
          href="/"
          className="inline-flex flex-shrink-0 items-center gap-2 rounded-xl border border-line bg-white px-3.5 py-2 text-sm font-medium text-foreground transition hover:border-accent/30"
        >
          <ArrowLeft className="size-4" /> Geri
        </Link>
        <div className="flex items-center gap-3">
          <CalendarDays className="size-5 text-accent" />
          <h1 className="text-base font-bold text-foreground">Operasyonel Takvim Ve Ajanda</h1>
          <span className="rounded-full bg-accent/10 px-2.5 py-0.5 text-xs font-semibold text-accent">
            {result.activeTasks.length}
          </span>
        </div>
        <div className="ml-auto flex items-center gap-2">
          <Link
            href="/gorevler/print"
            className="inline-flex items-center gap-2 rounded-xl border border-line bg-white px-3.5 py-2 text-sm font-medium text-foreground transition hover:border-accent/30"
          >
            <Printer className="size-4" /> Yazdır
          </Link>
          <TaskCreateDialog disabled={!result.isConfigured} />
        </div>
      </header>

      <div className="flex-1 overflow-y-auto">
        {flash ? (
          <div className="px-6 pt-4">
            <StatusBanner flash={flash} />
          </div>
        ) : null}

        {!result.isConfigured && (
          <div className="mx-6 mt-4 rounded-2xl border border-sky-200 bg-sky-50/90 px-4 py-3 text-xs leading-6 text-sky-900">
            Supabase bağlantısı henüz aktif değil.
          </div>
        )}

        {result.dataError && (
          <div className="mx-6 mt-4 rounded-2xl border border-rose-200 bg-rose-50/90 px-4 py-3 text-xs leading-6 text-rose-900">
            {result.dataError}
          </div>
        )}

        <TaskBoard activeTasks={result.activeTasks} completedTasks={result.completedTasks} />
      </div>
    </div>
  );
}
