@echo off
set "PATH=C:\Users\TLAY~1\DOCUME~1\NEWPRO~1\.tools\node-v24.14.1-win-x64;%PATH%"
pushd "C:\Users\Tülay\Documents\New project"
npm run dev
popd
