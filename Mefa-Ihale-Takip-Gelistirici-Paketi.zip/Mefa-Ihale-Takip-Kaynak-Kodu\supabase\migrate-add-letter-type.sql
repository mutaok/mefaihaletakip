alter table public.guarantee_letters
  add column if not exists letter_type text not null default 'gecici';

alter table public.guarantee_letters
  drop constraint if exists guarantee_letters_letter_type_check;

alter table public.guarantee_letters
  add constraint guarantee_letters_letter_type_check
  check (letter_type in ('gecici', 'kesin'));
