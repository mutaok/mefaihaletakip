create table if not exists public.guarantee_letters (
  id uuid primary key default gen_random_uuid(),
  bank_name text not null,
  amount text not null,
  authority text not null,
  job_description text not null,
  storage_path text not null unique,
  original_filename text not null,
  file_size bigint,
  created_at timestamptz not null default timezone('utc', now())
);

create table if not exists public.tasks (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text,
  due_date date not null,
  completed boolean not null default false,
  completed_at timestamptz,
  created_at timestamptz not null default timezone('utc', now())
);

create index if not exists guarantee_letters_created_at_idx
  on public.guarantee_letters (created_at desc);

create index if not exists tasks_due_date_idx
  on public.tasks (due_date asc);

alter table public.guarantee_letters enable row level security;
alter table public.tasks enable row level security;

drop policy if exists "Anyone can read guarantee letters" on public.guarantee_letters;
create policy "Anyone can read guarantee letters"
  on public.guarantee_letters for select
  using (true);

drop policy if exists "Service role manages guarantee letters" on public.guarantee_letters;
create policy "Service role manages guarantee letters"
  on public.guarantee_letters for all
  using (true)
  with check (true);

drop policy if exists "Anyone can read tasks" on public.tasks;
create policy "Anyone can read tasks"
  on public.tasks for select
  using (true);

drop policy if exists "Service role manages tasks" on public.tasks;
create policy "Service role manages tasks"
  on public.tasks for all
  using (true)
  with check (true);
