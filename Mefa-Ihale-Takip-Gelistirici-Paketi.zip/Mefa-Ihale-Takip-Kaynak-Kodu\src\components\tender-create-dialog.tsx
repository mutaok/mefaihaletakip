"use client";

import { useState } from "react";
import { createPortal } from "react-dom";
import { Plus, X } from "lucide-react";

import { createTenderFolderAction } from "@/app/actions";
import { SubmitButton } from "@/components/submit-button";

type StaffRow = {
  quantity: string;
  position: string;
  requirements: string;
  other: string;
};

const emptyRow = (): StaffRow => ({
  quantity: "",
  position: "",
  requirements: "",
  other: "",
});

const inputCls =
  "w-full rounded-xl border border-line bg-white px-3.5 py-2.5 text-sm text-foreground outline-none transition focus:border-accent focus:ring-2 focus:ring-accent/15";

const textareaCls =
  "w-full rounded-xl border border-line bg-white px-3.5 py-2.5 text-sm text-foreground outline-none transition focus:border-accent focus:ring-2 focus:ring-accent/15 resize-y min-h-[80px]";

const labelCls =
  "mb-1.5 block text-xs font-semibold uppercase tracking-wide text-muted";

function Field({
  label,
  name,
  type = "text",
  placeholder,
  required,
}: {
  label: string;
  name: string;
  type?: string;
  placeholder?: string;
  required?: boolean;
}) {
  return (
    <label className="block">
      <span className={labelCls}>
        {label}
        {required && <span className="ml-1 text-rose-500">*</span>}
      </span>
      <input
        name={name}
        type={type}
        placeholder={placeholder}
        required={required}
        className={inputCls}
      />
    </label>
  );
}

function TextareaField({
  label,
  name,
  placeholder,
}: {
  label: string;
  name: string;
  placeholder?: string;
}) {
  return (
    <label className="block">
      <span className={labelCls}>{label}</span>
      <textarea
        name={name}
        placeholder={placeholder}
        className={textareaCls}
      />
    </label>
  );
}

function YesNoField({ label, name }: { label: string; name: string }) {
  return (
    <div>
      <span className={labelCls}>{label}</span>
      <div className="flex gap-5">
        {(
          [
            { value: "yes", text: "Evet" },
            { value: "no", text: "Hayır" },
            { value: "", text: "Belirtilmedi" },
          ] as const
        ).map(({ value, text }, i) => (
          <label key={value} className="flex cursor-pointer items-center gap-2">
            <input
              type="radio"
              name={name}
              value={value}
              defaultChecked={i === 2}
              className="accent-accent"
            />
            <span className="text-sm text-foreground">{text}</span>
          </label>
        ))}
      </div>
    </div>
  );
}

function SectionHeading({ num, title }: { num: number; title: string }) {
  return (
    <div className="flex items-center gap-3">
      <span className="grid size-8 flex-shrink-0 place-items-center rounded-full bg-accent text-sm font-bold text-white">
        {num}
      </span>
      <h3 className="text-base font-semibold text-foreground">{title}</h3>
    </div>
  );
}

export function TenderCreateDialog({
  disabled,
  variant = "tile",
}: {
  disabled?: boolean;
  variant?: "tile" | "compact" | "pill";
}) {
  const [open, setOpen] = useState(false);
  const [staff, setStaff] = useState<StaffRow[]>([emptyRow()]);

  const addRow = () => setStaff((prev) => [...prev, emptyRow()]);
  const removeRow = (i: number) =>
    setStaff((prev) => prev.filter((_, idx) => idx !== i));
  const updateRow = (i: number, field: keyof StaffRow, val: string) =>
    setStaff((prev) => {
      const next = [...prev];
      next[i] = { ...next[i], [field]: val };
      return next;
    });

  return (
    <>
      {variant === "compact" ? (
        <button
          type="button"
          onClick={() => setOpen(true)}
          disabled={disabled}
          title="Yeni İhale Ekle"
          className="grid size-9 flex-shrink-0 place-items-center rounded-full bg-accent text-white shadow-md transition hover:bg-accent/90 disabled:cursor-not-allowed disabled:opacity-50"
        >
          <Plus className="size-4" />
        </button>
      ) : variant === "pill" ? (
        <button
          type="button"
          onClick={() => setOpen(true)}
          disabled={disabled}
          className="inline-flex items-center gap-2 rounded-full bg-accent px-5 py-2.5 text-sm font-semibold text-white shadow-md transition hover:bg-accent/90 hover:shadow-lg active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-50"
        >
          <span className="grid size-5 place-items-center rounded-full border border-white/60">
            <Plus className="size-3.5" />
          </span>
          Yeni İhale Ekle
        </button>
      ) : (
        <button
          onClick={() => setOpen(true)}
          disabled={disabled}
          className="flex flex-col items-center gap-5 rounded-3xl border-2 border-dashed border-accent/40 bg-accent/5 px-10 py-12 text-accent transition hover:border-accent hover:bg-accent/10 disabled:cursor-not-allowed disabled:opacity-50"
        >
          <span className="grid size-16 place-items-center rounded-2xl bg-accent text-white shadow-lg">
            <Plus className="size-8" />
          </span>
          <span className="text-sm font-semibold">Yeni İhale Ekle</span>
        </button>
      )}

      {open && createPortal(
        <div className="fixed inset-0 z-50 overflow-y-auto" role="dialog" aria-modal="true">
          {/* Backdrop */}
          <div
            className="fixed inset-0 bg-black/50 backdrop-blur-sm"
            onClick={() => setOpen(false)}
          />

          {/* Dialog panel */}
          <div className="relative mx-auto my-6 w-full max-w-3xl px-4">
            <div className="overflow-hidden rounded-3xl bg-white shadow-2xl">
              {/* Header */}
              <div className="flex items-center justify-between border-b border-line px-8 py-5">
                <h2 className="text-xl font-bold tracking-tight text-foreground">
                  Yeni İhale Ekle
                </h2>
                <button
                  type="button"
                  onClick={() => setOpen(false)}
                  className="grid size-9 place-items-center rounded-full border border-line text-muted transition hover:bg-line"
                >
                  <X className="size-4" />
                </button>
              </div>

              <form action={createTenderFolderAction}>
                {/* Hidden technical staff JSON */}
                <input
                  type="hidden"
                  name="technicalStaffJson"
                  value={JSON.stringify(staff)}
                />

                <div className="max-h-[70vh] space-y-8 overflow-y-auto p-8">
                  {/* ── Section 1 ── */}
                  <section className="space-y-4">
                    <SectionHeading num={1} title="İhale Temel Bilgileri" />
                    <div className="grid gap-4 sm:grid-cols-2">
                      <Field label="İdare Adı" name="authority" placeholder="Kurum adı" />
                      <Field
                        label="İşin Adı"
                        name="title"
                        placeholder="İhale konusu"
                        required
                      />
                    </div>
                    <div className="grid gap-4 sm:grid-cols-2">
                      <Field
                        label="İhale Kayıt Numarası"
                        name="referenceCode"
                        placeholder="Örn: 2024/123456"
                      />
                      <Field
                        label="İhaleye Katılım Usulü"
                        name="participationMethod"
                        placeholder="Açık ihale / Belli istekliler"
                      />
                    </div>
                    <div className="grid gap-4 sm:grid-cols-2">
                      <Field label="İhale Tarihi" name="tenderDate" type="date" />
                      <Field
                        label="İşin Süresi"
                        name="deliveryDuration"
                        placeholder="Örn: 180 takvim günü"
                      />
                    </div>
                    <Field
                      label="Firma"
                      name="company"
                      placeholder="Örn: MEFA İnşaat A.Ş."
                    />
                  </section>

                  <hr className="border-line" />

                  {/* ── Section 2 ── */}
                  <section className="space-y-4">
                    <SectionHeading num={2} title="Teklif Yapısı" />
                    <div className="grid gap-4 sm:grid-cols-2">
                      <Field
                        label="Teslim Usulü"
                        name="submissionMethod"
                        placeholder="Anahtar teslim / Birim fiyat"
                      />
                      <Field
                        label="Para Birimi"
                        name="currency"
                        placeholder="TL / USD / EUR"
                      />
                    </div>
                  </section>

                  <hr className="border-line" />

                  {/* ── Section 3 ── */}
                  <section className="space-y-4">
                    <SectionHeading num={3} title="Teminatlar" />
                    <div className="grid gap-4 sm:grid-cols-2">
                      <Field
                        label="Geçici Teminat"
                        name="temporaryGuarantee"
                        placeholder="Örn: %3"
                      />
                      <Field
                        label="Kesin Teminat"
                        name="finalGuarantee"
                        placeholder="Örn: %6"
                      />
                    </div>
                    <YesNoField
                      label="Banka Referans Mektubu İstiyor mu?"
                      name="requiresBankReference"
                    />
                  </section>

                  <hr className="border-line" />

                  {/* ── Section 4 ── */}
                  <section className="space-y-4">
                    <SectionHeading num={4} title="Fiyat Farkı" />
                    <TextareaField
                      label="Fiyat Farkı Koşulları"
                      name="priceDifference"
                      placeholder="Fiyat farkı uygulanacak mı? Koşullar..."
                    />
                  </section>

                  <hr className="border-line" />

                  {/* ── Section 5 ── */}
                  <section className="space-y-4">
                    <SectionHeading num={5} title="Avans" />
                    <YesNoField label="Avans Veriliyor mu?" name="advancePayment" />
                    <Field
                      label="Avans Oranı veya Tutarı"
                      name="advanceAmount"
                      placeholder="Örn: %10 veya 500.000 TL"
                    />
                  </section>

                  <hr className="border-line" />

                  {/* ── Section 6 ── */}
                  <section className="space-y-4">
                    <SectionHeading num={6} title="İşin Süresi" />
                    <Field
                      label="İş Süresi"
                      name="workDuration"
                      placeholder="Örn: 365 takvim günü"
                    />
                  </section>

                  <hr className="border-line" />

                  {/* ── Section 7 ── */}
                  <section className="space-y-4">
                    <SectionHeading num={7} title="Teknik Personel Zorunluluğu" />
                    <div className="overflow-x-auto rounded-xl border border-line">
                      <table className="w-full text-sm">
                        <thead>
                          <tr className="bg-line/30">
                            <th className="px-3 py-2.5 text-left text-xs font-semibold uppercase tracking-wide text-muted w-20">
                              Adet
                            </th>
                            <th className="px-3 py-2.5 text-left text-xs font-semibold uppercase tracking-wide text-muted">
                              Mesleki Pozisyon
                            </th>
                            <th className="px-3 py-2.5 text-left text-xs font-semibold uppercase tracking-wide text-muted">
                              Mesleki Şartlar
                            </th>
                            <th className="px-3 py-2.5 text-left text-xs font-semibold uppercase tracking-wide text-muted">
                              Diğer
                            </th>
                            <th className="w-8" />
                          </tr>
                        </thead>
                        <tbody>
                          {staff.map((row, i) => (
                            <tr key={i} className="border-t border-line">
                              <td className="p-1.5">
                                <input
                                  value={row.quantity}
                                  onChange={(e) =>
                                    updateRow(i, "quantity", e.target.value)
                                  }
                                  placeholder="1"
                                  className="w-full rounded-lg border border-line px-2.5 py-1.5 text-sm outline-none focus:border-accent"
                                />
                              </td>
                              <td className="p-1.5">
                                <input
                                  value={row.position}
                                  onChange={(e) =>
                                    updateRow(i, "position", e.target.value)
                                  }
                                  placeholder="İnşaat Mühendisi"
                                  className="w-full rounded-lg border border-line px-2.5 py-1.5 text-sm outline-none focus:border-accent"
                                />
                              </td>
                              <td className="p-1.5">
                                <input
                                  value={row.requirements}
                                  onChange={(e) =>
                                    updateRow(i, "requirements", e.target.value)
                                  }
                                  placeholder="En az 5 yıl deneyim"
                                  className="w-full rounded-lg border border-line px-2.5 py-1.5 text-sm outline-none focus:border-accent"
                                />
                              </td>
                              <td className="p-1.5">
                                <input
                                  value={row.other}
                                  onChange={(e) =>
                                    updateRow(i, "other", e.target.value)
                                  }
                                  placeholder=""
                                  className="w-full rounded-lg border border-line px-2.5 py-1.5 text-sm outline-none focus:border-accent"
                                />
                              </td>
                              <td className="p-1.5">
                                {staff.length > 1 && (
                                  <button
                                    type="button"
                                    onClick={() => removeRow(i)}
                                    className="grid size-7 place-items-center rounded-lg text-muted transition hover:bg-rose-50 hover:text-rose-600"
                                  >
                                    <X className="size-3.5" />
                                  </button>
                                )}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                    <button
                      type="button"
                      onClick={addRow}
                      className="inline-flex items-center gap-2 rounded-xl border border-dashed border-accent/40 px-4 py-2 text-sm font-medium text-accent transition hover:border-accent hover:bg-accent/5"
                    >
                      <Plus className="size-4" />
                      Satır Ekle
                    </button>
                  </section>

                  <hr className="border-line" />

                  {/* ── Section 8 ── */}
                  <section className="space-y-4">
                    <SectionHeading num={8} title="Diğer Hususlar" />
                    <TextareaField
                      label="Notlar ve Özel Koşullar"
                      name="otherNotes"
                      placeholder="Önemli notlar, şartlar, özel koşullar..."
                    />
                  </section>
                </div>

                {/* Footer */}
                <div className="flex items-center justify-end gap-3 border-t border-line px-8 py-5">
                  <button
                    type="button"
                    onClick={() => setOpen(false)}
                    className="rounded-xl border border-line px-5 py-2.5 text-sm font-semibold text-foreground transition hover:bg-line/30"
                  >
                    İptal
                  </button>
                  <SubmitButton
                    className="rounded-xl bg-accent px-6 py-2.5 text-sm font-semibold text-white transition hover:bg-accent/90 disabled:opacity-70"
                    pendingLabel="Kaydediliyor..."
                  >
                    İhale Ekle
                  </SubmitButton>
                </div>
              </form>
            </div>
          </div>
        </div>,
        document.body
      )}
    </>
  );
}
