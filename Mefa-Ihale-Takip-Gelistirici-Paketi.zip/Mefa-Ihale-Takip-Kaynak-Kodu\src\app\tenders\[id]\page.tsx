import Link from "next/link";
import {
  ArrowLeft,
  CheckCircle2,
  Download,
  FileSpreadsheet,
  FileText,
  FileType2,
  FolderClosed,
  FolderOpen,
  FolderPlus,
  Printer,
  Trash2,
} from "lucide-react";
import { notFound } from "next/navigation";

import {
  createTenderDocumentFolderAction,
  deleteTenderDocumentAction,
  softDeleteTenderAction,
  getDocumentDownloadUrl,
  renameTenderDocumentAction,
  uploadTenderDocumentAction,
} from "@/app/actions";
import { FolderUploadForm } from "@/components/folder-upload-form";
import { RequiredDocumentsChecklist } from "@/components/required-documents-checklist";
import { StatusBanner } from "@/components/status-banner";
import { SubmitButton } from "@/components/submit-button";
import { TenderEditDialog } from "@/components/tender-edit-dialog";
import { TenderResultDialog } from "@/components/tender-result-dialog";
import { resolveFlashMessage } from "@/lib/flash";
import {
  formatBooleanAnswer,
  formatDate,
  formatDateTime,
  formatFileSize,
} from "@/lib/format";
import { getTenderDetail } from "@/lib/tenders";

export const dynamic = "force-dynamic";

const inputCls =
  "w-full rounded-xl border border-line bg-white/80 px-3.5 py-2.5 text-sm text-foreground outline-none transition focus:border-accent focus:ring-2 focus:ring-accent/15";
const documentAccept =
  ".pdf,application/pdf,.doc,application/msword,.docx,application/vnd.openxmlformats-officedocument.wordprocessingml.document,.xls,application/vnd.ms-excel,.xlsx,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";

type TenderDetailPageProps = {
  params: Promise<{ id: string }>;
  searchParams: Promise<Record<string, string | string[] | undefined>>;
};

function InfoItem({
  label,
  value,
}: {
  label: string;
  value: string | null | undefined;
}) {
  return (
    <div className="rounded-xl border border-line bg-white/60 px-4 py-3">
      <p className="text-xs font-semibold uppercase tracking-wide text-muted">
        {label}
      </p>
      <p className="mt-1.5 text-sm leading-6 text-foreground">{value || "—"}</p>
    </div>
  );
}

function SectionCard({
  num,
  title,
  children,
}: {
  num: number;
  title: string;
  children: React.ReactNode;
}) {
  return (
    <div className="rounded-2xl border border-line bg-surface/80 p-5 shadow-sm">
      <div className="mb-4 flex items-center gap-3">
        <span className="grid size-7 flex-shrink-0 place-items-center rounded-full bg-accent text-xs font-bold text-white">
          {num}
        </span>
        <h3 className="font-semibold text-foreground">{title}</h3>
      </div>
      {children}
    </div>
  );
}

function DocTypeIcon({ mimeType }: { mimeType: string }) {
  if (mimeType === "application/pdf") {
    return (
      <span className="inline-grid size-8 flex-shrink-0 place-items-center rounded-lg bg-rose-50 text-rose-600">
        <FileText className="size-4" />
      </span>
    );
  }
  if (
    mimeType === "application/msword" ||
    mimeType ===
      "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
  ) {
    return (
      <span className="inline-grid size-8 flex-shrink-0 place-items-center rounded-lg bg-blue-50 text-blue-600">
        <FileType2 className="size-4" />
      </span>
    );
  }
  if (
    mimeType === "application/vnd.ms-excel" ||
    mimeType ===
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
  ) {
    return (
      <span className="inline-grid size-8 flex-shrink-0 place-items-center rounded-lg bg-emerald-50 text-emerald-600">
        <FileSpreadsheet className="size-4" />
      </span>
    );
  }
  return (
    <span className="inline-grid size-8 flex-shrink-0 place-items-center rounded-lg bg-line text-muted">
      <FileText className="size-4" />
    </span>
  );
}

export default async function TenderDetailPage({
  params,
  searchParams,
}: TenderDetailPageProps) {
  const [{ id }, rawSearchParams] = await Promise.all([params, searchParams]);
  const flash = resolveFlashMessage(rawSearchParams);
  const result = await getTenderDetail(id);

  if (!result.isConfigured) {
    return (
      <main className="flex flex-1 flex-col gap-6 p-6">
        <Link
          href="/"
          className="inline-flex w-fit items-center gap-2 text-sm text-muted transition hover:text-foreground"
        >
          <ArrowLeft className="size-4" /> Ana sayfaya dön
        </Link>
        <StatusBanner
          flash={{
            variant: "info",
            title: "Supabase bağlantısı bekleniyor",
            description: ".env.local dosyasına bağlantı anahtarlarını ekleyin.",
          }}
        />
      </main>
    );
  }

  if (result.dataError) {
    return (
      <main className="flex flex-1 flex-col gap-6 p-6">
        <Link
          href="/"
          className="inline-flex w-fit items-center gap-2 text-sm text-muted transition hover:text-foreground"
        >
          <ArrowLeft className="size-4" /> Ana sayfaya dön
        </Link>
        <StatusBanner
          flash={{
            variant: "error",
            title: "Sorgu hatası",
            description: result.dataError,
          }}
        />
      </main>
    );
  }

  if (!result.tender) notFound();

  const tender = result.tender;
  const { details } = tender;
  const documentsBySection = new Map<string, typeof tender.documents>();

  for (const document of tender.documents) {
    const key = document.folderId ?? "root";
    const sectionDocuments = documentsBySection.get(key) ?? [];
    sectionDocuments.push(document);
    documentsBySection.set(key, sectionDocuments);
  }

  const documentSections = [
    ...(documentsBySection.has("root")
      ? [
          {
            documents: documentsBySection.get("root") ?? [],
            id: "root",
            title: "Ana Klasor",
          },
        ]
      : []),
    ...tender.documentFolders.map((folder) => ({
      documents: documentsBySection.get(folder.id) ?? [],
      id: folder.id,
      title: folder.name,
    })),
  ];

  const downloadUrls = new Map<string, string | null>();
  await Promise.all(
    tender.documents.map(async (doc) => {
      const url = await getDocumentDownloadUrl(tender.id, doc.id);
      downloadUrls.set(doc.id, url);
    }),
  );

  return (
    <div className="flex flex-1 flex-col overflow-hidden">
      {/* ── Üst bar ── */}
      <header className="flex flex-shrink-0 items-center gap-4 border-b border-line bg-white/50 px-6 py-3 backdrop-blur-sm">
        <Link
          href="/"
          className="inline-flex flex-shrink-0 items-center gap-2 rounded-xl border border-line bg-white px-3.5 py-2 text-sm font-medium text-foreground transition hover:border-accent/30 print:hidden"
        >
          <ArrowLeft className="size-4" /> Geri
        </Link>
        <div className="min-w-0 flex-1">
          <h1 className="truncate text-base font-bold text-foreground">
            {tender.title}
          </h1>
          {tender.authority && (
            <p className="truncate text-xs text-muted">{tender.authority}</p>
          )}
        </div>
        <div className="flex flex-shrink-0 items-center gap-2 print:hidden">
          <Link
            href={`/tenders/${tender.id}/print`}
            className="inline-flex items-center gap-2 rounded-xl border border-line bg-white px-4 py-2 text-sm font-semibold text-foreground transition hover:border-accent/30"
          >
            <Printer className="size-4" /> Yazdır
          </Link>
          <TenderResultDialog tenderId={tender.id} existingResult={details.result ?? null} />
          <TenderEditDialog tender={tender} />
          <form action={softDeleteTenderAction}>
            <input name="tenderId" type="hidden" value={tender.id} />
            <SubmitButton
              className="inline-flex items-center gap-2 rounded-xl border border-rose-300 bg-rose-50 px-4 py-2 text-sm font-semibold text-rose-700 transition hover:bg-rose-100 disabled:opacity-70"
              pendingLabel="Siliniyor..."
            >
              <Trash2 className="size-4" /> Sil
            </SubmitButton>
          </form>
        </div>
      </header>

      {/* ── Kaydırılabilir içerik ── */}
      <div className="flex-1 overflow-y-auto">
        <div className="mx-auto max-w-5xl space-y-4 p-6">
          {flash ? <div className="print:hidden"><StatusBanner flash={flash} /></div> : null}

          {/* İhale Sonucu (varsa, en üstte) */}
          {details.result && details.result.bids.length > 0 && (
            <div className="rounded-2xl border border-emerald-200 bg-emerald-50/80 p-5 shadow-sm">
              <div className="mb-4 flex items-center gap-3">
                <span className="grid size-7 flex-shrink-0 place-items-center rounded-full bg-emerald-600 text-white">
                  <CheckCircle2 className="size-4" />
                </span>
                <h3 className="font-semibold text-foreground">
                  İhale Sonucu
                  <span className="ml-2 text-xs font-normal text-muted">
                    {formatDateTime(details.result.finishedAt)}
                  </span>
                </h3>
              </div>
              <div className="overflow-x-auto rounded-xl border border-emerald-200/70 bg-white/70">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="bg-emerald-100/60">
                      <th className="px-4 py-2.5 text-left text-xs font-semibold uppercase tracking-wide text-emerald-900">
                        Firma İsmi
                      </th>
                      <th className="px-4 py-2.5 text-left text-xs font-semibold uppercase tracking-wide text-emerald-900">
                        Verilen Teklif
                      </th>
                      <th className="px-4 py-2.5 text-left text-xs font-semibold uppercase tracking-wide text-emerald-900">
                        İhale Dışı Kalma Sebebi
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {details.result.bids.map((bid, i) => (
                      <tr key={i} className="border-t border-emerald-100">
                        <td className="px-4 py-3 font-medium text-foreground">
                          {bid.companyName}
                        </td>
                        <td className="px-4 py-3">{bid.bidAmount || "—"}</td>
                        <td className="px-4 py-3 text-muted">
                          {bid.disqualifiedReason || "—"}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* 1 - İhale Temel Bilgileri */}
          <SectionCard num={1} title="İhale Temel Bilgileri">
            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
              <InfoItem label="İdare Adı" value={tender.authority} />
              <InfoItem label="İşin Adı" value={tender.title} />
              <InfoItem
                label="İhale Kayıt Numarası"
                value={tender.referenceCode}
              />
              <InfoItem
                label="Katılım Usulü"
                value={details.participationMethod}
              />
              <InfoItem
                label="İhale Tarihi"
                value={formatDate(tender.tenderDate)}
              />
              <InfoItem label="Teslim Süresi" value={details.deliveryDuration} />
              <InfoItem label="Firma" value={details.company} />
            </div>
          </SectionCard>

          {/* 2 - Teklif Yapısı */}
          <SectionCard num={2} title="Teklif Yapısı">
            <div className="grid gap-3 sm:grid-cols-2">
              <InfoItem label="Teslim Usulü" value={details.submissionMethod} />
              <InfoItem label="Para Birimi" value={details.currency} />
            </div>
          </SectionCard>

          {/* 3 - Teminatlar */}
          <SectionCard num={3} title="Teminatlar">
            <div className="grid gap-3 sm:grid-cols-3">
              <InfoItem
                label="Geçici Teminat"
                value={details.temporaryGuarantee}
              />
              <InfoItem label="Kesin Teminat" value={details.finalGuarantee} />
              <InfoItem
                label="Banka Referans Mektubu"
                value={formatBooleanAnswer(details.requiresBankReference)}
              />
            </div>
          </SectionCard>

          {/* 4 - Fiyat Farkı */}
          <SectionCard num={4} title="Fiyat Farkı">
            <p className="whitespace-pre-wrap text-sm leading-7 text-foreground">
              {details.priceDifference || "—"}
            </p>
          </SectionCard>

          {/* 5 - Avans */}
          <SectionCard num={5} title="Avans">
            <div className="grid gap-3 sm:grid-cols-2">
              <InfoItem
                label="Avans Veriliyor mu?"
                value={formatBooleanAnswer(details.advancePayment)}
              />
              <InfoItem
                label="Avans Oranı veya Tutarı"
                value={details.advanceAmount}
              />
            </div>
          </SectionCard>

          {/* 6 - İşin Süresi */}
          <SectionCard num={6} title="İşin Süresi">
            <p className="text-sm text-foreground">
              {details.workDuration || "—"}
            </p>
          </SectionCard>

          {/* 7 - Teknik Personel */}
          <SectionCard num={7} title="Teknik Personel Zorunluluğu">
            {details.technicalStaff.length > 0 ? (
              <div className="overflow-x-auto rounded-xl border border-line">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="bg-line/30">
                      <th className="px-4 py-2.5 text-left text-xs font-semibold uppercase tracking-wide text-muted">
                        Adet
                      </th>
                      <th className="px-4 py-2.5 text-left text-xs font-semibold uppercase tracking-wide text-muted">
                        Mesleki Pozisyon
                      </th>
                      <th className="px-4 py-2.5 text-left text-xs font-semibold uppercase tracking-wide text-muted">
                        Mesleki Şartlar
                      </th>
                      <th className="px-4 py-2.5 text-left text-xs font-semibold uppercase tracking-wide text-muted">
                        Diğer
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {details.technicalStaff.map((item, i) => (
                      <tr key={i} className="border-t border-line">
                        <td className="px-4 py-3">{item.quantity || "—"}</td>
                        <td className="px-4 py-3">{item.position || "—"}</td>
                        <td className="px-4 py-3">{item.requirements || "—"}</td>
                        <td className="px-4 py-3">{item.other || "—"}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <p className="text-sm text-muted">
                Teknik personel zorunluluğu belirtilmedi.
              </p>
            )}
          </SectionCard>

          {/* 8 - Diğer Hususlar */}
          <SectionCard num={8} title="Diğer Hususlar">
            <p className="whitespace-pre-wrap text-sm leading-7 text-foreground">
              {details.otherNotes || "—"}
            </p>
          </SectionCard>

          {/* 9 - İhale İstenilen Evraklar */}
          <SectionCard num={9} title="İhale İstenilen Evraklar">
            <RequiredDocumentsChecklist
              tenderId={tender.id}
              requiredDocuments={details.requiredDocuments}
            />
          </SectionCard>

          {/* ── Dokümanlar ── */}
          <div className="overflow-hidden rounded-2xl border border-line bg-surface/80 shadow-sm">
            {/* Başlık */}
            <div className="flex items-center gap-3 border-b border-line bg-white/50 px-5 py-4">
              <FileText className="size-5 text-accent" />
              <h3 className="font-semibold text-foreground">Dokümanlar</h3>
              <span className="rounded-full bg-accent/10 px-2.5 py-0.5 text-xs font-semibold text-accent">
                {tender.documents.length} Dosya
              </span>
            </div>

            {/* Yukleme islemleri */}
            <div className="space-y-4 border-b border-line bg-card/50 p-5 print:hidden">

              {/* ── 1. Klasör Oluştur ── */}
              <div className="rounded-2xl border border-line bg-white/70 p-4">
                <p className="mb-3 flex items-center gap-2 text-xs font-semibold uppercase tracking-wide text-muted">
                  <FolderPlus className="size-4" /> Yeni Klasör Oluştur
                </p>
                <form action={createTenderDocumentFolderAction} className="flex flex-wrap items-end gap-3">
                  <input name="tenderId" type="hidden" value={tender.id} />
                  <div className="min-w-[200px] flex-1">
                    <label className="block">
                      <span className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-muted">
                        Klasör Adı
                      </span>
                      <input
                        name="folderName"
                        required
                        placeholder="Örn: İdari Belgeler"
                        className={inputCls}
                      />
                    </label>
                  </div>
                  <SubmitButton
                    className="inline-flex flex-shrink-0 items-center gap-2 rounded-xl border border-line bg-white px-4 py-2.5 text-sm font-semibold text-foreground transition hover:border-accent/30 disabled:opacity-70"
                    pendingLabel="Oluşturuluyor..."
                  >
                    <FolderPlus className="size-4" /> Ekle
                  </SubmitButton>
                </form>
                {tender.documentFolders.length > 0 && (
                  <div className="mt-3 flex flex-wrap gap-2">
                    {tender.documentFolders.map((f) => (
                      <span key={f.id} className="inline-flex items-center gap-1.5 rounded-full border border-accent/20 bg-accent/5 px-3 py-1 text-xs font-medium text-accent">
                        <FolderClosed className="size-3" />
                        {f.name}
                        <span className="text-muted">({f.documentCount})</span>
                      </span>
                    ))}
                  </div>
                )}
              </div>

              {/* ── 2. Tek Dosya Yükle ── */}
              <div className="rounded-2xl border border-line bg-white/70 p-4">
                <p className="mb-3 flex items-center gap-2 text-xs font-semibold uppercase tracking-wide text-muted">
                  <FileText className="size-4" /> Tek Dosya Yükle
                </p>
                <form
                  action={uploadTenderDocumentAction}
                  encType="multipart/form-data"
                  className="flex flex-wrap items-end gap-3"
                >
                  <input name="tenderId" type="hidden" value={tender.id} />
                  <div className="min-w-[180px] flex-1">
                    <label className="block">
                      <span className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-muted">
                        Dosya Adı
                      </span>
                      <input
                        name="displayName"
                        required
                        placeholder="Örn: Teknik Şartname"
                        className={inputCls}
                      />
                    </label>
                  </div>
                  <div className="min-w-[160px] flex-1">
                    <label className="block">
                      <span className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-muted">
                        Klasör
                      </span>
                      <select name="folderName" defaultValue="" className={inputCls}>
                        <option value="">Ana Klasör</option>
                        {tender.documentFolders.map((folder) => (
                          <option key={folder.id} value={folder.name}>
                            {folder.name}
                          </option>
                        ))}
                      </select>
                    </label>
                  </div>
                  <div className="min-w-[200px] flex-1">
                    <label className="block">
                      <span className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-muted">
                        Dosya (PDF / Word / Excel)
                      </span>
                      <input
                        type="file"
                        name="file"
                        required
                        accept={documentAccept}
                        className="w-full rounded-xl border border-dashed border-line bg-white/80 px-3.5 py-2 text-sm text-muted file:mr-3 file:rounded-lg file:border-0 file:bg-accent file:px-3 file:py-1.5 file:text-xs file:font-semibold file:text-white"
                      />
                    </label>
                    <p className="mt-1 text-xs text-muted">Maks. 200 MB</p>
                  </div>
                  <SubmitButton
                    className="flex-shrink-0 rounded-xl bg-foreground px-5 py-2.5 text-sm font-semibold text-white transition hover:bg-foreground/90 disabled:opacity-70"
                    pendingLabel="Yükleniyor..."
                  >
                    Yükle
                  </SubmitButton>
                </form>
              </div>

              {/* ── 3. Klasörden Toplu Yükle ── */}
              <div className="rounded-2xl border border-line bg-white/70 p-4">
                <p className="mb-3 flex items-center gap-2 text-xs font-semibold uppercase tracking-wide text-muted">
                  <FolderOpen className="size-4" /> Klasörden Toplu Yükle
                </p>
                <FolderUploadForm
                  tenderId={tender.id}
                  documentFolders={tender.documentFolders.map((f) => ({
                    id: f.id,
                    name: f.name,
                  }))}
                />
              </div>
            </div>

            {/* Dokuman listesi */}
            {documentSections.length > 0 ? (
              <div className="divide-y divide-line">
                {documentSections.map((section) => (
                  <div key={section.id}>
                    <div className="flex items-center gap-2 border-b border-line bg-white/40 px-5 py-3">
                      <FolderClosed className="size-4 text-accent" />
                      <p className="text-sm font-semibold text-foreground">
                        {section.title}
                      </p>
                      <span className="rounded-full bg-accent/10 px-2 py-0.5 text-[11px] font-semibold text-accent">
                        {section.documents.length} dosya
                      </span>
                    </div>

                    {section.documents.length > 0 ? (
                      section.documents.map((doc) => (
                        <div key={doc.id} className="px-5 py-4">
                          <div className="flex flex-wrap items-center justify-between gap-3">
                            <div className="flex min-w-0 items-center gap-3">
                              <DocTypeIcon mimeType={doc.mimeType} />
                              <div className="min-w-0">
                              <p className="truncate text-sm font-semibold text-foreground">
                                {doc.displayName}
                              </p>
                              <p className="mt-0.5 text-xs text-muted">
                                {doc.originalFilename} ·{" "}
                                {formatFileSize(doc.fileSize)} ·{" "}
                                {formatDateTime(doc.uploadedAt)}
                              </p>
                              </div>
                            </div>
                            <div className="flex flex-shrink-0 items-center gap-2">
                              {downloadUrls.get(doc.id) ? (
                                <a
                                  href={downloadUrls.get(doc.id)!}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="inline-flex items-center gap-1.5 rounded-lg border border-accent/30 bg-accent/10 px-3 py-1.5 text-xs font-semibold text-accent transition hover:bg-accent/20"
                                >
                                  <Download className="size-3.5" /> Indir
                                </a>
                              ) : null}
                              <form action={deleteTenderDocumentAction}>
                                <input
                                  name="tenderId"
                                  type="hidden"
                                  value={tender.id}
                                />
                                <input
                                  name="documentId"
                                  type="hidden"
                                  value={doc.id}
                                />
                                <SubmitButton
                                  className="inline-flex items-center gap-1.5 rounded-lg border border-rose-200 bg-rose-50 px-3 py-1.5 text-xs font-semibold text-rose-700 transition hover:bg-rose-100 disabled:opacity-70"
                                  pendingLabel="..."
                                >
                                  <Trash2 className="size-3.5" /> Sil
                                </SubmitButton>
                              </form>
                            </div>
                          </div>

                          {/* Yeniden adlandirma */}
                          <form
                            action={renameTenderDocumentAction}
                            className="mt-2 flex items-center gap-2"
                          >
                            <input
                              name="tenderId"
                              type="hidden"
                              value={tender.id}
                            />
                            <input
                              name="documentId"
                              type="hidden"
                              value={doc.id}
                            />
                            <input
                              name="displayName"
                              defaultValue={doc.displayName}
                              required
                              className="flex-1 rounded-lg border border-line bg-white/80 px-3 py-1.5 text-xs text-foreground outline-none focus:border-accent"
                            />
                            <SubmitButton
                              className="flex-shrink-0 rounded-lg border border-line px-3 py-1.5 text-xs font-semibold text-foreground transition hover:bg-line/30 disabled:opacity-70"
                              pendingLabel="..."
                            >
                              Yeniden Adlandir
                            </SubmitButton>
                          </form>
                        </div>
                      ))
                    ) : (
                      <div className="px-5 py-4 text-sm text-muted">
                        Bu klasorde henuz dosya yok.
                      </div>
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <div className="flex flex-col items-center gap-2 p-10 text-center">
                <FileText className="size-10 text-muted/40" />
                <p className="text-sm text-muted">Henuz dosya yuklenmedi</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
