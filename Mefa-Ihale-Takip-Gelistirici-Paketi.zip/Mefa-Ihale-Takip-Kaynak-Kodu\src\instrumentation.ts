/**
 * Next.js sunucu başlangıcında bir kez çağrılır (bkz. Next.js "instrumentation"
 * dosya kuralı). Uygulama açıkken saatlik olarak e-posta hatırlatıcılarını
 * kontrol eden zamanlayıcıyı burada kuruyoruz — ayrı bir sunucu/cron altyapısı
 * gerektirmez, uygulamanın kendi ömrü boyunca çalışır.
 */
export async function register() {
  if (process.env.NEXT_RUNTIME !== "nodejs") return;

  const { runReminderCheck } = await import("@/lib/reminders");

  const CHECK_INTERVAL_MS = 60 * 60 * 1000; // 1 saat

  const check = () => {
    runReminderCheck().catch((err) => {
      console.error("Hatırlatıcı kontrolü başarısız:", err);
    });
  };

  // Açılıştan kısa bir süre sonra ilk kontrol, ardından saatlik.
  setTimeout(check, 15_000);
  setInterval(check, CHECK_INTERVAL_MS);
}
