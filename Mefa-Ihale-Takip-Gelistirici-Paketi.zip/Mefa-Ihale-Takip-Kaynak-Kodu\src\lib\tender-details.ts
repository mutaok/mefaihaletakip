import type { Json } from "@/lib/supabase/database.types";

export type TechnicalStaffItem = {
  other: string;
  position: string;
  quantity: string;
  requirements: string;
};

export type RequiredDocumentItem = {
  name: string;
  checked: boolean;
};

export type TenderResultBid = {
  companyName: string;
  bidAmount: string;
  disqualifiedReason: string | null;
};

export type TenderResult = {
  bids: TenderResultBid[];
  finishedAt: string;
};

export type TenderDetails = {
  advanceAmount: string | null;
  advancePayment: boolean | null;
  company: string | null;
  currency: string | null;
  deliveryDuration: string | null;
  documentFolders?: string[];
  evaluationCriteria: string | null;
  finalGuarantee: string | null;
  otherNotes: string | null;
  participationMethod: string | null;
  priceDifference: string | null;
  requiredDocuments: RequiredDocumentItem[];
  requiresBankReference: boolean | null;
  result?: TenderResult | null;
  submissionMethod: string | null;
  technicalStaff: TechnicalStaffItem[];
  temporaryGuarantee: string | null;
  workDuration: string | null;
};

export const EMPTY_TENDER_DETAILS: TenderDetails = {
  advanceAmount: null,
  advancePayment: null,
  company: null,
  currency: null,
  deliveryDuration: null,
  documentFolders: [],
  evaluationCriteria: null,
  finalGuarantee: null,
  otherNotes: null,
  participationMethod: null,
  priceDifference: null,
  requiredDocuments: [],
  requiresBankReference: null,
  result: null,
  submissionMethod: null,
  technicalStaff: [],
  temporaryGuarantee: null,
  workDuration: null,
};

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function readNullableString(value: unknown): string | null {
  if (typeof value !== "string") {
    return null;
  }

  const text = value.trim();
  return text ? text : null;
}

function readNullableBoolean(value: unknown): boolean | null {
  return typeof value === "boolean" ? value : null;
}

export function normalizeTechnicalStaff(value: unknown): TechnicalStaffItem[] {
  if (!Array.isArray(value)) {
    return [];
  }

  return value
    .map((item) => {
      if (!isRecord(item)) {
        return null;
      }

      const normalizedItem = {
        other: readNullableString(item.other) ?? "",
        position: readNullableString(item.position) ?? "",
        quantity: readNullableString(item.quantity) ?? "",
        requirements: readNullableString(item.requirements) ?? "",
      };

      return Object.values(normalizedItem).some(Boolean) ? normalizedItem : null;
    })
    .filter((item): item is TechnicalStaffItem => item !== null);
}

export function normalizeRequiredDocuments(value: unknown): RequiredDocumentItem[] {
  if (!Array.isArray(value)) return [];
  return value
    .map((item) => {
      if (!isRecord(item)) return null;
      const name = readNullableString(item.name);
      if (!name) return null;
      return { name, checked: typeof item.checked === "boolean" ? item.checked : false };
    })
    .filter((item): item is RequiredDocumentItem => item !== null);
}

export function normalizeTenderResultBids(value: unknown): TenderResultBid[] {
  if (!Array.isArray(value)) return [];
  return value
    .map((item) => {
      if (!isRecord(item)) return null;
      const companyName = readNullableString(item.companyName);
      if (!companyName) return null;
      return {
        bidAmount: readNullableString(item.bidAmount) ?? "",
        companyName,
        disqualifiedReason: readNullableString(item.disqualifiedReason),
      };
    })
    .filter((item): item is TenderResultBid => item !== null);
}

export function readTenderResult(
  value: Json | Record<string, unknown> | null | undefined,
): TenderResult | null {
  if (!isRecord(value) || !isRecord(value.result)) return null;

  const finishedAt = readNullableString(value.result.finishedAt);
  if (!finishedAt) return null;

  return {
    bids: normalizeTenderResultBids(value.result.bids),
    finishedAt,
  };
}

export type TenderOutcome = "won" | "lost" | "finished";

/** "1.234.567,89 TL" gibi Türkçe biçimli tutarları sayıya çevirir. */
export function parseBidAmount(raw: string): number | null {
  const cleaned = raw.replace(/[^\d.,]/g, "");
  if (!cleaned) return null;

  let normalized: string;
  if (cleaned.includes(",")) {
    normalized = cleaned.replace(/\./g, "").replace(",", ".");
  } else {
    const parts = cleaned.split(".");
    // Tek nokta ve 1-2 basamaklı son kısım ondalık kabul edilir; aksi halde binlik ayracı
    normalized = parts.length === 2 && parts[1].length <= 2 ? cleaned : parts.join("");
  }

  const value = Number(normalized);
  return Number.isFinite(value) ? value : null;
}

/**
 * Sonuç girilmişse ihalenin akıbetini türetir: kendi firmamız (details.company)
 * diskalifiye olmayan en düşük teklifi verdiyse "won", vermediyse "lost";
 * firma bilgisi veya karşılaştırılabilir teklif yoksa "finished".
 * Sonuç girilmemişse null (değerlendirmede).
 */
export function deriveTenderOutcome(
  value: Json | Record<string, unknown> | null | undefined,
): TenderOutcome | null {
  const result = readTenderResult(value);
  if (!result || result.bids.length === 0) {
    return result ? "finished" : null;
  }

  const company = isRecord(value) ? readNullableString(value.company) : null;
  if (!company) return "finished";

  const normalizedCompany = company.toLocaleLowerCase("tr-TR");
  const validBids = result.bids
    .filter((bid) => !bid.disqualifiedReason)
    .map((bid) => ({
      amount: parseBidAmount(bid.bidAmount),
      name: bid.companyName.trim().toLocaleLowerCase("tr-TR"),
    }))
    .filter((bid) => bid.name && bid.amount !== null);

  if (validBids.length === 0) return "finished";

  const lowest = validBids.reduce((min, bid) =>
    bid.amount! < min.amount! ? bid : min,
  );
  const won =
    lowest.name.includes(normalizedCompany) ||
    normalizedCompany.includes(lowest.name);
  return won ? "won" : "lost";
}

export type TenderStatus =
  | { kind: "upcoming"; daysRemaining: number }
  | { kind: "won" }
  | { kind: "lost" }
  | { kind: "finished" }
  | { kind: "open" };

function daysBetween(fromKey: string, toKey: string): number {
  const from = new Date(`${fromKey}T00:00:00`);
  const to = new Date(`${toKey}T00:00:00`);
  return Math.round((to.getTime() - from.getTime()) / 86_400_000);
}

/**
 * Sonuç girilmemiş ihaleler için tarih temelli görünüm durumu türetir:
 * ihale tarihi henüz gelmediyse "upcoming" (kaç gün kaldığıyla birlikte),
 * tarih geçtiyse veya belirtilmediyse "open" (Değerlendirmede).
 * Sonuç girilmişse doğrudan outcome'u yansıtır.
 */
export function deriveTenderStatus(
  outcome: TenderOutcome | null,
  tenderDate: string | null,
  todayKey: string,
): TenderStatus {
  if (outcome === "won") return { kind: "won" };
  if (outcome === "lost") return { kind: "lost" };
  if (outcome === "finished") return { kind: "finished" };

  if (tenderDate && tenderDate > todayKey) {
    return { kind: "upcoming", daysRemaining: daysBetween(todayKey, tenderDate) };
  }
  return { kind: "open" };
}

export function withTenderResult(
  details: Json,
  result: TenderResult | null,
): Json {
  const baseDetails = isRecord(details) ? details : {};
  return {
    ...baseDetails,
    result: result
      ? { bids: normalizeTenderResultBids(result.bids), finishedAt: result.finishedAt }
      : null,
  };
}

export function readRequiredDocuments(
  value: Json | Record<string, unknown> | null | undefined,
): RequiredDocumentItem[] {
  if (!isRecord(value)) return [];
  return normalizeRequiredDocuments(value.requiredDocuments);
}

export function withRequiredDocuments(
  details: Json,
  requiredDocuments: RequiredDocumentItem[],
): Json {
  const baseDetails = isRecord(details) ? details : {};
  return { ...baseDetails, requiredDocuments: normalizeRequiredDocuments(requiredDocuments) };
}

export function readDeletedAt(
  value: Json | Record<string, unknown> | null | undefined,
): string | null {
  if (!isRecord(value)) return null;
  return readNullableString(value._deletedAt);
}

export function withDeletedAt(details: Json, deletedAt: string | null): Json {
  const baseDetails = isRecord(details) ? details : {};
  return { ...baseDetails, _deletedAt: deletedAt };
}

export function parseTenderDetails(value: Json | null | undefined): TenderDetails {
  if (!isRecord(value)) {
    return EMPTY_TENDER_DETAILS;
  }

  return {
    advanceAmount: readNullableString(value.advanceAmount),
    advancePayment: readNullableBoolean(value.advancePayment),
    company: readNullableString(value.company),
    currency: readNullableString(value.currency),
    deliveryDuration: readNullableString(value.deliveryDuration),
    documentFolders: readDocumentFolders(value),
    evaluationCriteria: readNullableString(value.evaluationCriteria),
    finalGuarantee: readNullableString(value.finalGuarantee),
    otherNotes: readNullableString(value.otherNotes),
    participationMethod: readNullableString(value.participationMethod),
    priceDifference: readNullableString(value.priceDifference),
    requiredDocuments: normalizeRequiredDocuments(value.requiredDocuments),
    requiresBankReference: readNullableBoolean(value.requiresBankReference),
    result: readTenderResult(value),
    submissionMethod: readNullableString(value.submissionMethod),
    technicalStaff: normalizeTechnicalStaff(value.technicalStaff),
    temporaryGuarantee: readNullableString(value.temporaryGuarantee),
    workDuration: readNullableString(value.workDuration),
  };
}

export function buildTenderDetails(details: TenderDetails): Json {
  return {
    advanceAmount: details.advanceAmount,
    advancePayment: details.advancePayment,
    company: details.company,
    currency: details.currency,
    deliveryDuration: details.deliveryDuration,
    documentFolders: normalizeDocumentFolders(details.documentFolders),
    evaluationCriteria: details.evaluationCriteria,
    finalGuarantee: details.finalGuarantee,
    otherNotes: details.otherNotes,
    participationMethod: details.participationMethod,
    priceDifference: details.priceDifference,
    requiredDocuments: normalizeRequiredDocuments(details.requiredDocuments),
    requiresBankReference: details.requiresBankReference,
    result: details.result ?? null,
    submissionMethod: details.submissionMethod,
    technicalStaff: normalizeTechnicalStaff(details.technicalStaff),
    temporaryGuarantee: details.temporaryGuarantee,
    workDuration: details.workDuration,
  };
}

export function normalizeDocumentFolders(value: unknown): string[] {
  if (!Array.isArray(value)) {
    return [];
  }

  return Array.from(
    new Set(
      value
        .map((item) => (typeof item === "string" ? item.trim() : ""))
        .filter(Boolean),
    ),
  );
}

export function readDocumentFolders(
  value: Json | Record<string, unknown> | null | undefined,
): string[] {
  if (!isRecord(value)) {
    return [];
  }

  return normalizeDocumentFolders(value.documentFolders);
}

export function withDocumentFolders(
  details: Json,
  documentFolders: string[],
): Json {
  const baseDetails = isRecord(details) ? details : {};

  return {
    ...baseDetails,
    documentFolders: normalizeDocumentFolders(documentFolders),
  };
}
