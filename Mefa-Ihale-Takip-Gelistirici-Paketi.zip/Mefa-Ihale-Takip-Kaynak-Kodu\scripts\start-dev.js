const fs = require("fs");
const path = require("path");
const { spawn } = require("child_process");

const root = fs.realpathSync(path.resolve(__dirname, ".."));
process.chdir(root);

const nodeBin = path.join(root, ".tools", "node-v24.14.1-win-x64");
process.env.PATH = nodeBin + ";" + process.env.PATH;

const nextBin = path.join(root, "node_modules", "next", "dist", "bin", "next");
const child = spawn(process.execPath, [nextBin, "dev", "--webpack"], {
  cwd: root,
  stdio: "inherit",
  env: process.env,
});
child.on("exit", (code) => process.exit(code ?? 1));
