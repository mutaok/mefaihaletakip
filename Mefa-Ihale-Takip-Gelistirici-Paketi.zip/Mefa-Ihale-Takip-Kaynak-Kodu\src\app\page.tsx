import Link from "next/link";
import { FolderOpen, Printer, Trash2 } from "lucide-react";

import { DashboardCalendar, type DashboardCalendarEvent } from "@/components/dashboard-calendar";
import { DashboardStatCard } from "@/components/dashboard-stat-card";
import { DashboardTaskList } from "@/components/dashboard-task-list";
import { TenderCreateDialog } from "@/components/tender-create-dialog";
import { StatusBanner } from "@/components/status-banner";
import { resolveFlashMessage } from "@/lib/flash";
import { formatDate, todayDateKey } from "@/lib/format";
import { getDeletedTenders, getTenderDashboardData, type TenderSummary } from "@/lib/tenders";
import { deriveTenderStatus, type TenderStatus } from "@/lib/tender-details";
import { getTasks } from "@/lib/tasks";
import { getGuaranteeLetters } from "@/lib/guarantee-letters";

export const dynamic = "force-dynamic";

type HomePageProps = {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
};

const STATUS_CHIP: Record<Exclude<TenderStatus["kind"], "upcoming">, { label: string; className: string }> = {
  open: { label: "Değerlendirmede", className: "bg-amber-500" },
  won: { label: "Kazanıldı", className: "bg-emerald-500" },
  lost: { label: "Sözleşme İmzalanmadı", className: "bg-rose-500" },
  finished: { label: "Sonuçlandı", className: "bg-slate-400" },
};

function StatusChip({ status, dateLabel }: { status: TenderStatus; dateLabel: string }) {
  if (status.kind === "upcoming") {
    return (
      <span className="inline-flex items-center gap-1.5 whitespace-nowrap rounded-md border border-blue-200 bg-blue-50 px-3 py-1 text-xs font-semibold text-blue-700">
        <span>{dateLabel}</span>
        <span className="text-blue-300">·</span>
        <span className="tabular-nums">{status.daysRemaining} gün kaldı</span>
      </span>
    );
  }
  const meta = STATUS_CHIP[status.kind];
  return (
    <span
      className={`inline-flex items-center rounded-md px-3 py-1 text-xs font-semibold text-white shadow-sm ${meta.className}`}
    >
      {meta.label}
    </span>
  );
}

function buildCalendarEvents(
  tenders: TenderSummary[],
  tasks: { dueDate: string; title: string }[],
): DashboardCalendarEvent[] {
  const events: DashboardCalendarEvent[] = [];
  for (const tender of tenders) {
    if (tender.tenderDate) {
      events.push({ date: tender.tenderDate, kind: "tender", label: tender.title });
    }
  }
  for (const task of tasks) {
    events.push({ date: task.dueDate, kind: "task", label: task.title });
  }
  return events;
}

export default async function Home({ searchParams }: HomePageProps) {
  const params = await searchParams;
  const flash = resolveFlashMessage(params);
  const [dashboard, deletedResult, tasksResult, guaranteeLettersResult] = await Promise.all([
    getTenderDashboardData(),
    getDeletedTenders(),
    getTasks(),
    getGuaranteeLetters(),
  ]);
  const appReady = dashboard.isConfigured && !dashboard.dataError;
  const deletedCount = deletedResult.tenders.length;

  const openCount = dashboard.tenders.filter((tender) => tender.outcome === null).length;
  const wonCount = dashboard.tenders.filter((tender) => tender.outcome === "won").length;
  const lostCount = dashboard.tenders.filter((tender) => tender.outcome === "lost").length;
  const completedCount = dashboard.tenders.length - openCount;

  const letters = guaranteeLettersResult.letters;
  const latestLetter = letters[0] ?? null;

  const summary = `${openCount} Açık İhale, ${guaranteeLettersResult.activeCount} Aktif Teminat`;
  const events = buildCalendarEvents(dashboard.tenders, tasksResult.activeTasks);
  const todayKey = todayDateKey();

  return (
    <div className="flex flex-1 overflow-hidden max-lg:flex-col max-lg:overflow-y-auto">
      {/* ── Sol panel: başlık + ihale tablosu ── */}
      <section className="min-w-0 bg-[#fbfcfa] p-6 lg:w-[48.5%] lg:overflow-y-auto lg:p-8">
        <header className="mb-6">
          <h1 className="text-[28px] font-extrabold italic tracking-tight text-foreground">
            Mefa Group İhale Takip
          </h1>
          <p className="mt-1 text-sm text-muted">Mevcut Durum: {summary}</p>
        </header>

        {flash ? (
          <div className="mb-4">
            <StatusBanner flash={flash} />
          </div>
        ) : null}

        {!dashboard.isConfigured && (
          <div className="mb-4 rounded-2xl border border-sky-200 bg-sky-50/90 px-4 py-3 text-xs leading-6 text-sky-900">
            Supabase bağlantısı henüz aktif değil.
          </div>
        )}

        {dashboard.dataError && (
          <div className="mb-4 rounded-2xl border border-rose-200 bg-rose-50/90 px-4 py-3 text-xs leading-6 text-rose-900">
            {dashboard.dataError}
          </div>
        )}

        <div className="rounded-2xl bg-white p-6 shadow-[0_2px_16px_rgba(21,54,50,0.07)]">
          <div className="mb-4 flex flex-wrap items-center justify-between gap-4">
            <h2 className="text-lg font-extrabold tracking-wide text-foreground">
              EKLENEN İHALELER
            </h2>
            <div className="flex items-center gap-2">
              <Link
                href="/aktif-ihaleler/print"
                title="Aktif ihaleleri yazdır"
                className="inline-flex items-center gap-2 rounded-full border border-line bg-white px-3.5 py-2 text-sm font-semibold text-muted transition hover:border-accent/30 hover:text-foreground"
              >
                <Printer className="size-4" />
              </Link>
              <TenderCreateDialog disabled={!appReady} variant="pill" />
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full min-w-[420px] text-sm">
              <thead>
                <tr className="text-left text-xs font-medium text-muted">
                  <th className="pb-3 font-medium">İhale Adı</th>
                  <th className="pb-3 font-medium">Başvuru Tarihi</th>
                  <th className="pb-3 font-medium">Durum</th>
                </tr>
              </thead>
              <tbody>
                {dashboard.tenders.length === 0 && (
                  <tr>
                    <td colSpan={3} className="py-12 text-center">
                      <FolderOpen className="mx-auto mb-2 size-8 text-muted/40" />
                      <span className="text-xs text-muted">Henüz ihale eklenmedi</span>
                    </td>
                  </tr>
                )}
                {dashboard.tenders.map((tender) => (
                  <tr
                    key={tender.id}
                    className="border-t border-line/60 transition-colors hover:bg-accent/5"
                  >
                    <td className="py-1 pr-4">
                      <Link
                        href={`/tenders/${tender.id}`}
                        className="block truncate py-2.5 font-medium text-foreground"
                      >
                        {tender.title}
                      </Link>
                    </td>
                    <td className="whitespace-nowrap py-3.5 pr-4 text-muted">
                      {formatDate(tender.tenderDate)}
                    </td>
                    <td className="py-3.5">
                      <StatusChip
                        status={deriveTenderStatus(tender.outcome, tender.tenderDate, todayKey)}
                        dateLabel={formatDate(tender.tenderDate)}
                      />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {deletedCount > 0 && (
          <Link
            href="/trash"
            className="mt-4 flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm text-muted transition hover:bg-white hover:text-foreground"
          >
            <Trash2 className="size-4" />
            Çöp Kutusu
            <span className="ml-auto rounded-full bg-rose-100 px-2 py-0.5 text-xs font-semibold text-rose-700">
              {deletedCount}
            </span>
          </Link>
        )}
      </section>

      {/* ── Sağ panel: yönetici özeti ── */}
      <section className="min-w-0 flex-1 space-y-6 bg-[#eef0ea] p-6 lg:overflow-y-auto lg:p-8">
        <header className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <h2 className="text-xl font-extrabold tracking-wide text-foreground">
              YÖNETİCİ ÖZETİ
            </h2>
            <p className="mt-1 text-[11px] font-semibold tracking-wider text-muted">
              KONTROL PANELİ GÖSTERGELERİ
            </p>
          </div>
          <p className="text-sm font-semibold text-foreground/80">{summary}</p>
        </header>

        <div className="grid grid-cols-[minmax(0,1fr)] gap-6 sm:grid-cols-[minmax(0,1fr)_minmax(0,1fr)]">
          <DashboardStatCard
            href="/teminat-mektuplari"
            value={guaranteeLettersResult.activeCount}
            title="Aktif Teminat Mektubu"
            subtitle={`${guaranteeLettersResult.geciciCount} Geçici, ${guaranteeLettersResult.kesinCount} Kesin`}
            legend={[
              {
                dotClass: "bg-accent",
                label: "Son Eklenen",
                value: latestLetter ? formatDateShort(latestLetter.createdAt) : "—",
              },
              {
                dotClass: "bg-emerald-500",
                label: "İade Edilen",
                value: String(guaranteeLettersResult.returnedCount),
              },
            ]}
          />
          <DashboardStatCard
            href="/gecmis-ihaleler"
            value={completedCount}
            title="Toplam Tamamlanan İhale"
            subtitle={`${wonCount} Kazanıldı, ${lostCount} Sözleşme İmzalanmadı`}
            legend={[
              {
                dotClass: "bg-accent",
                label: "Değerlendirmede",
                value: String(openCount),
              },
              {
                dotClass: "bg-slate-300",
                label: "Toplam İhale",
                value: String(dashboard.tenders.length),
              },
            ]}
          />
        </div>

        <div className="grid grid-cols-[minmax(0,1fr)] gap-6 xl:grid-cols-[minmax(0,1.1fr)_minmax(0,0.9fr)]">
          <DashboardCalendar events={events} />
          <DashboardTaskList tasks={tasksResult.activeTasks} />
        </div>
      </section>
    </div>
  );
}

function formatDateShort(isoDateTime: string): string {
  const date = new Date(isoDateTime);
  if (Number.isNaN(date.getTime())) return "—";
  return new Intl.DateTimeFormat("tr-TR", { dateStyle: "medium" }).format(date);
}
