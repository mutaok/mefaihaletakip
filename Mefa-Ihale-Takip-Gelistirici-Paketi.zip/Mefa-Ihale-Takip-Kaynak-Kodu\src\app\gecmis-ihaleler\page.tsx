import Link from "next/link";
import { ArrowLeft, CheckCircle2, History } from "lucide-react";

import { formatDate } from "@/lib/format";
import { getPastTenders } from "@/lib/tenders";

export const dynamic = "force-dynamic";

export default async function PastTendersPage() {
  const result = await getPastTenders();

  return (
    <div className="flex flex-1 flex-col overflow-hidden">
      <header className="flex flex-shrink-0 items-center gap-4 border-b border-line bg-white/50 px-6 py-3 backdrop-blur-sm">
        <Link
          href="/"
          className="inline-flex flex-shrink-0 items-center gap-2 rounded-xl border border-line bg-white px-3.5 py-2 text-sm font-medium text-foreground transition hover:border-accent/30"
        >
          <ArrowLeft className="size-4" /> Geri
        </Link>
        <div className="flex items-center gap-3">
          <History className="size-5 text-accent" />
          <h1 className="text-base font-bold text-foreground">Geçmiş İhaleler</h1>
          <span className="rounded-full bg-accent/10 px-2.5 py-0.5 text-xs font-semibold text-accent">
            {result.tenders.length}
          </span>
        </div>
      </header>

      <div className="flex-1 overflow-y-auto">
        <div className="mx-auto max-w-3xl space-y-4 p-6">
          {!result.isConfigured && (
            <div className="rounded-2xl border border-sky-200 bg-sky-50/90 px-4 py-3 text-xs leading-6 text-sky-900">
              Supabase bağlantısı henüz aktif değil.
            </div>
          )}

          {result.dataError && (
            <div className="rounded-2xl border border-rose-200 bg-rose-50/90 px-4 py-3 text-xs leading-6 text-rose-900">
              {result.dataError}
            </div>
          )}

          {result.tenders.length > 0 ? (
            <div className="space-y-2">
              {result.tenders.map((tender) => (
                <Link
                  key={tender.id}
                  href={`/tenders/${tender.id}`}
                  className="flex flex-wrap items-center justify-between gap-4 rounded-2xl border border-line bg-white/80 px-5 py-4 transition hover:border-accent/30"
                >
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-semibold text-foreground">
                      {tender.title}
                    </p>
                    <p className="mt-0.5 text-xs text-muted">
                      {tender.authority && `${tender.authority} · `}
                      {formatDate(tender.tenderDate)}
                    </p>
                  </div>
                  {tender.resultBidCount !== null && (
                    <span className="inline-flex flex-shrink-0 items-center gap-1.5 rounded-full border border-emerald-200 bg-emerald-50 px-3 py-1 text-xs font-semibold text-emerald-700">
                      <CheckCircle2 className="size-3.5" />
                      Sonuç girildi · {tender.resultBidCount} teklif
                    </span>
                  )}
                </Link>
              ))}
            </div>
          ) : (
            <div className="flex flex-col items-center gap-3 py-16 text-center">
              <History className="size-10 text-muted/30" />
              <p className="text-sm text-muted">Tarihi geçmiş ihale bulunmuyor</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
