import Link from "next/link";
import { Check } from "lucide-react";

import { toggleTaskCompletedAction } from "@/app/actions";
import { formatDate, todayDateKey } from "@/lib/format";
import type { Task } from "@/lib/tasks";

type Urgency = "gecikti" | "bugun" | "yakinda";

const URGENCY_META: Record<
  Urgency,
  { label: string; chipClass: string; barClass: string }
> = {
  gecikti: {
    label: "Gecikti",
    chipClass: "bg-red-50 text-red-700 border border-red-200",
    barClass: "bg-rose-500",
  },
  bugun: {
    label: "Bugün",
    chipClass: "bg-slate-800 text-white",
    barClass: "bg-slate-800",
  },
  yakinda: {
    label: "Yakında",
    chipClass: "bg-amber-50 text-amber-700 border border-amber-200",
    barClass: "bg-emerald-500",
  },
};

function taskUrgency(task: Task, today: string): Urgency {
  if (task.dueDate < today) return "gecikti";
  if (task.dueDate === today) return "bugun";
  return "yakinda";
}

export function DashboardTaskList({ tasks }: { tasks: Task[] }) {
  const today = todayDateKey();
  const visible = tasks.slice(0, 5);

  return (
    <section className="flex flex-col rounded-2xl bg-white p-6 shadow-[0_2px_16px_rgba(21,54,50,0.07)]">
      <div className="mb-4 flex items-center justify-between">
        <h3 className="text-base font-extrabold tracking-wide text-foreground">
          GÖREV LİSTESİ
        </h3>
        <Link
          href="/gorevler"
          className="text-xs font-medium text-muted transition-colors hover:text-foreground"
        >
          Tümünü Gör
        </Link>
      </div>

      {visible.length === 0 ? (
        <p className="py-8 text-center text-sm text-muted">Bekleyen görev yok.</p>
      ) : (
        <ul className="space-y-4">
          {visible.map((task) => {
            const meta = URGENCY_META[taskUrgency(task, today)];
            return (
              <li key={task.id} className="flex items-start gap-3">
                <span className={`w-1 self-stretch rounded-full ${meta.barClass}`} />
                <form action={toggleTaskCompletedAction} className="mt-0.5 shrink-0">
                  <input type="hidden" name="taskId" value={task.id} />
                  <input type="hidden" name="completed" value="true" />
                  <input type="hidden" name="redirectTo" value="/" />
                  <button
                    type="submit"
                    title="Görevi tamamla"
                    aria-label={`${task.title} görevini tamamla`}
                    className="group grid size-5 place-items-center rounded-full border-2 border-line transition hover:border-emerald-500 hover:bg-emerald-500"
                  >
                    <Check className="size-3 text-transparent transition group-hover:text-white" />
                  </button>
                </form>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-[13px] font-bold text-foreground">
                    {task.title}
                  </p>
                  <p className="mt-0.5 text-xs text-muted">
                    (Son Tarih: {formatDate(task.dueDate)})
                  </p>
                </div>
                <span
                  className={`inline-flex shrink-0 items-center rounded-full px-3 py-1 text-[11px] font-semibold ${meta.chipClass}`}
                >
                  {meta.label}
                </span>
              </li>
            );
          })}
        </ul>
      )}
    </section>
  );
}
