"use client";

import L from "leaflet";
import { MapContainer, Marker, Popup, TileLayer } from "react-leaflet";

export type MapMarker = {
  id: string;
  title: string;
  il: string;
  ilce: string | null;
  latitude: number;
  longitude: number;
  count: number;
};

type TenderMapProps = {
  markers: MapMarker[];
};

function buildIcon(count: number) {
  const label = count > 1 ? String(count) : "&#9733;";
  return L.divIcon({
    className: "tender-star-marker-wrap",
    html: `<span class="tender-star-marker" aria-hidden="true">${label}</span>`,
    iconAnchor: [20, 20],
    iconSize: [40, 40],
  });
}

export function TenderMap({ markers }: TenderMapProps) {
  if (markers.length === 0) return null;

  const center: [number, number] =
    markers.length === 1
      ? [markers[0].latitude, markers[0].longitude]
      : [39.0, 35.0];

  const zoom = markers.length === 1 ? 9 : 6;

  return (
    <MapContainer center={center} className="h-full w-full" scrollWheelZoom zoom={zoom}>
      <TileLayer
        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
      />
      {markers.map((m) => (
        <Marker key={m.id} icon={buildIcon(m.count)} position={[m.latitude, m.longitude]}>
          <Popup>
            <strong>{m.count > 1 ? `${m.count} proje` : m.title}</strong>
            <br />
            {m.ilce ? `${m.ilce}, ${m.il}` : m.il}
          </Popup>
        </Marker>
      ))}
    </MapContainer>
  );
}
