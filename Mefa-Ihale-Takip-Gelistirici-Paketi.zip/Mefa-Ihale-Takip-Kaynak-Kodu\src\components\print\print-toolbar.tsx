"use client";

import Link from "next/link";
import { ArrowLeft, Printer } from "lucide-react";

export function PrintToolbar({ backHref }: { backHref: string }) {
  return (
    <div className="pd-toolbar">
      <Link href={backHref} className="pd-toolbar-back">
        <ArrowLeft size={14} /> Geri
      </Link>
      <button type="button" className="pd-toolbar-print" onClick={() => window.print()}>
        <Printer size={14} /> Yazdır
      </button>
    </div>
  );
}
