"use client";

import dynamic from "next/dynamic";
import type { MapMarker } from "@/components/tender-map";

type TenderMapPanelProps = {
  markers: MapMarker[];
};

const TenderMap = dynamic(
  () => import("@/components/tender-map").then((module) => module.TenderMap),
  {
    loading: () => (
      <div className="grid h-full min-h-80 place-items-center rounded-[30px] bg-card text-sm text-muted">
        Harita yukleniyor...
      </div>
    ),
    ssr: false,
  },
);

export function TenderMapPanel(props: TenderMapPanelProps) {
  return <TenderMap {...props} />;
}
