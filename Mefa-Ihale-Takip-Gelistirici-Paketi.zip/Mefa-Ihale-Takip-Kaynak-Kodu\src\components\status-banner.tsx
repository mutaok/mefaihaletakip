import clsx from "clsx";

import type { FlashMessage } from "@/lib/flash";

const variantStyles: Record<FlashMessage["variant"], string> = {
  error:
    "border border-rose-300/70 bg-rose-50/90 text-rose-950 shadow-[0_18px_36px_rgba(244,63,94,0.1)]",
  info: "border border-sky-300/70 bg-sky-50/90 text-sky-950",
  success:
    "border border-emerald-300/70 bg-emerald-50/90 text-emerald-950 shadow-[0_18px_36px_rgba(16,185,129,0.12)]",
};

export function StatusBanner({ flash }: { flash: FlashMessage }) {
  return (
    <div
      className={clsx(
        "panel-shadow rounded-[28px] px-5 py-4 sm:px-6",
        variantStyles[flash.variant],
      )}
    >
      <p className="text-sm font-semibold uppercase tracking-[0.22em]">
        {flash.title}
      </p>
      <p className="mt-2 text-sm leading-6 text-current/80">{flash.description}</p>
    </div>
  );
}
