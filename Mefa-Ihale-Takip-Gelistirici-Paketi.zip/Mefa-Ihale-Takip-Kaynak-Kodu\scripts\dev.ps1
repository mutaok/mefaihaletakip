$ErrorActionPreference = "Stop"

$root = Split-Path -Parent $PSScriptRoot
$nodeBin = Join-Path $root ".tools\node-v24.14.1-win-x64"
$npmCmd = Join-Path $nodeBin "npm.cmd"

if (-not (Test-Path $npmCmd)) {
  throw "Tasinabilir Node bulunamadi. .tools\\node-v24.14.1-win-x64 klasorunu kontrol edin."
}

$env:PATH = "$nodeBin;$env:PATH"
& $npmCmd run dev
