"use client";

import { useRef } from "react";
import { CirclePlus, Trash2 } from "lucide-react";

import {
  addRequiredDocumentAction,
  toggleRequiredDocumentAction,
  removeRequiredDocumentAction,
} from "@/app/actions";
import { SubmitButton } from "@/components/submit-button";
import type { RequiredDocumentItem } from "@/lib/tender-details";

type Props = {
  tenderId: string;
  requiredDocuments: RequiredDocumentItem[];
};

function ChecklistRow({
  item,
  index,
  tenderId,
}: {
  item: RequiredDocumentItem;
  index: number;
  tenderId: string;
}) {
  const toggleRef = useRef<HTMLFormElement>(null);

  return (
    <div className="flex items-center gap-3 rounded-xl border border-line bg-white/60 px-4 py-3">
      {/* Toggle */}
      <form ref={toggleRef} action={toggleRequiredDocumentAction} className="print:hidden">
        <input type="hidden" name="tenderId" value={tenderId} />
        <input type="hidden" name="documentIndex" value={index} />
        <input type="hidden" name="checked" value={item.checked ? "false" : "true"} />
        <input
          type="checkbox"
          checked={item.checked}
          onChange={() => toggleRef.current?.requestSubmit()}
          className="size-5 rounded border-line accent-accent cursor-pointer"
        />
      </form>

      {/* Print-only static checkbox */}
      <span className="hidden print:inline-block">
        {item.checked ? "☑" : "☐"}
      </span>

      {/* Name */}
      <span
        className={`flex-1 text-sm ${
          item.checked
            ? "text-muted line-through"
            : "text-foreground font-medium"
        }`}
      >
        {item.name}
      </span>

      {/* Remove */}
      <form action={removeRequiredDocumentAction} className="print:hidden">
        <input type="hidden" name="tenderId" value={tenderId} />
        <input type="hidden" name="documentIndex" value={index} />
        <SubmitButton
          className="inline-flex items-center rounded-lg border border-rose-200 bg-rose-50 p-1.5 text-rose-700 transition hover:bg-rose-100 disabled:opacity-70"
          pendingLabel=""
        >
          <Trash2 className="size-3.5" />
        </SubmitButton>
      </form>
    </div>
  );
}

export function RequiredDocumentsChecklist({ tenderId, requiredDocuments }: Props) {
  const checkedCount = requiredDocuments.filter((d) => d.checked).length;

  return (
    <div className="space-y-3">
      {/* Add form */}
      <form
        action={addRequiredDocumentAction}
        className="flex flex-wrap items-end gap-3 print:hidden"
      >
        <input type="hidden" name="tenderId" value={tenderId} />
        <div className="min-w-[200px] flex-1">
          <label className="block">
            <span className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-muted">
              Evrak Adı
            </span>
            <input
              name="documentName"
              required
              placeholder="Örn: Bilanço, İş Deneyim Belgesi"
              className="w-full rounded-xl border border-line bg-white/80 px-3.5 py-2.5 text-sm text-foreground outline-none transition focus:border-accent focus:ring-2 focus:ring-accent/15"
            />
          </label>
        </div>
        <SubmitButton
          className="inline-flex flex-shrink-0 items-center gap-2 rounded-xl border border-line bg-white px-4 py-2.5 text-sm font-semibold text-foreground transition hover:border-accent/30 disabled:opacity-70"
          pendingLabel="Ekleniyor..."
        >
          <CirclePlus className="size-4" /> Ekle
        </SubmitButton>
      </form>

      {/* Progress */}
      {requiredDocuments.length > 0 && (
        <div className="flex items-center gap-2 text-xs text-muted">
          <span className="rounded-full bg-accent/10 px-2.5 py-0.5 font-semibold text-accent">
            {checkedCount}/{requiredDocuments.length}
          </span>
          tamamlandı
          {checkedCount === requiredDocuments.length && requiredDocuments.length > 0 && (
            <span className="ml-1 text-accent font-semibold">— Tüm evraklar hazır ✓</span>
          )}
        </div>
      )}

      {/* List */}
      {requiredDocuments.length > 0 ? (
        <div className="space-y-1.5">
          {requiredDocuments.map((item, index) => (
            <ChecklistRow
              key={`${item.name}-${index}`}
              item={item}
              index={index}
              tenderId={tenderId}
            />
          ))}
        </div>
      ) : (
        <p className="text-sm text-muted">Henüz istenilen evrak eklenmedi.</p>
      )}
    </div>
  );
}
